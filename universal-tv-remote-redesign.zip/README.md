# Controle Universal de TV

Universal smart-TV remote (PT-BR) — installable PWA + Node backend that speaks each manufacturer's protocol.

## Technical audit (what was found)

The workspace did **not** contain an Android project: no Gradle files, Kotlin sources, GitHub repository, screenshots
or error captures — only an empty Next.js + PostgreSQL template. So nothing could be preserved, and **no APK can be built
here**. Instead of inventing an audit of code that does not exist, the app was implemented as a PWA (Add to Home Screen on
Android) with a real backend. If you share the Android repository, the adapters in `src/lib/protocols/*` are a
documented reference for porting each protocol to Kotlin.

> **Important:** the server must run on the **same LAN** as the TVs (laptop, mini-PC, Raspberry Pi, NAS). A cloud-hosted
> instance cannot reach `192.168.x.x`. The phone just opens the app in the browser.

## Architecture

| Layer | Where |
|---|---|
| UI (React, glass/dark+light, PT-BR) | `src/components/*` |
| Client state, auto-reconnect, polling | `src/components/store.tsx` |
| REST API | `src/app/api/**` |
| Device records / pairing flow | `src/lib/device-service.ts`, `src/db/schema.ts` (PostgreSQL via Drizzle) |
| Credential vault (AES-256-GCM, key outside DB) | `src/lib/crypto.ts` |
| Connection manager (health check, back-off, recovery) | `src/lib/connection-manager.ts`, `src/lib/reconnect.ts` |
| Protocol adapters (one file per brand) | `src/lib/protocols/{lg,samsung,sony,androidtv,roku,philips,panasonic,vizio,dlna,chromecast}.ts` |
| Discovery (SSDP + per-adapter probes), WoL, DLNA | `src/lib/ssdp.ts`, `src/lib/net.ts`, `src/lib/dlna.ts` |
| File hosting + transfer state machine | `src/app/api/files/**`, `src/lib/transfer.ts` |

Each adapter independently implements identification (`probe`), pairing (`beginPairing`/`finishPairing`), connect /
reconnect, its own key map, apps, text, cast and media where the protocol allows. The UI only enables commands present in
the connected adapter's key map (`capabilitiesFor`).

## Permanent pairing

* First connection: identify → official pairing (TV prompt / PIN) → credential stored **encrypted** → TV saved.
* Later: stored credential is decrypted server-side and reused. A new pairing is never started when a valid credential
  exists (`startPairing` short-circuits, `connection-manager` never contacts a TV for pairing on its own).
* Survives app close, phone reboot, Wi‑Fi drops (server keeps the session; client re-syncs on `online`/foreground) and
  server restarts (`instrumentation.ts` reconnects favourite/last TV with stored credentials).
* Network failures → exponential back-off retries. Only an explicit credential rejection (twice in a row) marks the TV
  `revoked` and asks the user to pair again.
* Encryption key: `CREDENTIAL_KEY` env var, or a random key in `.data/credential.key` (mode 0600). Back up `.data/`.
  Losing the key makes credentials unreadable (the app then asks to re-pair — it never fabricates credentials).
* Tokens are never logged or sent to the browser.

## Honest compatibility matrix (nothing here was tested on physical TVs)

| Brand | Keys | Apps | Pairing | Notes |
|---|---|---|---|---|
| Roku | ✔ ECP | ✔ list + icons | none needed | Cast via DLNA or Roku Media Player (needs hardware test) |
| LG webOS | ✔ SSAP + pointer socket | ✔ | TV prompt → `client-key` | Unsigned manifest; cast needs DLNA enabled |
| Samsung Tizen | ✔ | list on older models, shortcuts on newer | TV "Allow" → token | 2016+ |
| Sony Bravia | ✔ IRCC (codes read from TV) | ✔ | PIN (cookie, can expire) or `psk:KEY` | |
| Android TV / Google TV | ✔ Remote v2 | deep-link shortcuts only (protocol can't list apps) | 6-char code → client certificate | uses `androidtv-remote` |
| Philips JointSPACE | ✔ v6 digest / v1 | ✔ (v6) | 4-digit PIN | |
| Panasonic Viera | ✔ unencrypted NRC | ✘ | none | **2018+ encrypted models NOT supported** |
| Vizio SmartCast | ✔ (no numpad) | ✘ | PIN → AUTH token | |
| DLNA/UPnP | ✘ keys | ✘ | none | cast, play/pause/seek, volume |
| Chromecast | ✘ | ✘ | — | **CASTV2 not implemented**; discovery/reachability only. Use an Android/Google TV profile for Chromecast with Google TV |

TLS: TVs use self-signed certificates, so verification is relaxed **per socket/request to the explicit TV IP only** — never
globally.

## File sharing — what is and isn't possible

Phone → server (streamed upload with progress/cancel) → TV pulls over HTTP with Range support (DLNA `SetAVTransportURI`,
or Roku Media Player). Only **photos, videos, music** can be rendered that way. PDFs/other files can't be pushed to any
TV through an official protocol; they're hosted and shared as a LAN link. TVs without DLNA would need a companion receiver
app installed on the TV (not included).

## Running

```bash
npm install
npx drizzle-kit push      # create tables
npm run build && npm start
npx vitest run            # unit + integration tests
```

Env: `DATABASE_URL`, optional `CREDENTIAL_KEY`, `DATA_DIR`, `MAX_UPLOAD_MB`, `PORT`.
There is no login: run it only on a trusted home network.

## Needs physical-TV verification

LG manifest acceptance on newest webOS, Samsung app listing on 2020+ models, Sony cookie lifetime, Philips v6 pairing
signature, Vizio key codes, Roku `/input/15985` casting, DLNA seek/volume per model, Android TV key injection on your
firmware.
