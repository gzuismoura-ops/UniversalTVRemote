import http from "node:http";
import { eq } from "drizzle-orm";
import { afterAll, beforeAll, describe, expect, it } from "vitest";
import { db, pool } from "@/db";
import { devices } from "@/db/schema";
import { readCredentials, saveCredentials } from "@/lib/device-service";
import { rokuModule } from "@/lib/protocols/roku";

/** A fake Roku ECP server on 127.0.0.1:8060 — verifies real HTTP commands and app discovery. */
const seen: string[] = [];
let server: http.Server;
let listening = false;

beforeAll(async () => {
  server = http.createServer((req, res) => {
    seen.push(`${req.method} ${req.url}`);
    if (req.url === "/query/apps") {
      res.end('<apps><app id="12" type="appl" version="4.1">Netflix</app><app id="837" type="appl" version="1.0">YouTube &amp; Co</app></apps>');
    } else if (req.url === "/query/device-info") {
      res.end("<device-info><user-device-name>Sala</user-device-name><model-name>Roku Ultra</model-name><wifi-mac>AA:BB:CC:00:11:22</wifi-mac></device-info>");
    } else res.end("");
  });
  await new Promise<void>((resolve) => {
    server.once("error", () => resolve());
    server.listen(8060, "127.0.0.1", () => {
      listening = true;
      resolve();
    });
  });
});
afterAll(async () => {
  server?.close();
  await pool.end();
});

describe("Roku adapter (against a local fake ECP)", () => {
  const ctx = { ip: "127.0.0.1", port: 8060, clientName: "t", credentials: null, meta: {}, saveCredentials: async () => undefined };

  it("identifies the device", async () => {
    if (!listening) return;
    const id = await rokuModule.probe("127.0.0.1");
    expect(id).toMatchObject({ brand: "roku", name: "Sala", model: "Roku Ultra", mac: "aa:bb:cc:00:11:22" });
  });

  it("discovers applications (with icons) and launches one", async () => {
    if (!listening) return;
    const d = rokuModule.createDriver(ctx);
    await d.connect();
    const apps = await d.listApps!();
    expect(apps.map((a) => a.name)).toEqual(["Netflix", "YouTube & Co"]);
    expect(apps[0].icon).toBe("http://127.0.0.1:8060/query/icon/12");
    await d.launchApp!("12");
    expect(seen).toContain("POST /launch/12");
  });

  it("sends the Roku-specific key and rejects unmapped commands", async () => {
    if (!listening) return;
    const d = rokuModule.createDriver(ctx);
    await d.send("ok");
    expect(seen).toContain("POST /keypress/Select");
    await expect(d.send("red")).rejects.toThrow(/não suportado/i);
  });
});

describe("device storage & credential retrieval (PostgreSQL)", () => {
  it("stores credentials encrypted and restores them after a 'restart'", async () => {
    const [row] = await db
      .insert(devices)
      .values({ name: "Teste", brand: "lg", ip: "10.255.255.250", authState: "none" })
      .returning();
    try {
      await saveCredentials(row.id, { clientKey: "abc-123-secret" });
      const [raw] = await db.select().from(devices).where(eq(devices.id, row.id));
      expect(raw.credentialsEnc).toBeTruthy();
      expect(raw.credentialsEnc).not.toContain("abc-123-secret"); // not plain text in the DB
      expect(raw.authState).toBe("paired");
      // Fresh read (simulates reopening the app) -> same credential, no new pairing needed.
      expect(readCredentials(raw)).toEqual({ clientKey: "abc-123-secret" });
    } finally {
      await db.delete(devices).where(eq(devices.id, row.id));
    }
  });
});
