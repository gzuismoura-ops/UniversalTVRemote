import crypto from "node:crypto";
import { describe, expect, it } from "vitest";
import { COMMANDS } from "@/lib/commands";
import { decryptJson, encryptJson } from "@/lib/crypto";
import { buildMagicPacket, isPrivateIPv4, normalizeMac } from "@/lib/net";
import { MODULES, capabilitiesFor } from "@/lib/protocols";
import { backoffDelay, decideReconnect, MAX_ATTEMPTS, MAX_DELAY_MS } from "@/lib/reconnect";
import { canTransition, isCastable, kindFromMime, progressPercent, transition } from "@/lib/transfer";

describe("credential vault (AES-256-GCM)", () => {
  const key = crypto.randomBytes(32);
  it("round-trips credentials and never leaks plain text", () => {
    const creds = { clientKey: "super-secret-key-123" };
    const enc = encryptJson(creds, key);
    expect(enc).not.toContain("super-secret");
    expect(decryptJson(enc, key)).toEqual(creds);
  });
  it("returns null for a wrong key or tampered payload (forces re-pair, never fake credentials)", () => {
    const enc = encryptJson({ a: 1 }, key);
    expect(decryptJson(enc, crypto.randomBytes(32))).toBeNull();
    const parts = enc.split(":");
    parts[3] = Buffer.from("tampered").toString("base64");
    expect(decryptJson(parts.join(":"), key)).toBeNull();
  });
});

describe("reconnection policy", () => {
  it("retries (never re-pairs) on network failures even when credentials are valid", () => {
    for (let a = 0; a < 10; a++) {
      const d = decideReconnect({ attempts: a, authState: "paired", errorKind: "network" });
      expect(d.action).toBe("retry");
    }
  });
  it("asks for pairing only when the TV rejected the credential or it was revoked", () => {
    expect(decideReconnect({ attempts: 0, authState: "paired", errorKind: "auth" }).action).toBe("needs-pairing");
    expect(decideReconnect({ attempts: 0, authState: "revoked" }).action).toBe("needs-pairing");
  });
  it("uses capped exponential back-off and eventually gives up", () => {
    expect(backoffDelay(0)).toBeLessThan(backoffDelay(3));
    expect(backoffDelay(50)).toBe(MAX_DELAY_MS);
    expect(decideReconnect({ attempts: MAX_ATTEMPTS, authState: "paired", errorKind: "network" }).action).toBe("give-up");
  });
});

describe("transfer state machine", () => {
  it("allows the happy path and rejects invalid jumps", () => {
    expect(transition("uploading", "ready")).toBe("ready");
    expect(transition("ready", "sending")).toBe("sending");
    expect(transition("sending", "sent")).toBe("sent");
    expect(() => transition("uploading", "sent")).toThrow();
    expect(canTransition("cancelled", "sending")).toBe(false);
    expect(canTransition("failed", "sending")).toBe(true);
  });
  it("computes progress and classifies files honestly", () => {
    expect(progressPercent(50, 200)).toBe(25);
    expect(progressPercent(5, 0)).toBe(0);
    expect(progressPercent(999, 100)).toBe(100);
    expect(kindFromMime("image/png")).toBe("image");
    expect(kindFromMime("application/pdf", "a.pdf")).toBe("document");
    expect(isCastable("document")).toBe(false);
    expect(isCastable("video")).toBe(true);
  });
});

describe("manufacturer command mapping", () => {
  it("every adapter only maps known universal commands", () => {
    for (const m of Object.values(MODULES)) {
      for (const k of Object.keys(m.keymap)) expect(COMMANDS).toContain(k);
    }
  });
  it("maps to the native codes of each brand", () => {
    expect(MODULES.lg.keymap.volUp).toBe("ssap:audio/volumeUp");
    expect(MODULES.lg.keymap.ok).toBe("btn:ENTER");
    expect(MODULES.samsung.keymap.volUp).toBe("KEY_VOLUP");
    expect(MODULES.samsung.keymap.blue).toBe("KEY_CYAN");
    expect(MODULES.roku.keymap.ok).toBe("Select");
    expect(MODULES.sony.keymap.back).toBe("Return");
    expect(MODULES.androidtv.keymap.ok).toBe("KEYCODE_DPAD_CENTER");
    expect(MODULES.philips.keymap.up).toBe("CursorUp");
    expect(MODULES.panasonic.keymap.mute).toBe("NRC_MUTE-ONOFF");
    expect(MODULES.vizio.keymap.volDown).toBe("5,0");
  });
  it("capabilities reflect real support (no fake buttons)", () => {
    expect(capabilitiesFor("vizio").commands).not.toContain("num0");
    expect(capabilitiesFor("roku").commands).not.toContain("red");
    expect(capabilitiesFor("chromecast").commands).toHaveLength(0);
    expect(capabilitiesFor("lg").features).not.toContain("cast");
    expect(capabilitiesFor("lg", { dlnaLocation: "http://x/desc.xml" }).features).toContain("cast");
    expect(capabilitiesFor("roku").features).toContain("cast");
    expect(capabilitiesFor("unknown").commands).toEqual([]);
  });
});

describe("network helpers", () => {
  it("builds a valid Wake-on-LAN magic packet", () => {
    const p = buildMagicPacket("AA:BB:CC:DD:EE:FF");
    expect(p).toHaveLength(102);
    expect(p.subarray(0, 6).every((b) => b === 0xff)).toBe(true);
    expect(p.subarray(6, 12).toString("hex")).toBe("aabbccddeeff");
    expect(() => buildMagicPacket("nope")).toThrow();
  });
  it("normalises MACs and restricts targets to private IPs", () => {
    expect(normalizeMac("AA-BB-CC-DD-EE-FF")).toBe("aa:bb:cc:dd:ee:ff");
    expect(normalizeMac("zz")).toBeNull();
    expect(isPrivateIPv4("192.168.0.10")).toBe(true);
    expect(isPrivateIPv4("8.8.8.8")).toBe(false);
  });
});
