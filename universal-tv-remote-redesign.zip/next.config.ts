import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  serverExternalPackages: ["ws", "androidtv-remote", "pg"],
  poweredByHeader: false,
};

export default nextConfig;
