import {
  boolean,
  integer,
  jsonb,
  pgTable,
  serial,
  text,
  timestamp,
  uuid,
  bigint,
} from "drizzle-orm/pg-core";

/**
 * Saved televisions. `credentialsEnc` holds the pairing token / client-key /
 * certificate, encrypted with AES-256-GCM (see src/lib/crypto.ts). It is never
 * returned to the browser.
 */
export const devices = pgTable("devices", {
  id: uuid("id").defaultRandom().primaryKey(),
  name: text("name").notNull(),
  brand: text("brand").notNull(),
  model: text("model"),
  ip: text("ip").notNull(),
  port: integer("port"),
  mac: text("mac"),
  uniqueId: text("unique_id"),
  credentialsEnc: text("credentials_enc"),
  authState: text("auth_state").notNull().default("none"), // none | paired | revoked
  meta: jsonb("meta").$type<Record<string, unknown>>().notNull().default({}),
  favorite: boolean("favorite").notNull().default(false),
  lastConnectedAt: timestamp("last_connected_at"),
  lastSeenAt: timestamp("last_seen_at"),
  lastError: text("last_error"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const favoriteApps = pgTable("favorite_apps", {
  id: serial("id").primaryKey(),
  deviceId: uuid("device_id")
    .notNull()
    .references(() => devices.id, { onDelete: "cascade" }),
  appId: text("app_id").notNull(),
  name: text("name").notNull(),
  icon: text("icon"),
  position: integer("position").notNull().default(0),
});

export const activities = pgTable("activities", {
  id: serial("id").primaryKey(),
  deviceId: uuid("device_id").references(() => devices.id, {
    onDelete: "cascade",
  }),
  type: text("type").notNull(), // app | connect | file | media | error | command
  label: text("label").notNull(),
  refId: text("ref_id"),
  icon: text("icon"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const transfers = pgTable("transfers", {
  id: uuid("id").defaultRandom().primaryKey(),
  name: text("name").notNull(),
  mime: text("mime").notNull(),
  kind: text("kind").notNull(), // image | video | audio | document | other
  size: bigint("size", { mode: "number" }).notNull().default(0),
  received: bigint("received", { mode: "number" }).notNull().default(0),
  path: text("path"),
  status: text("status").notNull().default("uploading"),
  error: text("error"),
  deviceId: uuid("device_id").references(() => devices.id, {
    onDelete: "set null",
  }),
  method: text("method"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export type DeviceRow = typeof devices.$inferSelect;
export type TransferRow = typeof transfers.$inferSelect;
