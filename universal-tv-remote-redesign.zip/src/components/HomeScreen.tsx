"use client";

import { Gamepad2, Home as HomeIcon, Plus, Power, Sparkles, Tv, VolumeX, Volume1, Volume2, Zap } from "lucide-react";
import { useEffect, useState } from "react";
import { BRAND_LABEL, type ActivityDTO, type AppDTO, type Command } from "@/lib/commands";
import { useStore } from "./store";
import { AppIcon, BrandBadge, Empty, StatusChip, timeAgo } from "./ui";

const ACT_ICON: Record<string, string> = { app: "🚀", connect: "🔗", file: "📁", media: "🎬", error: "⚠️", command: "⚡" };

export function HomeScreen() {
  const { active, status, devices, api, setTab, selectDevice, setAddOpen, send, can, has, toast } = useStore();
  const [favs, setFavs] = useState<AppDTO[]>([]);
  const [acts, setActs] = useState<ActivityDTO[]>([]);

  useEffect(() => {
    if (!active) return;
    api<{ favorites: AppDTO[] }>(`/api/devices/${active.id}/favorites`).then((r) => setFavs(r.favorites)).catch(() => setFavs([]));
  }, [active, api]);
  useEffect(() => {
    api<{ activities: ActivityDTO[] }>("/api/activities").then((r) => setActs(r.activities.slice(0, 8))).catch(() => undefined);
  }, [api, active, status?.state]);

  if (devices.length === 0) {
    return (
      <div className="flex flex-col gap-4">
        <div className="glass rise relative overflow-hidden p-6">
          <div className="absolute -right-10 -top-10 h-40 w-40 rounded-full opacity-40 blur-3xl" style={{ background: "var(--accent)" }} />
          <Sparkles className="mb-3" style={{ color: "var(--accent-2)" }} />
          <h1 className="text-2xl font-extrabold leading-tight">Seu controle <span className="gradient-text">universal</span> de TV</h1>
          <p className="muted mt-2 text-sm">Pareie uma vez. Nas próximas vezes a conexão é restaurada automaticamente, sem pedir autorização de novo.</p>
          <button className="btn btn-primary mt-5" onClick={() => setAddOpen(true)}><Plus size={18} /> Adicionar minha TV</button>
        </div>
        <Empty icon={<Tv />} title="Compatibilidade" text="LG webOS, Samsung Tizen, Sony Bravia, Android/Google TV, Roku, Philips, Panasonic, Vizio e dispositivos DLNA. O servidor do app precisa estar na mesma rede da TV." />
      </div>
    );
  }

  const state = status?.state ?? "disconnected";
  const quick: { cmd: Command; label: string; icon: React.ReactNode }[] = [
    { cmd: "power", label: "Energia", icon: <Power size={20} /> },
    { cmd: "volDown", label: "Vol −", icon: <Volume1 size={20} /> },
    { cmd: "mute", label: "Mudo", icon: <VolumeX size={20} /> },
    { cmd: "volUp", label: "Vol +", icon: <Volume2 size={20} /> },
    { cmd: "home", label: "Início", icon: <HomeIcon size={20} /> },
    { cmd: "source", label: "Fonte", icon: <Gamepad2 size={20} /> },
  ];
  const wake = async () => {
    if (!active) return;
    try {
      await api(`/api/devices/${active.id}/wake`, { body: {} });
      toast("Pacote Wake-on-LAN enviado. Reconectando em instantes…", "ok");
    } catch (e) {
      toast((e as Error).message, "err");
    }
  };

  return (
    <div className="flex flex-col gap-5">
      {active && (
        <section className="glass rise relative overflow-hidden p-5">
          <div className="absolute -right-12 -top-12 h-44 w-44 rounded-full opacity-30 blur-3xl" style={{ background: state === "connected" ? "var(--ok)" : "var(--accent)" }} />
          <div className="flex items-center gap-4">
            <BrandBadge brand={active.brand} size={56} />
            <div className="min-w-0 flex-1">
              <p className="muted text-xs font-semibold uppercase tracking-wider">TV conectada</p>
              <h1 className="truncate text-xl font-extrabold">{active.name}</h1>
              <p className="muted truncate text-xs">{BRAND_LABEL[active.brand]} · {active.model ?? "modelo n/d"} · {active.ip}</p>
            </div>
          </div>
          <div className="mt-4 flex flex-wrap items-center gap-2">
            <StatusChip state={state} />
            {status?.latencyMs != null && <span className="chip">{status.latencyMs} ms</span>}
            {active.authState === "paired" && <span className="chip">🔒 Autorização salva</span>}
          </div>
          {state === "needs-pairing" && <p className="mt-3 text-sm" style={{ color: "var(--warn)" }}>A TV não aceita mais a autorização salva. Pareie novamente em “TVs”.</p>}
          {state !== "connected" && state !== "needs-pairing" && status?.error && <p className="muted mt-3 text-xs">{status.error}</p>}
          <div className="mt-4 flex gap-2">
            <button className="btn btn-primary flex-1" onClick={() => setTab("remote")}>Abrir controle</button>
            {active.mac && state !== "connected" && <button className="btn" onClick={wake}><Zap size={16} /> Ligar</button>}
          </div>
        </section>
      )}

      <section>
        <h2 className="muted mb-2 text-xs font-bold uppercase tracking-widest">Ações rápidas</h2>
        <div className="grid grid-cols-3 gap-2.5 sm:grid-cols-6">
          {quick.map((q) => (
            <button key={q.cmd} disabled={!can(q.cmd)} className="key h-16 flex-col gap-1 text-[11px] font-semibold" onClick={() => send(q.cmd)}>
              {q.icon}
              {q.label}
            </button>
          ))}
        </div>
      </section>

      {active && has("apps") && (
        <section>
          <div className="mb-2 flex items-center justify-between">
            <h2 className="muted text-xs font-bold uppercase tracking-widest">Apps favoritos</h2>
            <button className="text-xs font-semibold" style={{ color: "var(--accent-2)" }} onClick={() => setTab("apps")}>Ver todos</button>
          </div>
          {favs.length === 0 ? (
            <p className="card-sm muted p-4 text-sm">Toque na ⭐ de um app na aba Apps para fixá-lo aqui.</p>
          ) : (
            <div className="no-scrollbar flex gap-3 overflow-x-auto pb-1">
              {favs.map((a) => (
                <button key={a.id} className="flex w-[72px] shrink-0 flex-col items-center gap-1.5" onClick={() => api(`/api/devices/${active.id}/launch`, { body: { appId: a.id, name: a.name, icon: a.icon } }).then(() => toast(`Abrindo ${a.name}`, "ok")).catch((e) => toast(e.message, "err"))}>
                  <AppIcon deviceId={active.id} ip={active.ip} icon={a.icon} name={a.name} />
                  <span className="w-full truncate text-center text-[11px] font-medium">{a.name}</span>
                </button>
              ))}
            </div>
          )}
        </section>
      )}

      <section>
        <h2 className="muted mb-2 text-xs font-bold uppercase tracking-widest">Dispositivos recentes</h2>
        <div className="flex flex-col gap-2">
          {devices.slice(0, 4).map((d) => (
            <button key={d.id} onClick={() => selectDevice(d.id)} className="card-sm flex items-center gap-3 p-3 text-left transition active:scale-[0.98]" style={d.id === active?.id ? { borderColor: "var(--accent)" } : undefined}>
              <BrandBadge brand={d.brand} size={38} />
              <div className="min-w-0 flex-1">
                <p className="truncate text-sm font-semibold">{d.favorite && "⭐ "}{d.name}</p>
                <p className="muted truncate text-xs">{d.ip} · {timeAgo(d.lastConnectedAt)}</p>
              </div>
              {d.id === active?.id && <span className="chip">Ativa</span>}
            </button>
          ))}
        </div>
      </section>

      <section>
        <h2 className="muted mb-2 text-xs font-bold uppercase tracking-widest">Atividades recentes</h2>
        {acts.length === 0 ? (
          <p className="card-sm muted p-4 text-sm">Suas ações aparecerão aqui.</p>
        ) : (
          <div className="card-sm divide-y" style={{ borderColor: "var(--border)" }}>
            {acts.map((a) => (
              <div key={a.id} className="flex items-center gap-3 px-3 py-2.5" style={{ borderColor: "var(--border)" }}>
                <span>{ACT_ICON[a.type] ?? "•"}</span>
                <span className="min-w-0 flex-1 truncate text-sm">{a.label}</span>
                <span className="muted text-xs">{timeAgo(a.createdAt)}</span>
              </div>
            ))}
          </div>
        )}
      </section>
    </div>
  );
}
