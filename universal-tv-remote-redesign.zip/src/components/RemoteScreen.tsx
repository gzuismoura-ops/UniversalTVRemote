"use client";

import {
  ArrowLeft, ChevronDown, ChevronLeft, ChevronRight, ChevronUp, FastForward, Home, Info, Keyboard, LayoutGrid, Menu, Mic, Minus, Pause, Play, Plus, Power, Rewind, Send,
  Settings, SkipBack, SkipForward, Square, Tv, Volume2, VolumeX,
} from "lucide-react";
import { useEffect, useRef, useState, type ReactNode } from "react";
import { COMMAND_LABEL, type Command } from "@/lib/commands";
import { useStore } from "./store";
import { Empty, StatusChip } from "./ui";

/** Button that repeats while held (volume / channel / d-pad). */
function useHold(fire: () => void, repeat: boolean) {
  const timer = useRef<ReturnType<typeof setInterval> | null>(null);
  const start = useRef<ReturnType<typeof setTimeout> | null>(null);
  const stop = () => {
    if (start.current) clearTimeout(start.current);
    if (timer.current) clearInterval(timer.current);
    start.current = timer.current = null;
  };
  useEffect(() => stop, []);
  return {
    onPointerDown: (e: React.PointerEvent) => {
      e.preventDefault();
      fire();
      if (repeat) start.current = setTimeout(() => (timer.current = setInterval(fire, 140)), 420);
    },
    onPointerUp: stop,
    onPointerLeave: stop,
    onPointerCancel: stop,
    onContextMenu: (e: React.SyntheticEvent) => e.preventDefault(),
  };
}

function Key({ cmd, children, className = "", repeat = false, label }: { cmd: Command; children: ReactNode; className?: string; repeat?: boolean; label?: string }) {
  const { can, send } = useStore();
  const ok = can(cmd);
  const h = useHold(() => void send(cmd), repeat);
  return (
    <button
      {...h}
      disabled={!ok}
      aria-label={label ?? COMMAND_LABEL[cmd]}
      title={ok ? COMMAND_LABEL[cmd] : "Não suportado por esta TV"}
      className={`key ${className}`}
    >
      {children}
    </button>
  );
}

function DpadBtn({ cmd, pos, children }: { cmd: Command; pos: React.CSSProperties; children: ReactNode }) {
  const { can, send } = useStore();
  const h = useHold(() => void send(cmd), true);
  return (
    <button {...h} disabled={!can(cmd)} aria-label={COMMAND_LABEL[cmd]} className="dpad-btn" style={pos}>
      {children}
    </button>
  );
}

function Rocker({ up, down, mid, label, upIcon, downIcon, midIcon }: { up: Command; down: Command; mid?: Command; label: string; upIcon: ReactNode; downIcon: ReactNode; midIcon?: ReactNode }) {
  return (
    <div className="flex w-[84px] flex-col items-stretch gap-2 rounded-[28px] p-2" style={{ background: "var(--surface)", border: "1px solid var(--border)" }}>
      <Key cmd={up} repeat className="h-16 !rounded-[22px]">{upIcon}</Key>
      <div className="muted flex flex-col items-center gap-1 text-[10px] font-bold uppercase tracking-wider">
        {mid ? <Key cmd={mid} className="h-9 w-full !rounded-xl">{midIcon}</Key> : null}
        {label}
      </div>
      <Key cmd={down} repeat className="h-16 !rounded-[22px]">{downIcon}</Key>
    </div>
  );
}

function Section({ title, children }: { title: string; children: ReactNode }) {
  return (
    <section className="glass p-4">
      <h3 className="muted mb-3 text-xs font-bold uppercase tracking-widest">{title}</h3>
      {children}
    </section>
  );
}

type SR = { start: () => void; stop: () => void; lang: string; interimResults: boolean; onresult: ((e: { results: ArrayLike<ArrayLike<{ transcript: string }>> }) => void) | null; onend: (() => void) | null; onerror: (() => void) | null };

function TextInput() {
  const { api, active, toast, has } = useStore();
  const [text, setText] = useState("");
  const [busy, setBusy] = useState(false);
  const [listening, setListening] = useState(false);
  const rec = useRef<SR | null>(null);
  const speech = typeof window !== "undefined" && (("SpeechRecognition" in window) || ("webkitSpeechRecognition" in window));

  const submit = async (t: string, enter: boolean) => {
    if (!active || !t.trim()) return;
    setBusy(true);
    try {
      await api(`/api/devices/${active.id}/text`, { body: { text: t, enter } });
      toast("Texto enviado à TV", "ok");
      setText("");
    } catch (e) {
      toast((e as Error).message, "err");
    } finally {
      setBusy(false);
    }
  };

  const listen = () => {
    const w = window as unknown as { SpeechRecognition?: new () => SR; webkitSpeechRecognition?: new () => SR };
    const Ctor = w.SpeechRecognition ?? w.webkitSpeechRecognition;
    if (!Ctor) return;
    if (listening) return rec.current?.stop();
    const r = new Ctor();
    r.lang = "pt-BR";
    r.interimResults = false;
    r.onresult = (e) => {
      const t = e.results[0]?.[0]?.transcript ?? "";
      setText(t);
      void submit(t, true);
    };
    r.onend = () => setListening(false);
    r.onerror = () => {
      setListening(false);
      toast("Não foi possível usar o microfone (requer HTTPS ou localhost e permissão)", "err");
    };
    rec.current = r;
    setListening(true);
    r.start();
  };

  if (!has("text")) {
    return <p className="muted text-sm">Esta TV não aceita digitação remota pelo protocolo atual.</p>;
  }
  return (
    <div className="flex gap-2">
      <input className="input" value={text} placeholder="Digitar na TV…" onChange={(e) => setText(e.target.value)} onKeyDown={(e) => e.key === "Enter" && submit(text, true)} />
      {speech && (
        <button className={`btn !px-3 ${listening ? "btn-primary" : ""}`} onClick={listen} aria-label="Entrada por voz">
          <Mic size={18} />
        </button>
      )}
      <button className="btn btn-primary !px-3" disabled={busy || !text.trim()} onClick={() => submit(text, true)} aria-label="Enviar texto">
        <Send size={18} />
      </button>
    </div>
  );
}

export function RemoteScreen() {
  const { active, status, settings, lastCommand, reconnect, setAddOpen, has, can } = useStore();
  const [textOpen, setTextOpen] = useState(false);

  if (!active) {
    return <Empty icon={<Tv />} title="Nenhuma TV selecionada" text="Adicione uma TV para usar o controle." action={<button className="btn btn-primary" onClick={() => setAddOpen(true)}>Adicionar TV</button>} />;
  }
  const state = status?.state ?? "disconnected";
  const offline = state !== "connected";
  const caps = active.capabilities.commands;
  const none = caps.length === 0;
  const show = settings.show;
  const flash = lastCommand && Date.now() - lastCommand.at < 1500 ? lastCommand : null;
  const nums: Command[] = ["num1", "num2", "num3", "num4", "num5", "num6", "num7", "num8", "num9"];
  const anyNum = caps.some((c) => c.startsWith("num"));
  const anyColor = ["red", "green", "yellow", "blue"].some((c) => caps.includes(c as Command));
  const anyPlay = ["play", "pause", "stop", "rewind", "forward", "next", "prev"].some((c) => caps.includes(c as Command));

  return (
    <div className="flex flex-col items-center gap-4 pb-6">
      <div className="glass flex w-full items-center gap-3 p-3">
        <div className="min-w-0 flex-1">
          <p className="truncate font-bold">{active.name}</p>
          <div className="mt-1 flex items-center gap-2">
            <StatusChip state={state} />
            {flash && <span className="chip rise" style={{ color: flash.ok ? "var(--ok)" : "var(--danger)" }}>{flash.ok ? "✓" : "✕"} {COMMAND_LABEL[flash.cmd]}</span>}
          </div>
        </div>
        <Key cmd="power" className="key-danger h-12 w-12 !rounded-full"><Power size={20} /></Key>
      </div>

      {offline && (
        <div className="card-sm flex w-full items-center justify-between gap-3 p-3 text-sm" style={{ borderColor: "var(--warn)" }}>
          <span>
            {state === "needs-pairing" ? "A TV pede um novo pareamento." : state === "reconnecting" ? `Reconectando automaticamente${status?.nextRetryInMs ? ` (em ${Math.ceil(status.nextRetryInMs / 1000)} s)` : ""}…` : status?.error ?? "TV desconectada."}
          </span>
          <button className="btn !py-1.5" onClick={() => (state === "needs-pairing" ? setAddOpen(true) : reconnect(true))}>
            {state === "needs-pairing" ? "Parear" : "Reconectar"}
          </button>
        </div>
      )}

      {none && (
        <div className="card-sm muted w-full p-4 text-sm">
          O protocolo desta TV ({active.brand}) não oferece comandos por teclas nesta versão. {has("cast") ? "Use as abas Arquivos e Mídia para enviar conteúdo." : ""}
        </div>
      )}

      {/* Quick shortcuts (customizable in Settings) */}
      {show.shortcuts && settings.shortcuts.some((c) => can(c)) && (
        <div className="flex w-full flex-wrap justify-center gap-2">
          {settings.shortcuts.filter((c) => can(c)).map((c) => (
            <Key key={c} cmd={c} className="h-10 px-4 text-xs font-bold !rounded-full">{COMMAND_LABEL[c]}</Key>
          ))}
        </div>
      )}

      {/* D-pad */}
      <div className="dpad my-2">
        <DpadBtn cmd="up" pos={{ top: "3%", left: "33%" }}><ChevronUp size={30} /></DpadBtn>
        <DpadBtn cmd="down" pos={{ bottom: "3%", left: "33%" }}><ChevronDown size={30} /></DpadBtn>
        <DpadBtn cmd="left" pos={{ left: "3%", top: "33%" }}><ChevronLeft size={30} /></DpadBtn>
        <DpadBtn cmd="right" pos={{ right: "3%", top: "33%" }}><ChevronRight size={30} /></DpadBtn>
        <Key cmd="ok" className="key-accent absolute left-1/2 top-1/2 h-[30%] w-[30%] -translate-x-1/2 -translate-y-1/2 !rounded-full text-lg font-extrabold">OK</Key>
      </div>

      {/* Navigation row */}
      <div className="grid w-full grid-cols-5 gap-2.5">
        <Key cmd="back" className="h-14"><ArrowLeft size={22} /></Key>
        <Key cmd="home" className="h-14"><Home size={22} /></Key>
        <Key cmd="menu" className="h-14"><Menu size={22} /></Key>
        <Key cmd="settings" className="h-14"><Settings size={22} /></Key>
        <Key cmd="source" className="h-14"><LayoutGrid size={22} /></Key>
      </div>

      {/* Volume / Channel */}
      <div className="flex w-full items-stretch justify-center gap-5">
        <Rocker up="volUp" down="volDown" mid="mute" label="Vol" upIcon={<Plus size={26} />} downIcon={<Minus size={26} />} midIcon={<VolumeX size={16} />} />
        <div className="flex flex-col justify-center gap-2">
          <Key cmd="info" className="h-12 w-12"><Info size={20} /></Key>
          <Key cmd="guide" className="h-12 w-12 text-[11px] font-bold">GUIA</Key>
          <div className="muted flex justify-center"><Volume2 size={16} /></div>
        </div>
        {show.channels && <Rocker up="chUp" down="chDown" label="Canal" upIcon={<ChevronUp size={28} />} downIcon={<ChevronDown size={28} />} />}
      </div>

      {show.playback && anyPlay && (
        <Section title="Reprodução">
          <div className="grid grid-cols-6 gap-2">
            <Key cmd="prev" className="h-12"><SkipBack size={18} /></Key>
            <Key cmd="rewind" className="h-12"><Rewind size={18} /></Key>
            <Key cmd="play" className="key-accent h-12"><Play size={18} /></Key>
            <Key cmd="pause" className="h-12"><Pause size={18} /></Key>
            <Key cmd="forward" className="h-12"><FastForward size={18} /></Key>
            <Key cmd="next" className="h-12"><SkipForward size={18} /></Key>
          </div>
          <div className="mt-2 grid grid-cols-6">
            <Key cmd="stop" className="col-span-2 col-start-3 h-10"><Square size={14} /></Key>
          </div>
        </Section>
      )}

      {show.colors && anyColor && (
        <div className="grid w-full grid-cols-4 gap-2.5">
          {([["red", "#ef4444"], ["green", "#22c55e"], ["yellow", "#eab308"], ["blue", "#3b82f6"]] as [Command, string][]).map(([c, col]) => (
            <Key key={c} cmd={c} className="h-9 !rounded-full" label={COMMAND_LABEL[c]}>
              <span className="block h-2.5 w-10 rounded-full" style={{ background: col, boxShadow: `0 0 12px ${col}` }} />
            </Key>
          ))}
        </div>
      )}

      {show.numpad && anyNum && (
        <Section title="Teclado numérico">
          <div className="grid grid-cols-3 gap-2.5">
            {nums.map((n) => (
              <Key key={n} cmd={n} className="h-12 text-lg font-bold">{n.slice(3)}</Key>
            ))}
            <span />
            <Key cmd="num0" className="h-12 text-lg font-bold">0</Key>
            <span />
          </div>
        </Section>
      )}

      {show.text && (
        <Section title="Teclado e voz">
          <button className="btn mb-3 w-full" onClick={() => setTextOpen((v) => !v)}>
            <Keyboard size={16} /> {textOpen ? "Ocultar" : "Digitar no celular → TV"}
          </button>
          {textOpen && <TextInput />}
        </Section>
      )}
    </div>
  );
}
