"use client";

import { Radar, Wifi } from "lucide-react";
import { useRef, useState } from "react";
import { BRAND_LABEL, BRANDS, type Brand, type DeviceDTO } from "@/lib/commands";
import { useStore } from "./store";
import { BrandBadge, Sheet, Spinner } from "./ui";

interface Found {
  ip: string;
  brand: Brand;
  name: string;
  model: string | null;
  saved: boolean;
}

type PairOutcome =
  | { status: "paired"; device: DeviceDTO; reused: boolean }
  | { status: "pin"; pairingId: string; message: string; identity: { brand: Brand; name: string; model: string | null } };

const WAIT_HINT: Partial<Record<Brand, string>> = {
  lg: "Pegue o controle da TV e aceite a solicitação “Permitir conexão” que apareceu na tela.",
  samsung: "Na TV, selecione “Permitir” na janela de autorização que apareceu.",
};

export function AddDeviceSheet({ onClose, presetIp }: { onClose: () => void; presetIp?: string }) {
  const { api, refreshDevices, selectDevice, toast, setTab } = useStore();
  const [mode, setMode] = useState<"scan" | "manual">(presetIp ? "manual" : "scan");
  const [scanning, setScanning] = useState(false);
  const [found, setFound] = useState<Found[] | null>(null);
  const [serverIps, setServerIps] = useState<string[]>([]);
  const [ip, setIp] = useState(presetIp ?? "");
  const [brand, setBrand] = useState<Brand | "">("");
  const [phase, setPhase] = useState<"idle" | "working" | "pin">("idle");
  const [target, setTarget] = useState<{ ip: string; brand?: Brand; name?: string } | null>(null);
  const [pin, setPin] = useState("");
  const [pinMsg, setPinMsg] = useState("");
  const [pairingId, setPairingId] = useState<string | null>(null);
  const [err, setErr] = useState<string | null>(null);
  const [hint, setHint] = useState<string | null>(null);
  const aborter = useRef<AbortController | null>(null);

  const scan = async () => {
    setScanning(true);
    setErr(null);
    try {
      const r = await api<{ devices: Found[]; serverAddresses: string[] }>("/api/discovery");
      setFound(r.devices);
      setServerIps(r.serverAddresses);
    } catch (e) {
      setErr((e as Error).message);
    } finally {
      setScanning(false);
    }
  };

  const finish = async (d: DeviceDTO, reused: boolean) => {
    await refreshDevices();
    await selectDevice(d.id);
    toast(reused ? `${d.name}: usando a autorização já salva` : `${d.name} pareada e salva`, "ok");
    setTab("remote");
    onClose();
  };

  const start = async (t: { ip: string; brand?: Brand; name?: string }) => {
    setErr(null);
    setTarget(t);
    setPhase("working");
    setHint(t.brand ? (WAIT_HINT[t.brand] ?? null) : "Se a TV exibir uma solicitação de autorização, aceite-a.");
    aborter.current = new AbortController();
    try {
      const r = await api<PairOutcome>("/api/devices", { body: { ip: t.ip, brand: t.brand, name: t.name } });
      if (r.status === "paired") return await finish(r.device, r.reused);
      setPairingId(r.pairingId);
      setPinMsg(r.message);
      setPhase("pin");
    } catch (e) {
      setErr((e as Error).message);
      setPhase("idle");
    }
  };

  const confirm = async () => {
    if (!pairingId) return;
    setErr(null);
    setPhase("working");
    try {
      const r = await api<PairOutcome>("/api/devices/pair/confirm", { body: { pairingId, pin } });
      if (r.status === "paired") return await finish(r.device, false);
    } catch (e) {
      setErr((e as Error).message);
      setPhase("pin");
    }
  };

  const cancelPin = async () => {
    if (pairingId) await api("/api/devices/pair/confirm", { body: { pairingId, cancel: true } }).catch(() => undefined);
    setPairingId(null);
    setPin("");
    setPhase("idle");
  };

  return (
    <Sheet title="Adicionar TV" onClose={onClose} wide>
      {phase === "working" && (
        <div className="flex flex-col items-center gap-4 py-8 text-center">
          <Spinner size={34} />
          <p className="font-semibold">Conectando a {target?.ip}…</p>
          <p className="muted max-w-xs text-sm">{hint}</p>
          <p className="muted text-xs">A autorização é pedida apenas desta vez e fica salva de forma criptografada.</p>
        </div>
      )}

      {phase === "pin" && (
        <div className="flex flex-col gap-4">
          <p className="text-sm">{pinMsg}</p>
          <input autoFocus className="input text-center text-2xl font-bold tracking-[0.3em]" value={pin} onChange={(e) => setPin(e.target.value)} placeholder="••••" inputMode="text" autoCapitalize="characters" onKeyDown={(e) => e.key === "Enter" && pin && confirm()} />
          {err && <p className="text-sm" style={{ color: "var(--danger)" }}>{err}</p>}
          <div className="flex gap-2">
            <button className="btn flex-1" onClick={cancelPin}>Cancelar</button>
            <button className="btn btn-primary flex-1" disabled={!pin.trim()} onClick={confirm}>Confirmar</button>
          </div>
        </div>
      )}

      {phase === "idle" && (
        <>
          <div className="mb-4 grid grid-cols-2 gap-1 rounded-2xl p-1" style={{ background: "var(--surface)" }}>
            {(["scan", "manual"] as const).map((m) => (
              <button key={m} onClick={() => setMode(m)} className="rounded-xl py-2 text-sm font-semibold transition" style={mode === m ? { background: "var(--surface-2)" } : { color: "var(--muted)" }}>
                {m === "scan" ? "Descobrir" : "IP manual"}
              </button>
            ))}
          </div>

          {mode === "scan" && (
            <div className="flex flex-col gap-3">
              <button className="btn btn-primary" onClick={scan} disabled={scanning}>
                {scanning ? <Spinner /> : <Radar size={18} />} {scanning ? "Procurando na rede…" : found ? "Procurar novamente" : "Procurar TVs"}
              </button>
              {found && found.length === 0 && (
                <div className="card-sm muted p-4 text-sm">
                  Nenhuma TV encontrada. O servidor do app precisa estar na <b>mesma rede Wi‑Fi/LAN</b> da TV
                  {serverIps.length ? ` (servidor: ${serverIps.join(", ")})` : ""}. Redes com isolamento de clientes bloqueiam a descoberta — use “IP manual”.
                </div>
              )}
              {found?.map((f) => (
                <button key={f.ip} className="card-sm flex items-center gap-3 p-3 text-left transition active:scale-[0.98]" onClick={() => start({ ip: f.ip, brand: f.brand })}>
                  <BrandBadge brand={f.brand} />
                  <div className="min-w-0 flex-1">
                    <p className="truncate font-semibold">{f.name}</p>
                    <p className="muted truncate text-xs">{BRAND_LABEL[f.brand]} · {f.model ?? "modelo desconhecido"} · {f.ip}</p>
                  </div>
                  <span className="chip">{f.saved ? "Salva" : "Parear"}</span>
                </button>
              ))}
            </div>
          )}

          {mode === "manual" && (
            <div className="flex flex-col gap-3">
              <label className="text-sm font-semibold" htmlFor="ip">Endereço IP da TV</label>
              <input id="ip" className="input" placeholder="192.168.0.20" inputMode="decimal" value={ip} onChange={(e) => setIp(e.target.value)} />
              <label className="text-sm font-semibold" htmlFor="brand">Marca / protocolo</label>
              <select id="brand" className="input" value={brand} onChange={(e) => setBrand(e.target.value as Brand | "")}>
                <option value="">Detectar automaticamente</option>
                {BRANDS.map((b) => (
                  <option key={b} value={b}>{BRAND_LABEL[b]}</option>
                ))}
              </select>
              <button className="btn btn-primary" disabled={!ip.trim()} onClick={() => start({ ip: ip.trim(), brand: brand || undefined })}>
                <Wifi size={18} /> Conectar e parear
              </button>
            </div>
          )}
          {err && <p className="mt-3 text-sm" style={{ color: "var(--danger)" }}>{err}</p>}
        </>
      )}
    </Sheet>
  );
}
