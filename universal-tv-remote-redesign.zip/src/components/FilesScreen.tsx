"use client";

import { File as FileIcon, FileText, Film, Image as ImageIcon, Link2, Music, Send, Trash2, UploadCloud, X } from "lucide-react";
import { useCallback, useEffect, useRef, useState } from "react";
import type { TransferDTO, TransferStatus } from "@/lib/commands";
import { isCastable, kindFromMime, progressPercent } from "@/lib/transfer";
import { apiCall, useStore } from "./store";
import { formatBytes, Spinner, timeAgo } from "./ui";

const STATUS_LABEL: Record<TransferStatus, string> = {
  uploading: "Enviando ao servidor",
  ready: "Pronto no servidor",
  sending: "Enviando à TV",
  sent: "Enviado à TV",
  failed: "Falhou",
  cancelled: "Cancelado",
};
const STATUS_COLOR: Partial<Record<TransferStatus, string>> = { sent: "var(--ok)", failed: "var(--danger)", cancelled: "var(--muted)", sending: "var(--warn)", uploading: "var(--warn)" };

function KindIcon({ kind, size = 20 }: { kind: string; size?: number }) {
  if (kind === "image") return <ImageIcon size={size} />;
  if (kind === "video") return <Film size={size} />;
  if (kind === "audio") return <Music size={size} />;
  if (kind === "document") return <FileText size={size} />;
  return <FileIcon size={size} />;
}

const PICKERS = [
  { label: "Fotos", accept: "image/*", icon: <ImageIcon size={18} /> },
  { label: "Vídeos", accept: "video/*", icon: <Film size={18} /> },
  { label: "Músicas", accept: "audio/*", icon: <Music size={18} /> },
  { label: "PDF / outros", accept: ".pdf,application/pdf,*/*", icon: <FileText size={18} /> },
];

export function FilesScreen() {
  const { devices, active, toast, api, has } = useStore();
  const [deviceId, setDeviceId] = useState<string | null>(null);
  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [progress, setProgress] = useState<{ pct: number; speed: number } | null>(null);
  const [stage, setStage] = useState<"idle" | "uploading" | "sending">("idle");
  const [history, setHistory] = useState<TransferDTO[]>([]);
  const [lanBase, setLanBase] = useState<string | null>(null);
  const xhr = useRef<XMLHttpRequest | null>(null);
  const input = useRef<HTMLInputElement>(null);
  const [accept, setAccept] = useState("*/*");

  const target = devices.find((d) => d.id === (deviceId ?? active?.id)) ?? null;
  const canCast = !!target?.capabilities.features.includes("cast");

  const load = useCallback(async () => {
    try {
      const r = await apiCall<{ transfers: TransferDTO[]; lanBase: string | null }>("/api/files");
      setHistory(r.transfers);
      setLanBase(r.lanBase);
    } catch {
      /* ignore */
    }
  }, []);
  useEffect(() => {
    void load();
    const t = setInterval(load, 5000);
    return () => clearInterval(t);
  }, [load]);
  useEffect(() => {
    if (!file) return setPreview(null);
    const u = URL.createObjectURL(file);
    setPreview(u);
    return () => URL.revokeObjectURL(u);
  }, [file]);

  const kind = file ? kindFromMime(file.type || "application/octet-stream", file.name) : null;

  const pick = (acc: string) => {
    setAccept(acc);
    setTimeout(() => input.current?.click(), 0);
  };

  const upload = (f: File): Promise<TransferDTO> =>
    new Promise((resolve, reject) => {
      const x = new XMLHttpRequest();
      xhr.current = x;
      const t0 = Date.now();
      x.open("POST", `/api/files?name=${encodeURIComponent(f.name)}&type=${encodeURIComponent(f.type || "application/octet-stream")}&size=${f.size}`);
      x.setRequestHeader("Content-Type", "application/octet-stream");
      x.upload.onprogress = (e) => {
        if (e.lengthComputable) setProgress({ pct: progressPercent(e.loaded, e.total), speed: e.loaded / Math.max(0.5, (Date.now() - t0) / 1000) });
      };
      x.onload = () => {
        try {
          const j = JSON.parse(x.responseText);
          x.status < 300 ? resolve(j.transfer) : reject(new Error(j.error || `Erro ${x.status}`));
        } catch {
          reject(new Error("Resposta inválida do servidor"));
        }
      };
      x.onerror = () => reject(new Error("Falha de rede durante o envio"));
      x.onabort = () => reject(new Error("Envio cancelado"));
      x.send(f);
    });

  const sendToTv = async (t: TransferDTO) => {
    if (!target) throw new Error("Escolha uma TV");
    return api<{ transfer: TransferDTO }>(`/api/files/${t.id}/send`, { body: { deviceId: target.id } });
  };

  const go = async () => {
    if (!file) return;
    setStage("uploading");
    setProgress({ pct: 0, speed: 0 });
    try {
      const t = await upload(file);
      const castable = isCastable(t.kind);
      if (castable && canCast && target) {
        setStage("sending");
        await sendToTv(t);
        toast(`“${t.name}” enviado para ${target.name}`, "ok");
      } else if (!castable) {
        toast("Arquivo hospedado na rede local. Copie o link no histórico.", "info");
      } else {
        toast("Arquivo no servidor, mas esta TV não tem receptor de mídia.", "info");
      }
      setFile(null);
    } catch (e) {
      toast((e as Error).message, "err");
    } finally {
      setStage("idle");
      setProgress(null);
      xhr.current = null;
      void load();
    }
  };

  const cancel = () => xhr.current?.abort();

  const act = async (fn: () => Promise<unknown>, ok?: string) => {
    try {
      await fn();
      if (ok) toast(ok, "ok");
    } catch (e) {
      toast((e as Error).message, "err");
    }
    void load();
  };

  const link = (t: TransferDTO) => `${lanBase ?? location.origin}/api/files/${t.id}/raw/${encodeURIComponent(t.name)}`;
  const copy = async (t: TransferDTO) => {
    try {
      await navigator.clipboard.writeText(link(t));
      toast("Link copiado", "ok");
    } catch {
      toast(link(t), "info");
    }
  };

  return (
    <div className="flex flex-col gap-5">
      <section className="glass p-4">
        <label className="muted text-xs font-bold uppercase tracking-widest" htmlFor="target">Enviar para</label>
        <select id="target" className="input mt-2" value={target?.id ?? ""} onChange={(e) => setDeviceId(e.target.value)}>
          {devices.length === 0 && <option value="">Nenhuma TV salva</option>}
          {devices.map((d) => (
            <option key={d.id} value={d.id}>{d.name} — {d.capabilities.features.includes("cast") ? "recebe mídia" : "sem receptor de mídia"}</option>
          ))}
        </select>
        {target && !canCast && (
          <p className="mt-3 text-xs" style={{ color: "var(--warn)" }}>
            Esta TV não expõe um receptor DLNA/Roku. Fotos, vídeos e músicas só chegam nela se houver um receptor ativo (ative “Mídia/DLNA” nas configurações da TV) ou um app receptor companheiro. Você ainda pode hospedar o arquivo e abrir o link no navegador da TV.
          </p>
        )}
      </section>

      <section className="glass p-4">
        <input ref={input} type="file" hidden accept={accept} onChange={(e) => setFile(e.target.files?.[0] ?? null)} />
        {!file ? (
          <div
            className="flex flex-col items-center gap-4 rounded-2xl border-2 border-dashed p-6 text-center"
            style={{ borderColor: "var(--border)" }}
            onDragOver={(e) => e.preventDefault()}
            onDrop={(e) => {
              e.preventDefault();
              setFile(e.dataTransfer.files?.[0] ?? null);
            }}
          >
            <UploadCloud size={34} style={{ color: "var(--accent-2)" }} />
            <p className="text-sm font-semibold">Escolha o que enviar</p>
            <div className="grid w-full grid-cols-2 gap-2">
              {PICKERS.map((p) => (
                <button key={p.label} className="btn" onClick={() => pick(p.accept)}>{p.icon} {p.label}</button>
              ))}
            </div>
          </div>
        ) : (
          <div className="flex flex-col gap-3">
            <div className="flex items-center gap-3">
              <div className="flex h-20 w-20 shrink-0 items-center justify-center overflow-hidden rounded-2xl" style={{ background: "var(--surface-2)" }}>
                {kind === "image" && preview ? (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img src={preview} alt="Pré-visualização" className="h-full w-full object-cover" />
                ) : kind === "video" && preview ? (
                  <video src={preview} className="h-full w-full object-cover" muted preload="metadata" />
                ) : (
                  <KindIcon kind={kind ?? "other"} size={30} />
                )}
              </div>
              <div className="min-w-0 flex-1">
                <p className="truncate font-semibold">{file.name}</p>
                <p className="muted text-xs">{formatBytes(file.size)} · {file.type || "tipo desconhecido"}</p>
              </div>
              {stage === "idle" && <button className="btn !p-2" onClick={() => setFile(null)} aria-label="Remover"><X size={16} /></button>}
            </div>
            {kind === "audio" && preview && <audio src={preview} controls className="w-full" />}
            {kind === "document" && file.type === "application/pdf" && <p className="muted text-xs">PDF: a TV não abre este formato por DLNA. O arquivo será hospedado na rede para abrir por link.</p>}

            {stage !== "idle" && progress && (
              <div>
                <div className="mb-1 flex justify-between text-xs font-semibold">
                  <span>{stage === "uploading" ? "Enviando ao servidor…" : "Enviando à TV…"}</span>
                  <span>{progress.pct}% · {formatBytes(progress.speed)}/s</span>
                </div>
                <div className="progress"><i style={{ width: `${progress.pct}%` }} /></div>
              </div>
            )}
            <div className="flex gap-2">
              {stage === "uploading" ? (
                <button className="btn btn-danger flex-1" onClick={cancel}><X size={16} /> Cancelar envio</button>
              ) : stage === "sending" ? (
                <button className="btn flex-1" disabled><Spinner size={16} /> Enviando à TV…</button>
              ) : (
                <button className="btn btn-primary flex-1" onClick={go} disabled={!target}>
                  <Send size={16} /> {isCastable(kind ?? "other") && canCast ? `Enviar para ${target?.name ?? "TV"}` : "Hospedar na rede"}
                </button>
              )}
            </div>
          </div>
        )}
      </section>

      <section>
        <h2 className="muted mb-2 text-xs font-bold uppercase tracking-widest">Histórico de transferências</h2>
        {history.length === 0 ? (
          <p className="card-sm muted p-4 text-sm">Nenhuma transferência ainda.</p>
        ) : (
          <div className="flex flex-col gap-2">
            {history.map((t) => {
              const dev = devices.find((d) => d.id === t.deviceId);
              const busy = t.status === "sending" || t.status === "uploading";
              return (
                <div key={t.id} className="card-sm p-3">
                  <div className="flex items-center gap-3">
                    <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl" style={{ background: "var(--surface-2)" }}><KindIcon kind={t.kind} /></div>
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-sm font-semibold">{t.name}</p>
                      <p className="muted truncate text-xs">{formatBytes(t.size)} · {timeAgo(t.createdAt)}{dev ? ` · ${dev.name}` : ""}</p>
                    </div>
                    <span className="chip" style={{ color: STATUS_COLOR[t.status] }}>{STATUS_LABEL[t.status]}</span>
                  </div>
                  {t.error && t.status !== "sent" && <p className="mt-2 text-xs" style={{ color: "var(--danger)" }}>{t.error}</p>}
                  <div className="mt-2 flex flex-wrap gap-2">
                    {["ready", "sent", "failed"].includes(t.status) && isCastable(t.kind) && target && (t.status !== "failed" || t.received > 0 || true) && (
                      <button className="btn !px-3 !py-1.5 text-xs" disabled={!canCast} onClick={() => act(() => sendToTv(t), "Enviado à TV")}>
                        <Send size={13} /> {t.status === "sent" ? "Reenviar" : "Enviar"}
                      </button>
                    )}
                    {["ready", "sent"].includes(t.status) && <button className="btn !px-3 !py-1.5 text-xs" onClick={() => copy(t)}><Link2 size={13} /> Copiar link</button>}
                    {busy && t.status === "sending" && <button className="btn !px-3 !py-1.5 text-xs" onClick={() => act(() => api(`/api/files/${t.id}/cancel`, { body: {} }), "Cancelado")}><X size={13} /> Cancelar</button>}
                    {!busy && <button className="btn btn-danger !px-3 !py-1.5 text-xs" onClick={() => act(() => api(`/api/files/${t.id}`, { method: "DELETE" }))}><Trash2 size={13} /> Excluir</button>}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </section>

      <section className="card-sm muted p-4 text-xs leading-relaxed">
        <b style={{ color: "var(--text)" }}>Como funciona:</b> o arquivo vai do celular para este servidor e a TV o busca pela rede local (DLNA/UPnP, ou Roku Media Player).
        Só fotos, vídeos e músicas são reproduzíveis dessa forma — nenhuma marca recebe PDFs/arquivos arbitrários por protocolo oficial; eles ficam acessíveis por link.
        TVs sem DLNA exigem um app receptor instalado na própria TV{has("cast") ? "" : " (não incluído nesta versão)"}.
      </section>
    </div>
  );
}
