"use client";

import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import type { Command, DeviceDTO, Feature, StatusDTO } from "@/lib/commands";

export type Tab = "home" | "remote" | "apps" | "files" | "media" | "devices";

export interface Settings {
  theme: "dark" | "light" | "system";
  haptics: boolean;
  show: { shortcuts: boolean; channels: boolean; numpad: boolean; colors: boolean; playback: boolean; text: boolean };
  shortcuts: Command[];
}

const DEFAULT_SETTINGS: Settings = {
  theme: "dark",
  haptics: true,
  show: { shortcuts: true, channels: true, numpad: true, colors: true, playback: true, text: true },
  shortcuts: ["source", "settings", "guide", "info"],
};

export type DeviceWithStatus = DeviceDTO & { status?: StatusDTO };

interface Toast {
  id: number;
  text: string;
  kind: "ok" | "err" | "info";
}

interface Store {
  ready: boolean;
  tab: Tab;
  setTab: (t: Tab) => void;
  devices: DeviceWithStatus[];
  active: DeviceWithStatus | null;
  status: StatusDTO | null;
  connected: boolean;
  selectDevice: (id: string) => Promise<void>;
  refreshDevices: () => Promise<void>;
  reconnect: (force?: boolean) => Promise<void>;
  can: (c: Command) => boolean;
  has: (f: Feature) => boolean;
  send: (c: Command) => Promise<boolean>;
  lastCommand: { cmd: Command; ok: boolean; at: number } | null;
  api: <T = Record<string, unknown>>(url: string, init?: { method?: string; body?: unknown }) => Promise<T>;
  toast: (text: string, kind?: Toast["kind"]) => void;
  settings: Settings;
  setSettings: (s: Settings) => void;
  vibrate: (ms?: number) => void;
  addOpen: boolean;
  setAddOpen: (v: boolean) => void;
  settingsOpen: boolean;
  setSettingsOpen: (v: boolean) => void;
}

const Ctx = createContext<Store | null>(null);

export function useStore(): Store {
  const s = useContext(Ctx);
  if (!s) throw new Error("StoreProvider ausente");
  return s;
}

export async function apiCall<T = Record<string, unknown>>(url: string, init?: { method?: string; body?: unknown; signal?: AbortSignal }): Promise<T> {
  const res = await fetch(url, {
    method: init?.method ?? (init?.body !== undefined ? "POST" : "GET"),
    headers: init?.body !== undefined ? { "Content-Type": "application/json" } : undefined,
    body: init?.body !== undefined ? JSON.stringify(init.body) : undefined,
    signal: init?.signal,
    cache: "no-store",
  });
  const data = (await res.json().catch(() => ({}))) as T & { error?: string };
  if (!res.ok) throw new Error(data.error || `Erro ${res.status}`);
  return data;
}

export function StoreProvider({ children }: { children: ReactNode }) {
  const [ready, setReady] = useState(false);
  const [tab, setTabState] = useState<Tab>("home");
  const [devices, setDevices] = useState<DeviceWithStatus[]>([]);
  const [activeId, setActiveId] = useState<string | null>(null);
  const [status, setStatus] = useState<StatusDTO | null>(null);
  const [toasts, setToasts] = useState<Toast[]>([]);
  const [settings, setSettingsState] = useState<Settings>(DEFAULT_SETTINGS);
  const [lastCommand, setLastCommand] = useState<Store["lastCommand"]>(null);
  const [addOpen, setAddOpen] = useState(false);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const toastId = useRef(0);
  const activeRef = useRef<string | null>(null);
  activeRef.current = activeId;

  const toast = useCallback((text: string, kind: Toast["kind"] = "info") => {
    const id = ++toastId.current;
    setToasts((t) => [...t.slice(-2), { id, text, kind }]);
    setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), 3200);
  }, []);

  // ---- settings (persisted locally)
  useEffect(() => {
    try {
      const raw = JSON.parse(localStorage.getItem("utv-settings") || "{}");
      setSettingsState({ ...DEFAULT_SETTINGS, ...raw, show: { ...DEFAULT_SETTINGS.show, ...(raw.show ?? {}) } });
      const t = localStorage.getItem("utv-tab") as Tab | null;
      if (t) setTabState(t);
    } catch {
      /* defaults */
    }
  }, []);

  const applyTheme = useCallback((theme: Settings["theme"]) => {
    const t = theme === "system" ? (matchMedia("(prefers-color-scheme: light)").matches ? "light" : "dark") : theme;
    document.documentElement.dataset.theme = t;
  }, []);

  const setSettings = useCallback(
    (s: Settings) => {
      setSettingsState(s);
      localStorage.setItem("utv-settings", JSON.stringify(s));
      applyTheme(s.theme);
    },
    [applyTheme],
  );

  const setTab = useCallback((t: Tab) => {
    setTabState(t);
    localStorage.setItem("utv-tab", t);
  }, []);

  // ---- devices
  const refreshDevices = useCallback(async () => {
    try {
      const { devices: list } = await apiCall<{ devices: DeviceWithStatus[] }>("/api/devices");
      setDevices(list);
      return;
    } catch {
      /* offline: keep last list */
    }
  }, []);

  const active = useMemo(() => devices.find((d) => d.id === activeId) ?? null, [devices, activeId]);

  const reconnect = useCallback(
    async (force = false) => {
      const id = activeRef.current;
      if (!id) return;
      try {
        const r = await apiCall<{ status: StatusDTO }>(`/api/devices/${id}/connect`, { body: { force } });
        setStatus(r.status);
        refreshDevices();
      } catch (e) {
        toast((e as Error).message, "err");
      }
    },
    [refreshDevices, toast],
  );

  const selectDevice = useCallback(
    async (id: string) => {
      setActiveId(id);
      activeRef.current = id;
      localStorage.setItem("utv-active", id);
      setStatus({ state: "connecting", error: null, latencyMs: null, attempts: 0, nextRetryInMs: null });
      await reconnect(false);
    },
    [reconnect],
  );

  // initial load: restore last device and reconnect with the stored credential (no new pairing)
  useEffect(() => {
    (async () => {
      let list: DeviceWithStatus[] = [];
      try {
        list = (await apiCall<{ devices: DeviceWithStatus[] }>("/api/devices")).devices;
        setDevices(list);
      } catch {
        /* server unreachable */
      }
      const saved = localStorage.getItem("utv-active");
      const pick = list.find((d) => d.id === saved) ?? list.find((d) => d.favorite) ?? list[0];
      setReady(true);
      if (pick) {
        setActiveId(pick.id);
        activeRef.current = pick.id;
        if (pick.status) setStatus(pick.status);
        void apiCall<{ status: StatusDTO }>(`/api/devices/${pick.id}/connect`, { body: {} })
          .then((r) => setStatus(r.status))
          .catch(() => undefined);
      }
    })();
  }, []);

  // poll status (connection health) + list
  useEffect(() => {
    const t = setInterval(async () => {
      const id = activeRef.current;
      if (id && document.visibilityState === "visible") {
        try {
          const r = await apiCall<{ status: StatusDTO }>(`/api/devices/${id}/status`);
          setStatus(r.status);
        } catch {
          setStatus((s) => (s ? { ...s, state: "error", error: "Servidor inacessível" } : s));
        }
      }
    }, 4000);
    const l = setInterval(() => document.visibilityState === "visible" && refreshDevices(), 20000);
    return () => {
      clearInterval(t);
      clearInterval(l);
    };
  }, [refreshDevices]);

  // network recovery: when the phone's Wi‑Fi returns or the app comes back to the foreground
  useEffect(() => {
    const onBack = () => {
      if (document.visibilityState === "visible") void reconnect(false);
    };
    window.addEventListener("online", onBack);
    document.addEventListener("visibilitychange", onBack);
    return () => {
      window.removeEventListener("online", onBack);
      document.removeEventListener("visibilitychange", onBack);
    };
  }, [reconnect]);

  const vibrate = useCallback(
    (ms = 12) => {
      if (settings.haptics && typeof navigator !== "undefined" && "vibrate" in navigator) navigator.vibrate(ms);
    },
    [settings.haptics],
  );

  const can = useCallback((c: Command) => !!active?.capabilities.commands.includes(c), [active]);
  const has = useCallback((f: Feature) => !!active?.capabilities.features.includes(f), [active]);

  const send = useCallback(
    async (cmd: Command) => {
      const id = activeRef.current;
      if (!id) {
        toast("Selecione ou adicione uma TV primeiro", "err");
        return false;
      }
      vibrate();
      try {
        await apiCall(`/api/devices/${id}/command`, { body: { command: cmd } });
        setLastCommand({ cmd, ok: true, at: Date.now() });
        return true;
      } catch (e) {
        setLastCommand({ cmd, ok: false, at: Date.now() });
        toast((e as Error).message, "err");
        return false;
      }
    },
    [toast, vibrate],
  );

  const connected = status?.state === "connected";

  const value: Store = {
    ready,
    tab,
    setTab,
    devices,
    active,
    status,
    connected,
    selectDevice,
    refreshDevices,
    reconnect,
    can,
    has,
    send,
    lastCommand,
    api: apiCall as Store["api"],
    toast,
    settings,
    setSettings,
    vibrate,
    addOpen,
    setAddOpen,
    settingsOpen,
    setSettingsOpen,
  };

  return (
    <Ctx.Provider value={value}>
      {children}
      <div className="pointer-events-none fixed inset-x-0 top-3 z-[100] flex flex-col items-center gap-2 px-4">
        {toasts.map((t) => (
          <div
            key={t.id}
            role="status"
            className="glass rise pointer-events-auto max-w-sm px-4 py-2.5 text-sm font-medium"
            style={{ borderColor: t.kind === "err" ? "var(--danger)" : t.kind === "ok" ? "var(--ok)" : undefined }}
          >
            {t.text}
          </div>
        ))}
      </div>
    </Ctx.Provider>
  );
}
