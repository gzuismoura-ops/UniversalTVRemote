"use client";

import { COMMANDS, COMMAND_LABEL, type Command } from "@/lib/commands";
import { useStore, type Settings } from "./store";
import { Sheet } from "./ui";

const SECTIONS: { key: keyof Settings["show"]; label: string }[] = [
  { key: "shortcuts", label: "Atalhos personalizados" },
  { key: "channels", label: "Canais" },
  { key: "playback", label: "Reprodução" },
  { key: "colors", label: "Teclas coloridas" },
  { key: "numpad", label: "Teclado numérico" },
  { key: "text", label: "Teclado e voz" },
];

const SHORTCUT_CANDIDATES: Command[] = COMMANDS.filter((c) => !["up", "down", "left", "right", "ok", "back", "volUp", "volDown", "chUp", "chDown"].includes(c) && !c.startsWith("num"));

function Toggle({ on, onChange, label }: { on: boolean; onChange: (v: boolean) => void; label: string }) {
  return (
    <button role="switch" aria-checked={on} onClick={() => onChange(!on)} className="flex w-full items-center justify-between py-2.5 text-left text-sm font-medium">
      {label}
      <span className="relative h-6 w-11 rounded-full transition" style={{ background: on ? "var(--accent)" : "var(--surface-2)" }}>
        <i className="absolute top-0.5 h-5 w-5 rounded-full bg-white transition-all" style={{ left: on ? 22 : 2 }} />
      </span>
    </button>
  );
}

export function SettingsSheet({ onClose }: { onClose: () => void }) {
  const { settings, setSettings } = useStore();
  const toggleShortcut = (c: Command) => {
    const has = settings.shortcuts.includes(c);
    const next = has ? settings.shortcuts.filter((x) => x !== c) : [...settings.shortcuts, c].slice(-6);
    setSettings({ ...settings, shortcuts: next });
  };
  return (
    <Sheet title="Configurações" onClose={onClose}>
      <div className="flex flex-col gap-5">
        <section>
          <h3 className="muted mb-2 text-xs font-bold uppercase tracking-widest">Tema</h3>
          <div className="grid grid-cols-3 gap-1 rounded-2xl p-1" style={{ background: "var(--surface)" }}>
            {(["dark", "light", "system"] as const).map((t) => (
              <button key={t} onClick={() => setSettings({ ...settings, theme: t })} className="rounded-xl py-2 text-sm font-semibold" style={settings.theme === t ? { background: "var(--surface-2)" } : { color: "var(--muted)" }}>
                {t === "dark" ? "Escuro" : t === "light" ? "Claro" : "Sistema"}
              </button>
            ))}
          </div>
        </section>
        <section>
          <h3 className="muted mb-1 text-xs font-bold uppercase tracking-widest">Feedback</h3>
          <Toggle on={settings.haptics} onChange={(v) => setSettings({ ...settings, haptics: v })} label="Vibração ao tocar nas teclas" />
        </section>
        <section>
          <h3 className="muted mb-1 text-xs font-bold uppercase tracking-widest">Layout do controle</h3>
          {SECTIONS.map((s) => (
            <Toggle key={s.key} on={settings.show[s.key]} label={s.label} onChange={(v) => setSettings({ ...settings, show: { ...settings.show, [s.key]: v } })} />
          ))}
        </section>
        <section>
          <h3 className="muted mb-2 text-xs font-bold uppercase tracking-widest">Atalhos (até 6)</h3>
          <div className="flex flex-wrap gap-2">
            {SHORTCUT_CANDIDATES.map((c) => (
              <button key={c} onClick={() => toggleShortcut(c)} className="chip" style={settings.shortcuts.includes(c) ? { background: "var(--accent)", color: "#fff" } : undefined}>
                {COMMAND_LABEL[c]}
              </button>
            ))}
          </div>
          <p className="muted mt-2 text-xs">Só aparecem no controle os atalhos que a TV conectada realmente suporta.</p>
        </section>
        <section className="card-sm muted p-3 text-xs leading-relaxed">
          Idioma: Português (Brasil). Credenciais de pareamento são guardadas criptografadas (AES-256-GCM) no servidor e nunca são enviadas ao navegador.
        </section>
      </div>
    </Sheet>
  );
}
