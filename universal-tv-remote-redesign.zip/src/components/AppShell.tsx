"use client";

import { AppWindow, Gamepad2, Home, MonitorPlay, Settings, Share2, Tv } from "lucide-react";
import { AddDeviceSheet } from "./AddDeviceSheet";
import { AppsScreen } from "./AppsScreen";
import { DevicesScreen } from "./DevicesScreen";
import { FilesScreen } from "./FilesScreen";
import { HomeScreen } from "./HomeScreen";
import { MediaScreen } from "./MediaScreen";
import { RemoteScreen } from "./RemoteScreen";
import { SettingsSheet } from "./SettingsSheet";
import { StoreProvider, useStore, type Tab } from "./store";
import { Spinner, StatusChip } from "./ui";

const NAV: { id: Tab; label: string; icon: typeof Home }[] = [
  { id: "home", label: "Início", icon: Home },
  { id: "remote", label: "Controle", icon: Gamepad2 },
  { id: "apps", label: "Apps", icon: AppWindow },
  { id: "files", label: "Arquivos", icon: Share2 },
  { id: "media", label: "Mídia", icon: MonitorPlay },
  { id: "devices", label: "TVs", icon: Tv },
];

const TITLES: Record<Tab, string> = { home: "Início", remote: "Controle remoto", apps: "Aplicativos", files: "Compartilhar arquivos", media: "Central de mídia", devices: "Dispositivos" };

function Shell() {
  const { ready, tab, setTab, active, status, addOpen, setAddOpen, settingsOpen, setSettingsOpen } = useStore();

  return (
    <div className="mx-auto flex min-h-dvh w-full max-w-5xl">
      {/* Side navigation (tablets / desktop) */}
      <nav aria-label="Navegação principal" className="sticky top-0 hidden h-dvh w-60 shrink-0 flex-col gap-1 p-5 md:flex">
        <div className="mb-6 flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-2xl" style={{ background: "linear-gradient(135deg, var(--accent), var(--accent-2))" }}>
            <Gamepad2 size={20} color="#fff" />
          </div>
          <span className="text-sm font-extrabold leading-tight">Controle<br />Universal</span>
        </div>
        {NAV.map((n) => (
          <button key={n.id} onClick={() => setTab(n.id)} className="flex items-center gap-3 rounded-2xl px-4 py-3 text-sm font-semibold transition" style={tab === n.id ? { background: "var(--surface-2)" } : { color: "var(--muted)" }}>
            <n.icon size={18} /> {n.label}
          </button>
        ))}
        <button onClick={() => setSettingsOpen(true)} className="mt-auto flex items-center gap-3 rounded-2xl px-4 py-3 text-sm font-semibold" style={{ color: "var(--muted)" }}>
          <Settings size={18} /> Configurações
        </button>
      </nav>

      <div className="flex min-w-0 flex-1 flex-col">
        <header className="sticky top-0 z-30 flex items-center gap-3 px-4 pb-3 pt-[max(0.9rem,env(safe-area-inset-top))] backdrop-blur-xl" style={{ background: "color-mix(in srgb, var(--bg) 70%, transparent)" }}>
          <h1 className="flex-1 text-lg font-extrabold">{TITLES[tab]}</h1>
          {active && tab !== "home" && tab !== "devices" && (
            <button onClick={() => setTab("devices")} className="flex items-center gap-2 text-xs font-semibold" aria-label="Trocar de TV">
              <span className="max-w-[110px] truncate">{active.name}</span>
              <StatusChip state={status?.state} />
            </button>
          )}
          <button className="btn !p-2 md:hidden" onClick={() => setSettingsOpen(true)} aria-label="Configurações"><Settings size={18} /></button>
        </header>

        <main className="flex-1 px-4 pb-32 pt-2 md:pb-10">
          {!ready ? (
            <div className="flex justify-center py-24"><Spinner size={32} /></div>
          ) : (
            <div key={tab} className="rise mx-auto w-full max-w-lg md:max-w-xl">
              {tab === "home" && <HomeScreen />}
              {tab === "remote" && <RemoteScreen />}
              {tab === "apps" && <AppsScreen />}
              {tab === "files" && <FilesScreen />}
              {tab === "media" && <MediaScreen />}
              {tab === "devices" && <DevicesScreen />}
            </div>
          )}
        </main>
      </div>

      {/* Bottom navigation (phones) */}
      <nav aria-label="Navegação principal" className="glass fixed inset-x-3 bottom-[max(0.75rem,env(safe-area-inset-bottom))] z-40 grid grid-cols-6 gap-1 rounded-[26px] p-1.5 md:hidden">
        {NAV.map((n) => (
          <button key={n.id} onClick={() => setTab(n.id)} aria-label={n.label} aria-current={tab === n.id ? "page" : undefined} className="flex flex-col items-center gap-0.5 rounded-2xl py-2 text-[10px] font-semibold transition" style={tab === n.id ? { background: "linear-gradient(135deg, var(--accent), color-mix(in srgb, var(--accent-2) 70%, var(--accent)))", color: "#fff" } : { color: "var(--muted)" }}>
            <n.icon size={19} />
            {n.label}
          </button>
        ))}
      </nav>

      {addOpen && <AddDeviceSheet onClose={() => setAddOpen(false)} />}
      {settingsOpen && <SettingsSheet onClose={() => setSettingsOpen(false)} />}
    </div>
  );
}

export function AppShell() {
  return (
    <StoreProvider>
      <Shell />
    </StoreProvider>
  );
}
