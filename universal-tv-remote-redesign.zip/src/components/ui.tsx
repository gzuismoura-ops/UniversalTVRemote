"use client";

import { X } from "lucide-react";
import { useEffect, type ReactNode } from "react";
import { BRAND_LABEL, type Brand, type StatusDTO } from "@/lib/commands";

export const BRAND_COLOR: Record<Brand, string> = {
  lg: "#a50034",
  samsung: "#1428a0",
  sony: "#111111",
  androidtv: "#3ddc84",
  roku: "#6c3c97",
  philips: "#0b5ed7",
  panasonic: "#0041c0",
  vizio: "#e11d48",
  chromecast: "#ea4335",
  dlna: "#0ea5e9",
};

export function BrandBadge({ brand, size = 44 }: { brand: Brand; size?: number }) {
  const letters: Record<Brand, string> = { lg: "LG", samsung: "SA", sony: "SO", androidtv: "TV", roku: "RK", philips: "PH", panasonic: "PA", vizio: "VZ", chromecast: "CC", dlna: "UP" };
  return (
    <div
      aria-label={BRAND_LABEL[brand]}
      className="flex shrink-0 items-center justify-center rounded-2xl font-bold text-white"
      style={{ width: size, height: size, background: `linear-gradient(135deg, ${BRAND_COLOR[brand]}, color-mix(in srgb, ${BRAND_COLOR[brand]} 40%, #000))`, fontSize: size * 0.34 }}
    >
      {letters[brand]}
    </div>
  );
}

export const STATE_LABEL: Record<StatusDTO["state"], string> = {
  connected: "Conectada",
  connecting: "Conectando…",
  reconnecting: "Reconectando…",
  disconnected: "Desconectada",
  "needs-pairing": "Pareamento necessário",
  error: "Sem conexão",
};

export function StatusChip({ state }: { state?: StatusDTO["state"] }) {
  const s = state ?? "disconnected";
  const cls = s === "connected" ? "ok" : s === "connecting" || s === "reconnecting" ? "warn" : s === "disconnected" ? "" : "err";
  return (
    <span className="chip">
      <i className={`dot ${cls}`} />
      {STATE_LABEL[s]}
    </span>
  );
}

export function Sheet({ title, onClose, children, wide }: { title: string; onClose: () => void; children: ReactNode; wide?: boolean }) {
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", onKey);
    document.body.style.overflow = "hidden";
    return () => {
      window.removeEventListener("keydown", onKey);
      document.body.style.overflow = "";
    };
  }, [onClose]);
  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center sm:items-center" role="dialog" aria-modal="true" aria-label={title}>
      <button aria-label="Fechar" className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={onClose} />
      <div className={`glass sheet relative max-h-[92dvh] w-full overflow-y-auto rounded-b-none p-5 sm:rounded-b-3xl ${wide ? "sm:max-w-xl" : "sm:max-w-md"}`} style={{ background: "var(--surface-solid)" }}>
        <div className="mb-4 flex items-center justify-between">
          <h2 className="text-lg font-bold">{title}</h2>
          <button className="btn !p-2" onClick={onClose} aria-label="Fechar">
            <X size={18} />
          </button>
        </div>
        {children}
      </div>
    </div>
  );
}

export function Empty({ icon, title, text, action }: { icon: ReactNode; title: string; text: string; action?: ReactNode }) {
  return (
    <div className="glass rise flex flex-col items-center gap-3 px-6 py-10 text-center">
      <div className="flex h-14 w-14 items-center justify-center rounded-2xl" style={{ background: "var(--surface-2)" }}>
        {icon}
      </div>
      <h3 className="text-base font-bold">{title}</h3>
      <p className="muted max-w-sm text-sm">{text}</p>
      {action}
    </div>
  );
}

export function AppIcon({ deviceId, ip, icon, name, size = 56 }: { deviceId: string; ip: string; icon: string | null; name: string; size?: number }) {
  const proxied = icon && (() => {
    try {
      return new URL(icon).hostname === ip ? `/api/devices/${deviceId}/icon?u=${encodeURIComponent(icon)}` : null;
    } catch {
      return null;
    }
  })();
  return proxied ? (
    // eslint-disable-next-line @next/next/no-img-element
    <img src={proxied} alt="" width={size} height={size} loading="lazy" className="rounded-2xl object-cover" style={{ width: size, height: size, background: "var(--surface-2)" }} />
  ) : (
    <div className="flex items-center justify-center rounded-2xl font-bold text-white" style={{ width: size, height: size, background: `hsl(${hash(name) % 360} 55% 42%)`, fontSize: size * 0.4 }}>
      {name.trim().charAt(0).toUpperCase() || "?"}
    </div>
  );
}

function hash(s: string) {
  let h = 0;
  for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) | 0;
  return Math.abs(h);
}

export function timeAgo(iso: string | null): string {
  if (!iso) return "nunca";
  const s = Math.max(0, (Date.now() - new Date(iso).getTime()) / 1000);
  if (s < 60) return "agora há pouco";
  if (s < 3600) return `há ${Math.floor(s / 60)} min`;
  if (s < 86400) return `há ${Math.floor(s / 3600)} h`;
  return `há ${Math.floor(s / 86400)} d`;
}

export function formatBytes(n: number): string {
  if (n < 1024) return `${n} B`;
  if (n < 1024 ** 2) return `${(n / 1024).toFixed(1)} KB`;
  if (n < 1024 ** 3) return `${(n / 1024 ** 2).toFixed(1)} MB`;
  return `${(n / 1024 ** 3).toFixed(2)} GB`;
}

export function Spinner({ size = 18 }: { size?: number }) {
  return <span className="spin inline-block rounded-full border-2 border-current border-t-transparent" style={{ width: size, height: size }} />;
}
