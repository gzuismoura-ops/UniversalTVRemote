"use client";

import { AppWindow, RefreshCw, Search, Star } from "lucide-react";
import { useCallback, useEffect, useMemo, useState } from "react";
import type { ActivityDTO, AppDTO } from "@/lib/commands";
import { useStore } from "./store";
import { AppIcon, Empty, Spinner } from "./ui";

export function AppsScreen() {
  const { active, api, toast, has, connected, setAddOpen } = useStore();
  const [apps, setApps] = useState<AppDTO[]>([]);
  const [favs, setFavs] = useState<AppDTO[]>([]);
  const [recent, setRecent] = useState<ActivityDTO[]>([]);
  const [q, setQ] = useState("");
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  const load = useCallback(async () => {
    if (!active) return;
    setLoading(true);
    setErr(null);
    try {
      const [f, r] = await Promise.all([
        api<{ favorites: AppDTO[] }>(`/api/devices/${active.id}/favorites`),
        api<{ activities: ActivityDTO[] }>(`/api/activities?deviceId=${active.id}`),
      ]);
      setFavs(f.favorites);
      setRecent(r.activities.filter((a) => a.type === "app"));
      if (active.capabilities.features.includes("apps")) {
        const a = await api<{ apps: AppDTO[] }>(`/api/devices/${active.id}/apps`);
        setApps(a.apps.sort((x, y) => x.name.localeCompare(y.name, "pt-BR")));
      } else setApps([]);
    } catch (e) {
      setErr((e as Error).message);
    } finally {
      setLoading(false);
    }
  }, [active, api]);

  useEffect(() => {
    void load();
  }, [load, connected]);

  const filtered = useMemo(() => apps.filter((a) => a.name.toLowerCase().includes(q.toLowerCase())), [apps, q]);
  const favIds = new Set(favs.map((f) => f.id));
  const recentApps = useMemo(() => {
    const seen = new Set<string>();
    const out: AppDTO[] = [];
    for (const a of recent) {
      if (a.refId && !seen.has(a.refId)) {
        seen.add(a.refId);
        out.push({ id: a.refId, name: a.label, icon: a.icon });
      }
    }
    return out.slice(0, 8);
  }, [recent]);

  if (!active) return <Empty icon={<AppWindow />} title="Nenhuma TV selecionada" text="Adicione uma TV para ver seus aplicativos." action={<button className="btn btn-primary" onClick={() => setAddOpen(true)}>Adicionar TV</button>} />;
  if (!has("apps")) return <Empty icon={<AppWindow />} title="Apps indisponíveis" text={`O protocolo desta TV (${active.brand}) não permite listar ou abrir aplicativos remotamente.`} />;

  const launch = async (a: AppDTO) => {
    try {
      await api(`/api/devices/${active.id}/launch`, { body: { appId: a.id, name: a.name, icon: a.icon } });
      toast(`Abrindo ${a.name}`, "ok");
      void load();
    } catch (e) {
      toast((e as Error).message, "err");
    }
  };
  const toggleFav = async (a: AppDTO) => {
    await api(`/api/devices/${active.id}/favorites`, { body: { appId: a.id, name: a.name, icon: a.icon } }).catch((e) => toast(e.message, "err"));
    const f = await api<{ favorites: AppDTO[] }>(`/api/devices/${active.id}/favorites`);
    setFavs(f.favorites);
  };

  const Tile = ({ a }: { a: AppDTO }) => (
    <div className="relative flex flex-col items-center gap-1.5">
      <button className="transition active:scale-90" onClick={() => launch(a)} aria-label={`Abrir ${a.name}`}>
        <AppIcon deviceId={active.id} ip={active.ip} icon={a.icon} name={a.name} size={64} />
      </button>
      <button aria-label="Favoritar" className="absolute -right-1 -top-1 rounded-full p-1" style={{ background: "var(--surface-solid)", border: "1px solid var(--border)" }} onClick={() => toggleFav(a)}>
        <Star size={12} fill={favIds.has(a.id) ? "#fbbf24" : "none"} color={favIds.has(a.id) ? "#fbbf24" : "currentColor"} />
      </button>
      <span className="w-full truncate text-center text-[11px] font-medium">{a.name}</span>
    </div>
  );

  const hasCatalog = apps.some((a) => a.catalog);

  return (
    <div className="flex flex-col gap-5">
      <div className="flex gap-2">
        <div className="relative flex-1">
          <Search size={16} className="muted absolute left-3 top-1/2 -translate-y-1/2" />
          <input className="input !pl-9" placeholder="Buscar aplicativos" value={q} onChange={(e) => setQ(e.target.value)} />
        </div>
        <button className="btn !px-3" onClick={load} aria-label="Atualizar"><RefreshCw size={16} className={loading ? "spin" : ""} /></button>
      </div>

      {err && <div className="card-sm p-4 text-sm" style={{ borderColor: "var(--danger)" }}>{err}</div>}
      {hasCatalog && <p className="card-sm muted p-3 text-xs">Esta TV não informa a lista de apps instalados. Estes são atalhos conhecidos — abrem se o app estiver instalado.</p>}

      {favs.length > 0 && !q && (
        <section>
          <h2 className="muted mb-3 text-xs font-bold uppercase tracking-widest">Favoritos</h2>
          <div className="grid grid-cols-4 gap-x-2 gap-y-4 sm:grid-cols-6">{favs.map((a) => <Tile key={a.id} a={a} />)}</div>
        </section>
      )}
      {recentApps.length > 0 && !q && (
        <section>
          <h2 className="muted mb-3 text-xs font-bold uppercase tracking-widest">Abertos recentemente</h2>
          <div className="grid grid-cols-4 gap-x-2 gap-y-4 sm:grid-cols-6">{recentApps.map((a) => <Tile key={a.id} a={a} />)}</div>
        </section>
      )}
      <section>
        <h2 className="muted mb-3 text-xs font-bold uppercase tracking-widest">Todos os apps {apps.length ? `(${filtered.length})` : ""}</h2>
        {loading && apps.length === 0 ? (
          <div className="flex justify-center py-10"><Spinner size={28} /></div>
        ) : filtered.length === 0 ? (
          <p className="card-sm muted p-4 text-sm">{apps.length === 0 ? (connected ? "Nenhum app retornado pela TV." : "Conecte a TV para carregar os aplicativos.") : "Nada encontrado."}</p>
        ) : (
          <div className="grid grid-cols-4 gap-x-2 gap-y-4 sm:grid-cols-6">{filtered.map((a) => <Tile key={a.id} a={a} />)}</div>
        )}
      </section>
    </div>
  );
}
