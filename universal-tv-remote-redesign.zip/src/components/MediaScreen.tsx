"use client";

import { ListPlus, ListX, Pause, Play, Square, Tv, Volume2, VolumeX, Film, Music, Image as ImageIcon } from "lucide-react";
import { useCallback, useEffect, useRef, useState } from "react";
import type { TransferDTO } from "@/lib/commands";
import { isCastable } from "@/lib/transfer";
import { apiCall, useStore } from "./store";
import { Empty } from "./ui";

interface MediaStatus {
  position: number;
  duration: number;
  state: string;
  volume: number | null;
}

const fmt = (s: number) => {
  const t = Math.max(0, Math.floor(s));
  const h = Math.floor(t / 3600);
  const m = Math.floor((t % 3600) / 60);
  const sec = t % 60;
  return `${h ? `${h}:${String(m).padStart(2, "0")}` : m}:${String(sec).padStart(2, "0")}`;
};

export function MediaScreen() {
  const { active, api, toast, has, setTab, send, can, setAddOpen } = useStore();
  const [library, setLibrary] = useState<TransferDTO[]>([]);
  const [queue, setQueue] = useState<TransferDTO[]>([]);
  const [now, setNow] = useState<TransferDTO | null>(null);
  const [ms, setMs] = useState<MediaStatus | null>(null);
  const [seek, setSeek] = useState<number | null>(null);
  const [vol, setVol] = useState<number | null>(null);
  const [muted, setMuted] = useState(false);
  const prevState = useRef<string>("");
  const queueRef = useRef<TransferDTO[]>([]);
  queueRef.current = queue;

  const canCast = has("cast");
  const control = has("mediaControl");

  const loadLib = useCallback(async () => {
    try {
      const r = await apiCall<{ transfers: TransferDTO[] }>("/api/files");
      const lib = r.transfers.filter((t) => isCastable(t.kind) && ["ready", "sent", "sending"].includes(t.status));
      setLibrary(lib);
      if (active) {
        const last = r.transfers.filter((t) => t.deviceId === active.id && t.status === "sent").sort((a, b) => b.updatedAt.localeCompare(a.updatedAt))[0];
        setNow((n) => n ?? last ?? null);
      }
    } catch {
      /* ignore */
    }
  }, [active]);
  useEffect(() => {
    void loadLib();
  }, [loadLib]);

  const play = useCallback(
    async (t: TransferDTO) => {
      if (!active) return;
      try {
        await api(`/api/files/${t.id}/send`, { body: { deviceId: active.id } });
        setNow(t);
        toast(`Reproduzindo “${t.name}”`, "ok");
      } catch (e) {
        toast((e as Error).message, "err");
      }
      void loadLib();
    },
    [active, api, toast, loadLib],
  );

  // poll transport state; auto-advance the queue when playback ends
  useEffect(() => {
    if (!active || !control) return;
    const tick = async () => {
      try {
        const r = await apiCall<{ data: MediaStatus | null }>(`/api/devices/${active.id}/media`, { body: { action: "status" } });
        if (!r.data) return;
        setMs(r.data);
        if (vol === null && r.data.volume !== null) setVol(r.data.volume);
        const st = r.data.state;
        if (prevState.current === "PLAYING" && (st === "STOPPED" || st === "NO_MEDIA_PRESENT") && queueRef.current.length) {
          const [next, ...rest] = queueRef.current;
          setQueue(rest);
          void play(next);
        }
        prevState.current = st;
      } catch {
        setMs(null);
      }
    };
    void tick();
    const t = setInterval(tick, 2500);
    return () => clearInterval(t);
  }, [active, control, play, vol]);

  const media = async (action: string, value?: number) => {
    if (!active) return;
    try {
      await api(`/api/devices/${active.id}/media`, { body: { action, value } });
    } catch (e) {
      toast((e as Error).message, "err");
    }
  };

  if (!active) return <Empty icon={<Tv />} title="Nenhuma TV selecionada" text="Adicione uma TV para usar a central de mídia." action={<button className="btn btn-primary" onClick={() => setAddOpen(true)}>Adicionar TV</button>} />;

  const icon = (k: string) => (k === "image" ? <ImageIcon size={18} /> : k === "audio" ? <Music size={18} /> : <Film size={18} />);

  return (
    <div className="flex flex-col gap-5">
      {!canCast && (
        <div className="card-sm p-4 text-sm" style={{ borderColor: "var(--warn)" }}>
          Esta TV não expõe um receptor de mídia (DLNA / Roku), então não é possível enviar fotos e vídeos por aqui. Verifique se o “Compartilhamento de mídia / DLNA” está ativo na TV e adicione-a novamente pela descoberta.
        </div>
      )}

      <section className="glass p-5">
        <p className="muted text-xs font-bold uppercase tracking-widest">Reproduzindo</p>
        <h2 className="mt-1 truncate text-lg font-bold">{now?.name ?? "Nada tocando"}</h2>
        <p className="muted text-xs">{active.name}{ms ? ` · ${ms.state === "PLAYING" ? "tocando" : ms.state === "PAUSED_PLAYBACK" ? "pausado" : ms.state.toLowerCase()}` : ""}</p>

        {control ? (
          <>
            <div className="mt-4">
              <input type="range" min={0} max={Math.max(1, ms?.duration ?? 1)} value={seek ?? ms?.position ?? 0} disabled={!ms?.duration} aria-label="Posição" onChange={(e) => setSeek(Number(e.target.value))} onPointerUp={() => { if (seek !== null) void media("seek", seek).then(() => setSeek(null)); }} onKeyUp={() => { if (seek !== null) void media("seek", seek).then(() => setSeek(null)); }} />
              <div className="muted flex justify-between text-xs"><span>{fmt(seek ?? ms?.position ?? 0)}</span><span>{fmt(ms?.duration ?? 0)}</span></div>
            </div>
            <div className="mt-3 grid grid-cols-3 gap-3">
              <button className="key h-14" onClick={() => media("play")} aria-label="Reproduzir"><Play /></button>
              <button className="key h-14" onClick={() => media("pause")} aria-label="Pausar"><Pause /></button>
              <button className="key h-14" onClick={() => media("stop")} aria-label="Parar"><Square size={20} /></button>
            </div>
            <div className="mt-4 flex items-center gap-3">
              <button className="key h-10 w-10" aria-label="Mudo" onClick={() => { const m = !muted; setMuted(m); void media("mute", m ? 1 : 0); }}>{muted ? <VolumeX size={18} /> : <Volume2 size={18} />}</button>
              <input type="range" min={0} max={100} value={vol ?? 0} aria-label="Volume" onChange={(e) => setVol(Number(e.target.value))} onPointerUp={() => vol !== null && media("volume", vol)} onKeyUp={() => vol !== null && media("volume", vol)} />
              <span className="muted w-8 text-right text-xs">{vol ?? "—"}</span>
            </div>
          </>
        ) : (
          <div className="mt-4 flex flex-col gap-3">
            <p className="muted text-xs">Controle de transporte por DLNA indisponível; use as teclas do controle.</p>
            <div className="grid grid-cols-4 gap-2">
              <button className="key h-12" disabled={!can("play")} onClick={() => send("play")}><Play size={18} /></button>
              <button className="key h-12" disabled={!can("pause")} onClick={() => send("pause")}><Pause size={18} /></button>
              <button className="key h-12" disabled={!can("volDown")} onClick={() => send("volDown")}>Vol −</button>
              <button className="key h-12" disabled={!can("volUp")} onClick={() => send("volUp")}>Vol +</button>
            </div>
            <button className="btn" onClick={() => setTab("remote")}>Abrir controle completo</button>
          </div>
        )}
      </section>

      {queue.length > 0 && (
        <section>
          <h2 className="muted mb-2 text-xs font-bold uppercase tracking-widest">Fila ({queue.length})</h2>
          <div className="flex flex-col gap-2">
            {queue.map((t, i) => (
              <div key={`${t.id}-${i}`} className="card-sm flex items-center gap-3 p-3">
                {icon(t.kind)}
                <span className="min-w-0 flex-1 truncate text-sm">{t.name}</span>
                <button className="btn !p-2" aria-label="Remover da fila" onClick={() => setQueue((q) => q.filter((_, j) => j !== i))}><ListX size={16} /></button>
              </div>
            ))}
          </div>
          <p className="muted mt-2 text-xs">A fila avança sozinha quando o item atual termina (requer controle por DLNA).</p>
        </section>
      )}

      <section>
        <h2 className="muted mb-2 text-xs font-bold uppercase tracking-widest">Biblioteca (arquivos enviados do celular)</h2>
        {library.length === 0 ? (
          <div className="card-sm muted flex flex-col gap-3 p-4 text-sm">
            Nenhuma foto, vídeo ou música ainda.
            <button className="btn" onClick={() => setTab("files")}>Escolher arquivos</button>
          </div>
        ) : (
          <div className="flex flex-col gap-2">
            {library.map((t) => (
              <div key={t.id} className="card-sm flex items-center gap-3 p-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-xl" style={{ background: "var(--surface-2)" }}>{icon(t.kind)}</div>
                <span className="min-w-0 flex-1 truncate text-sm font-medium">{t.name}</span>
                <button className="btn !p-2" aria-label="Adicionar à fila" disabled={!control} title={control ? "Adicionar à fila" : "Fila requer controle DLNA"} onClick={() => setQueue((q) => [...q, t])}><ListPlus size={16} /></button>
                <button className="btn btn-primary !p-2" aria-label="Reproduzir na TV" disabled={!canCast} onClick={() => play(t)}><Play size={16} /></button>
              </div>
            ))}
          </div>
        )}
      </section>
    </div>
  );
}
