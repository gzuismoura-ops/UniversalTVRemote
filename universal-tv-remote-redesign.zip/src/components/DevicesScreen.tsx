"use client";

import { Activity, Pencil, Plus, RefreshCw, ShieldAlert, Star, Trash2, Zap } from "lucide-react";
import { useEffect, useState } from "react";
import { BRAND_LABEL } from "@/lib/commands";
import { AddDeviceSheet } from "./AddDeviceSheet";
import { useStore, type DeviceWithStatus } from "./store";
import { BrandBadge, Empty, Sheet, Spinner, StatusChip, timeAgo } from "./ui";

interface Check {
  label: string;
  ok: boolean;
  detail: string;
}

function Diagnostics({ device, onClose }: { device: DeviceWithStatus; onClose: () => void }) {
  const { api } = useStore();
  const [checks, setChecks] = useState<Check[] | null>(null);
  const [err, setErr] = useState<string | null>(null);
  useEffect(() => {
    api<{ checks: Check[] }>(`/api/devices/${device.id}/diagnostics`).then((r) => setChecks(r.checks)).catch((e) => setErr(e.message));
  }, [api, device.id]);
  return (
    <Sheet title={`Diagnóstico — ${device.name}`} onClose={onClose}>
      {!checks && !err && <div className="flex justify-center py-8"><Spinner size={28} /></div>}
      {err && <p style={{ color: "var(--danger)" }}>{err}</p>}
      <div className="flex flex-col gap-2">
        {checks?.map((c) => (
          <div key={c.label} className="card-sm flex items-start gap-3 p-3">
            <i className={`dot mt-1.5 ${c.ok ? "ok" : "err"}`} />
            <div className="min-w-0">
              <p className="text-sm font-semibold">{c.label}</p>
              <p className="muted break-words text-xs">{c.detail}</p>
            </div>
          </div>
        ))}
      </div>
    </Sheet>
  );
}

function EditSheet({ device, onClose }: { device: DeviceWithStatus; onClose: () => void }) {
  const { api, refreshDevices, toast } = useStore();
  const [name, setName] = useState(device.name);
  const [mac, setMac] = useState(device.mac ?? "");
  const save = async () => {
    try {
      await api(`/api/devices/${device.id}`, { method: "PATCH", body: { name, mac } });
      await refreshDevices();
      toast("Dispositivo atualizado", "ok");
      onClose();
    } catch (e) {
      toast((e as Error).message, "err");
    }
  };
  return (
    <Sheet title="Editar dispositivo" onClose={onClose}>
      <div className="flex flex-col gap-3">
        <label className="text-sm font-semibold" htmlFor="dn">Nome</label>
        <input id="dn" className="input" value={name} maxLength={60} onChange={(e) => setName(e.target.value)} />
        <label className="text-sm font-semibold" htmlFor="dm">Endereço MAC (para Wake-on-LAN)</label>
        <input id="dm" className="input" placeholder="AA:BB:CC:DD:EE:FF" value={mac} onChange={(e) => setMac(e.target.value)} />
        <button className="btn btn-primary" onClick={save} disabled={!name.trim()}>Salvar</button>
      </div>
    </Sheet>
  );
}

export function DevicesScreen() {
  const { devices, active, selectDevice, api, refreshDevices, toast, setAddOpen, reconnect, status } = useStore();
  const [diag, setDiag] = useState<DeviceWithStatus | null>(null);
  const [edit, setEdit] = useState<DeviceWithStatus | null>(null);
  const [repair, setRepair] = useState<string | null>(null);
  const [busy, setBusy] = useState<string | null>(null);

  const doConnect = async (d: DeviceWithStatus) => {
    setBusy(d.id);
    if (d.id !== active?.id) await selectDevice(d.id);
    else await reconnect(true);
    setBusy(null);
  };
  const fav = async (d: DeviceWithStatus) => {
    await api(`/api/devices/${d.id}`, { method: "PATCH", body: { favorite: !d.favorite } }).catch((e) => toast(e.message, "err"));
    refreshDevices();
  };
  const remove = async (d: DeviceWithStatus) => {
    if (!confirm(`Remover “${d.name}”? A autorização salva será apagada.`)) return;
    await api(`/api/devices/${d.id}`, { method: "DELETE" }).catch((e) => toast(e.message, "err"));
    if (d.id === active?.id) localStorage.removeItem("utv-active");
    await refreshDevices();
    toast("TV removida", "ok");
  };
  const wake = async (d: DeviceWithStatus) => {
    try {
      await api(`/api/devices/${d.id}/wake`, { body: {} });
      toast("Wake-on-LAN enviado", "ok");
    } catch (e) {
      toast((e as Error).message, "err");
    }
  };
  const startRepair = async (d: DeviceWithStatus) => {
    await api(`/api/devices/${d.id}/repair`, { body: {} }).catch(() => undefined);
    setRepair(d.ip);
  };

  return (
    <div className="flex flex-col gap-4">
      <button className="btn btn-primary" onClick={() => setAddOpen(true)}><Plus size={18} /> Adicionar nova TV</button>

      {devices.length === 0 && <Empty icon={<Plus />} title="Nenhuma TV salva" text="Procure TVs na rede ou informe o IP manualmente. O pareamento fica salvo para as próximas vezes." />}

      {devices.map((d) => {
        const st = d.id === active?.id ? status ?? d.status : d.status;
        const isActive = d.id === active?.id;
        return (
          <article key={d.id} className="glass rise p-4" style={isActive ? { borderColor: "var(--accent)" } : undefined}>
            <div className="flex items-center gap-3">
              <BrandBadge brand={d.brand} />
              <div className="min-w-0 flex-1">
                <p className="truncate font-bold">{d.name}</p>
                <p className="muted truncate text-xs">{BRAND_LABEL[d.brand]}{d.model ? ` · ${d.model}` : ""}</p>
                <p className="muted truncate text-xs">{d.ip} · última conexão {timeAgo(d.lastConnectedAt)}</p>
              </div>
              <button className="p-2" onClick={() => fav(d)} aria-label="Favorita"><Star size={20} fill={d.favorite ? "#fbbf24" : "none"} color={d.favorite ? "#fbbf24" : "currentColor"} /></button>
            </div>
            <div className="mt-3 flex flex-wrap items-center gap-2">
              <StatusChip state={isActive ? st?.state : st?.state ?? "disconnected"} />
              {d.authState === "paired" && <span className="chip">🔒 Autorização salva</span>}
              {d.authState === "revoked" && <span className="chip" style={{ color: "var(--danger)" }}><ShieldAlert size={12} /> Autorização revogada</span>}
              {d.authState === "none" && d.capabilities.features.includes("pairingPin") && <span className="chip">Não pareada</span>}
            </div>
            {d.lastError && d.status?.state !== "connected" && <p className="muted mt-2 text-xs">Último erro: {d.lastError}</p>}
            <div className="mt-3 grid grid-cols-3 gap-2">
              <button className="btn !px-2 !py-2 text-xs" disabled={busy === d.id} onClick={() => doConnect(d)}>
                {busy === d.id ? <Spinner size={14} /> : <RefreshCw size={14} />} {isActive ? "Reconectar" : "Usar"}
              </button>
              <button className="btn !px-2 !py-2 text-xs" onClick={() => setDiag(d)}><Activity size={14} /> Diagnóstico</button>
              <button className="btn !px-2 !py-2 text-xs" onClick={() => setEdit(d)}><Pencil size={14} /> Editar</button>
              <button className="btn !px-2 !py-2 text-xs" onClick={() => wake(d)}><Zap size={14} /> Ligar (WoL)</button>
              <button className="btn !px-2 !py-2 text-xs" onClick={() => startRepair(d)}><ShieldAlert size={14} /> Parear de novo</button>
              <button className="btn btn-danger !px-2 !py-2 text-xs" onClick={() => remove(d)}><Trash2 size={14} /> Remover</button>
            </div>
          </article>
        );
      })}

      {repair && <AddDeviceSheet presetIp={repair} onClose={() => setRepair(null)} />}
      {diag && <Diagnostics device={diag} onClose={() => setDiag(null)} />}
      {edit && <EditSheet device={edit} onClose={() => setEdit(null)} />}
    </div>
  );
}
