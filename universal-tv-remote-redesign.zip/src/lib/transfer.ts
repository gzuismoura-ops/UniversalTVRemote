import type { TransferStatus } from "./commands";

/** Transfer state machine (unit-tested). */
const ALLOWED: Record<TransferStatus, TransferStatus[]> = {
  uploading: ["ready", "failed", "cancelled"],
  ready: ["sending", "cancelled"],
  sending: ["sent", "failed", "cancelled"],
  sent: ["sending"], // can be re-sent
  failed: ["sending", "uploading"],
  cancelled: [],
};

export function canTransition(from: TransferStatus, to: TransferStatus): boolean {
  return ALLOWED[from]?.includes(to) ?? false;
}

export function transition(from: TransferStatus, to: TransferStatus): TransferStatus {
  if (!canTransition(from, to)) {
    throw new Error(`Transição inválida: ${from} → ${to}`);
  }
  return to;
}

export function progressPercent(received: number, size: number): number {
  if (size <= 0) return 0;
  return Math.max(0, Math.min(100, Math.floor((received / size) * 100)));
}

export function kindFromMime(mime: string, name = ""): "image" | "video" | "audio" | "document" | "other" {
  const m = mime.toLowerCase();
  if (m.startsWith("image/")) return "image";
  if (m.startsWith("video/")) return "video";
  if (m.startsWith("audio/")) return "audio";
  if (m === "application/pdf" || /\.(pdf|docx?|xlsx?|pptx?|txt)$/i.test(name)) return "document";
  return "other";
}

/** Only photos, videos and music can be rendered by a TV media renderer. */
export function isCastable(kind: string): boolean {
  return kind === "image" || kind === "video" || kind === "audio";
}
