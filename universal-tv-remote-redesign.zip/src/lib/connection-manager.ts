import { eq } from "drizzle-orm";
import { db } from "@/db";
import { devices } from "@/db/schema";
import type { Command, StatusDTO } from "./commands";
import { getDevice, logActivity, readCredentials, saveCredentials } from "./device-service";
import { TvError } from "./net";
import { getModule } from "./protocols";
import type { TvDriver } from "./protocols/types";
import { decideReconnect } from "./reconnect";
import { CLIENT_NAME } from "./device-service";

class NeedsPairing extends TvError {
  constructor(m: string) {
    super(m, "auth");
  }
}

/**
 * Keeps one live driver per saved TV, in server memory:
 *  - connects with the stored (decrypted) credential, never re-pairing on its own
 *  - health-checks every 10 s
 *  - reconnects with exponential back-off after Wi‑Fi drops / TV power cycles
 *  - only reports "needs-pairing" when the TV itself rejected the credential
 */

const HEALTH_MS = 10_000;

interface Entry {
  id: string;
  driver: TvDriver | null;
  state: StatusDTO["state"];
  error: string | null;
  latencyMs: number | null;
  attempts: number;
  authFailures: number;
  nextRetryAt: number | null;
  retryTimer: NodeJS.Timeout | null;
  healthTimer: NodeJS.Timeout | null;
  inflight: Promise<void> | null;
  stopped: boolean;
  lastSeenWrite: number;
}

const g = globalThis as typeof globalThis & { __utvEntries?: Map<string, Entry> };
const entries = (g.__utvEntries ??= new Map<string, Entry>());

function entryFor(id: string): Entry {
  let e = entries.get(id);
  if (!e) {
    e = { id, driver: null, state: "disconnected", error: null, latencyMs: null, attempts: 0, authFailures: 0, nextRetryAt: null, retryTimer: null, healthTimer: null, inflight: null, stopped: false, lastSeenWrite: 0 };
    entries.set(id, e);
  }
  return e;
}

function clearTimers(e: Entry) {
  if (e.retryTimer) clearTimeout(e.retryTimer);
  if (e.healthTimer) clearInterval(e.healthTimer);
  e.retryTimer = null;
  e.healthTimer = null;
  e.nextRetryAt = null;
}

async function attempt(e: Entry): Promise<void> {
  const row = await getDevice(e.id);
  if (!row) {
    await forget(e.id);
    throw new TvError("Dispositivo removido");
  }
  const mod = getModule(row.brand);
  if (!mod) throw new TvError("Protocolo desconhecido", "unsupported");
  const creds = readCredentials(row);

  if (mod.requiresCredentials && !creds) {
    // Nothing to reuse and we must not surprise the TV with an unrequested prompt.
    e.state = "needs-pairing";
    e.error = row.authState === "revoked" ? "A TV revogou a autorização. Pareie novamente." : "Pareamento necessário.";
    throw new NeedsPairing(e.error);
  }

  e.state = e.attempts > 0 ? "reconnecting" : "connecting";
  e.driver?.disconnect();
  const driver = mod.createDriver({
    ip: row.ip,
    port: row.port,
    clientName: CLIENT_NAME,
    credentials: creds,
    meta: (row.meta ?? {}) as Record<string, unknown>,
    saveCredentials: (c) => saveCredentials(row.id, c),
  });
  e.driver = driver;
  const t0 = Date.now();
  await driver.connect();
  e.latencyMs = Date.now() - t0;
  e.state = "connected";
  e.error = null;
  e.attempts = 0;
  e.authFailures = 0;
  await db.update(devices).set({ lastConnectedAt: new Date(), lastSeenAt: new Date(), lastError: null, authState: mod.requiresCredentials ? "paired" : row.authState === "none" ? "paired" : row.authState }).where(eq(devices.id, row.id));
  startHealth(e);
}

function startHealth(e: Entry) {
  if (e.healthTimer) clearInterval(e.healthTimer);
  e.healthTimer = setInterval(async () => {
    if (e.stopped || e.state !== "connected" || !e.driver) return;
    const t0 = Date.now();
    try {
      await e.driver.ping();
      e.latencyMs = Date.now() - t0;
      if (!e.driver.isAlive()) throw new TvError("Conexão perdida");
      if (Date.now() - e.lastSeenWrite > 60_000) {
        e.lastSeenWrite = Date.now();
        await db.update(devices).set({ lastSeenAt: new Date() }).where(eq(devices.id, e.id));
      }
    } catch (err) {
      await handleFailure(e, err as TvError);
    }
  }, HEALTH_MS);
  e.healthTimer.unref?.();
}

async function handleFailure(e: Entry, err: TvError) {
  if (e.stopped) return;
  if (e.healthTimer) clearInterval(e.healthTimer);
  e.healthTimer = null;
  e.error = err.message;
  e.latencyMs = null;
  e.driver?.disconnect();

  let kind = err.kind === "auth" ? "auth" : "network";
  // A single "auth" error may be a TV in deep standby; require two before declaring the credential revoked.
  if (kind === "auth") {
    e.authFailures++;
    if (e.authFailures < 2) kind = "network";
  }
  const row = await getDevice(e.id).catch(() => null);
  const decision = decideReconnect({ attempts: e.attempts, authState: (row?.authState as "none" | "paired" | "revoked") ?? "paired", errorKind: kind as "network" | "auth" });
  if (decision.action === "needs-pairing") {
    e.state = "needs-pairing";
    if (kind === "auth") {
      await db.update(devices).set({ authState: "revoked", lastError: err.message }).where(eq(devices.id, e.id));
      await logActivity({ deviceId: e.id, type: "error", label: "A TV recusou a credencial salva" }).catch(() => undefined);
    }
    return;
  }
  if (decision.action === "give-up") {
    e.state = "error";
    return;
  }
  e.attempts++;
  e.state = "reconnecting";
  e.nextRetryAt = Date.now() + decision.delayMs;
  e.retryTimer = setTimeout(() => void runConnect(e).catch(() => undefined), decision.delayMs);
  e.retryTimer.unref?.();
  await db.update(devices).set({ lastError: err.message }).where(eq(devices.id, e.id)).catch(() => undefined);
}

function runConnect(e: Entry): Promise<void> {
  if (e.inflight) return e.inflight;
  e.retryTimer && clearTimeout(e.retryTimer);
  e.retryTimer = null;
  e.nextRetryAt = null;
  e.stopped = false;
  e.inflight = (async () => {
    try {
      await attempt(e);
    } catch (err) {
      const te = err instanceof TvError ? err : new TvError((err as Error).message);
      if (err instanceof NeedsPairing) throw te;
      await handleFailure(e, te);
      throw te;
    } finally {
      e.inflight = null;
    }
  })();
  return e.inflight;
}

/** Connect (or reuse the live connection). Safe to call on every app open. */
export async function connect(id: string, opts: { force?: boolean } = {}): Promise<StatusDTO> {
  const e = entryFor(id);
  if (opts.force) {
    clearTimers(e);
    e.driver?.disconnect();
    e.attempts = 0;
    e.authFailures = 0;
    e.state = "disconnected";
  }
  if (e.state === "connected" && e.driver?.isAlive()) return status(id);
  try {
    await runConnect(e);
  } catch {
    /* status carries the error */
  }
  return status(id);
}

export function status(id: string): StatusDTO {
  const e = entries.get(id);
  if (!e) return { state: "disconnected", error: null, latencyMs: null, attempts: 0, nextRetryInMs: null };
  return {
    state: e.state,
    error: e.error,
    latencyMs: e.latencyMs,
    attempts: e.attempts,
    nextRetryInMs: e.nextRetryAt ? Math.max(0, e.nextRetryAt - Date.now()) : null,
  };
}

/** Returns a live driver, connecting first if needed. */
export async function driverFor(id: string): Promise<TvDriver> {
  const e = entryFor(id);
  if (!(e.state === "connected" && e.driver?.isAlive())) {
    await connect(id);
  }
  if (e.state !== "connected" || !e.driver) {
    throw new TvError(e.error ?? "TV desconectada", e.state === "needs-pairing" ? "auth" : "network");
  }
  return e.driver;
}

export async function run<T>(id: string, fn: (d: TvDriver) => Promise<T>): Promise<T> {
  const d = await driverFor(id);
  try {
    return await fn(d);
  } catch (err) {
    const te = err instanceof TvError ? err : new TvError((err as Error).message);
    if (te.kind === "network" || te.kind === "timeout" || te.kind === "auth") {
      const e = entryFor(id);
      // Drop the broken transport and reconnect in the background, then retry once.
      if (!d.isAlive() && !e.inflight) {
        e.driver?.disconnect();
        e.state = "reconnecting";
        try {
          await runConnect(e);
          return await fn(e.driver!);
        } catch {
          /* fall through */
        }
      }
    }
    throw te;
  }
}

export async function sendCommand(id: string, cmd: Command) {
  return run(id, (d) => d.send(cmd));
}

export async function forget(id: string) {
  const e = entries.get(id);
  if (!e) return;
  e.stopped = true;
  clearTimers(e);
  e.driver?.disconnect();
  entries.delete(id);
}

export function disconnect(id: string) {
  const e = entries.get(id);
  if (!e) return;
  e.stopped = true;
  clearTimers(e);
  e.driver?.disconnect();
  e.state = "disconnected";
  e.stopped = false;
}
