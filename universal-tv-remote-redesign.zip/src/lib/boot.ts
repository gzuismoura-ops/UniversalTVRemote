import { desc } from "drizzle-orm";
import { db } from "@/db";
import { devices } from "@/db/schema";
import { connect } from "./connection-manager";

/**
 * Runs once when the server process starts: reconnect the favorite TV and the
 * most recently used TV using their stored credentials (no new authorization).
 */
export async function boot() {
  try {
    await new Promise((r) => setTimeout(r, 4000));
    const rows = await db.select().from(devices).orderBy(desc(devices.favorite), desc(devices.lastConnectedAt)).limit(2);
    for (const d of rows) {
      if (d.authState === "revoked") continue;
      void connect(d.id).catch(() => undefined);
    }
  } catch {
    /* DB not ready yet: the client reconnects on demand */
  }
}
