import crypto from "node:crypto";
import { desc, eq, lte } from "drizzle-orm";
import { db } from "@/db";
import { activities, devices, type DeviceRow } from "@/db/schema";
import type { ActivityDTO, Brand, DeviceDTO } from "./commands";
import { decryptJson, encryptJson } from "./crypto";
import { findDlnaLocation } from "./dlna";
import { isPrivateIPv4, isValidIPv4, lookupMac, normalizeMac, TvError } from "./net";
import { capabilitiesFor, getModule, identify } from "./protocols";
import type { Credentials, DeviceIdentity, PairingContext, PairingResult, ProtocolModule } from "./protocols/types";

export const CLIENT_NAME = "Universal TV Remote";

export function toDTO(r: DeviceRow): DeviceDTO {
  const meta = (r.meta ?? {}) as Record<string, unknown>;
  const caps = capabilitiesFor(r.brand, meta);
  return {
    id: r.id,
    name: r.name,
    brand: r.brand as Brand,
    model: r.model,
    ip: r.ip,
    port: r.port,
    mac: r.mac,
    favorite: r.favorite,
    authState: (r.authState as DeviceDTO["authState"]) ?? "none",
    lastConnectedAt: r.lastConnectedAt?.toISOString() ?? null,
    lastError: r.lastError,
    createdAt: r.createdAt.toISOString(),
    capabilities: caps,
    hasMedia: caps.features.includes("cast"),
  };
}

export async function listDevices(): Promise<DeviceRow[]> {
  return db.select().from(devices).orderBy(desc(devices.favorite), desc(devices.lastConnectedAt), desc(devices.createdAt));
}

export async function getDevice(id: string): Promise<DeviceRow | null> {
  if (!/^[0-9a-f-]{36}$/i.test(id)) return null;
  const [row] = await db.select().from(devices).where(eq(devices.id, id)).limit(1);
  return row ?? null;
}

export function readCredentials(row: DeviceRow): Credentials | null {
  if (!row.credentialsEnc) return null;
  return decryptJson<Credentials>(row.credentialsEnc);
}

export async function saveCredentials(id: string, creds: Credentials): Promise<void> {
  await db.update(devices).set({ credentialsEnc: encryptJson(creds), authState: "paired", lastError: null }).where(eq(devices.id, id));
}

export async function logActivity(a: { deviceId?: string | null; type: string; label: string; refId?: string | null; icon?: string | null }) {
  await db.insert(activities).values({ deviceId: a.deviceId ?? null, type: a.type, label: a.label, refId: a.refId ?? null, icon: a.icon ?? null });
  // keep the table small
  const old = await db.select({ id: activities.id }).from(activities).orderBy(desc(activities.id)).offset(300).limit(1);
  if (old[0]) await db.delete(activities).where(lte(activities.id, old[0].id));
}

export function activityDTO(a: typeof activities.$inferSelect): ActivityDTO {
  return { id: a.id, deviceId: a.deviceId, type: a.type, label: a.label, refId: a.refId, icon: a.icon, createdAt: a.createdAt.toISOString() };
}

// ---------------------------------------------------------------- pairing

interface PairSession {
  module: ProtocolModule;
  state: unknown;
  ctx: PairingContext;
  meta: Record<string, unknown>;
  expires: number;
}
const g = globalThis as typeof globalThis & { __utvPairings?: Map<string, PairSession> };
const sessions = (g.__utvPairings ??= new Map());

function sweep() {
  const now = Date.now();
  for (const [k, v] of sessions) if (v.expires < now) sessions.delete(k);
}

export type PairOutcome =
  | { status: "paired"; device: DeviceDTO; reused: boolean }
  | { status: "pin"; pairingId: string; message: string; identity: { brand: Brand; name: string; model: string | null } };

async function persist(identity: DeviceIdentity, creds: Credentials | null, ip: string, meta: Record<string, unknown>, nameOverride?: string): Promise<DeviceRow> {
  const existing = (await db.select().from(devices).where(eq(devices.ip, ip)).limit(1))[0];
  const mac = normalizeMac(identity.mac) ?? existing?.mac ?? (await lookupMac(ip));
  const values = {
    name: nameOverride || existing?.name || identity.name,
    brand: identity.brand,
    model: identity.model ?? existing?.model ?? null,
    ip,
    port: identity.port ?? existing?.port ?? null,
    mac,
    uniqueId: identity.uniqueId ?? existing?.uniqueId ?? null,
    meta: { ...((existing?.meta as Record<string, unknown>) ?? {}), ...(identity.meta ?? {}), ...meta },
    authState: creds || !getModule(identity.brand)?.requiresCredentials ? "paired" : "none",
    credentialsEnc: creds ? encryptJson(creds) : (existing?.credentialsEnc ?? null),
    lastError: null,
  };
  if (existing) {
    const [row] = await db.update(devices).set(values).where(eq(devices.id, existing.id)).returning();
    return row;
  }
  const [row] = await db.insert(devices).values({ ...values, favorite: (await db.select({ id: devices.id }).from(devices).limit(1)).length === 0 }).returning();
  return row;
}

export async function startPairing(input: { ip: string; brand?: string; name?: string }): Promise<PairOutcome> {
  sweep();
  const ip = input.ip.trim();
  if (!isValidIPv4(ip) || !isPrivateIPv4(ip)) throw new TvError("Informe um IP de rede local válido (ex.: 192.168.0.20)", "unsupported");

  // Never trigger a new pairing prompt when a working credential already exists.
  const existing = (await db.select().from(devices).where(eq(devices.ip, ip)).limit(1))[0];
  if (existing && existing.authState === "paired" && (existing.credentialsEnc ? readCredentials(existing) : !getModule(existing.brand)?.requiresCredentials)) {
    return { status: "paired", device: toDTO(existing), reused: true };
  }

  let identity: DeviceIdentity | null = null;
  const forced = input.brand ? getModule(input.brand) : null;
  const dlnaP = findDlnaLocation(ip).catch(() => null);
  if (forced) identity = (await forced.probe(ip).catch(() => null)) ?? { brand: forced.brand, name: input.name || forced.brand.toUpperCase() };
  else identity = await identify(ip);
  const dlnaLocation = await dlnaP;
  if (!identity) throw new TvError("Nenhuma TV compatível encontrada nesse IP. Confira se ela está ligada e na mesma rede Wi‑Fi do servidor.");
  const module = getModule(identity.brand)!;
  const meta: Record<string, unknown> = dlnaLocation ? { dlnaLocation } : {};

  const ctx: PairingContext = { ip, clientName: CLIENT_NAME, identity };
  const res: PairingResult = await module.beginPairing(ctx);
  if (res.status === "pin") {
    const pairingId = crypto.randomUUID();
    sessions.set(pairingId, { module, state: res.state, ctx, meta, expires: Date.now() + 5 * 60_000 });
    return { status: "pin", pairingId, message: res.message, identity: { brand: identity.brand, name: identity.name, model: identity.model ?? null } };
  }
  const row = await persist({ ...identity, ...res.identity, name: res.identity.name ?? identity.name, brand: identity.brand }, res.credentials, ip, meta, input.name);
  await logActivity({ deviceId: row.id, type: "connect", label: `Pareado com ${row.name}` });
  return { status: "paired", device: toDTO(row), reused: false };
}

export async function confirmPairing(pairingId: string, pin: string): Promise<PairOutcome> {
  const s = sessions.get(pairingId);
  if (!s || s.expires < Date.now()) throw new TvError("Sessão de pareamento expirada. Recomece.", "timeout");
  if (!s.module.finishPairing) throw new TvError("Este protocolo não usa PIN", "unsupported");
  const res = await s.module.finishPairing(s.state, pin, s.ctx);
  sessions.delete(pairingId);
  if (res.status !== "paired") throw new TvError("Pareamento incompleto");
  const identity = { ...s.ctx.identity, ...res.identity, name: res.identity.name ?? s.ctx.identity.name, brand: s.ctx.identity.brand };
  const row = await persist(identity, res.credentials, s.ctx.ip, s.meta);
  await logActivity({ deviceId: row.id, type: "connect", label: `Pareado com ${row.name}` });
  return { status: "paired", device: toDTO(row), reused: false };
}

export async function cancelPairing(pairingId: string) {
  sessions.delete(pairingId);
}

/** Starts a brand-new pairing for a device whose credential was revoked. */
export async function resetCredentials(id: string) {
  await db.update(devices).set({ credentialsEnc: null, authState: "none" }).where(eq(devices.id, id));
}
