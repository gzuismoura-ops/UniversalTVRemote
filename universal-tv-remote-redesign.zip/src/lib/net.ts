import http from "node:http";
import https from "node:https";
import net from "node:net";
import os from "node:os";
import dgram from "node:dgram";
import { execFile } from "node:child_process";

export class TvError extends Error {
  kind: "network" | "auth" | "unsupported" | "timeout";
  constructor(message: string, kind: TvError["kind"] = "network") {
    super(message);
    this.kind = kind;
  }
}

export interface HttpOpts {
  method?: string;
  headers?: Record<string, string>;
  body?: string | Buffer;
  timeoutMs?: number;
  /**
   * TVs use self-signed certificates on the LAN. Verification is relaxed ONLY
   * for the single request/socket to the explicit device IP — never globally
   * (no NODE_TLS_REJECT_UNAUTHORIZED, no global agent).
   */
  insecureTls?: boolean;
}

export interface HttpRes {
  status: number;
  headers: http.IncomingHttpHeaders;
  body: string;
}

export function httpRequest(url: string, opts: HttpOpts = {}): Promise<HttpRes> {
  return new Promise((resolve, reject) => {
    let u: URL;
    try {
      u = new URL(url);
    } catch {
      reject(new TvError("URL inválida"));
      return;
    }
    const isHttps = u.protocol === "https:";
    const lib = isHttps ? https : http;
    const headers = { ...(opts.headers ?? {}) };
    if (opts.body !== undefined && !headers["Content-Length"]) {
      headers["Content-Length"] = String(Buffer.byteLength(opts.body));
    }
    const req = lib.request(
      {
        hostname: u.hostname,
        port: u.port || (isHttps ? 443 : 80),
        path: u.pathname + u.search,
        method: opts.method ?? "GET",
        headers,
        timeout: opts.timeoutMs ?? 4000,
        ...(isHttps ? { rejectUnauthorized: !opts.insecureTls } : {}),
        agent: false,
      },
      (res) => {
        const chunks: Buffer[] = [];
        res.on("data", (c) => chunks.push(c));
        res.on("end", () =>
          resolve({
            status: res.statusCode ?? 0,
            headers: res.headers,
            body: Buffer.concat(chunks).toString("utf8"),
          }),
        );
        res.on("error", reject);
      },
    );
    req.on("timeout", () => {
      req.destroy(new TvError("Tempo esgotado ao falar com a TV", "timeout"));
    });
    req.on("error", (e) =>
      reject(e instanceof TvError ? e : new TvError(`Rede: ${(e as Error).message}`)),
    );
    if (opts.body !== undefined) req.write(opts.body);
    req.end();
  });
}

export async function httpJson<T = unknown>(url: string, opts: HttpOpts = {}): Promise<{ status: number; json: T | null; headers: http.IncomingHttpHeaders }> {
  const r = await httpRequest(url, opts);
  let json: T | null = null;
  try {
    json = JSON.parse(r.body) as T;
  } catch {
    json = null;
  }
  return { status: r.status, json, headers: r.headers };
}

/** Measures TCP connect time; null when closed/unreachable. */
export function tcpProbe(host: string, port: number, timeoutMs = 1200): Promise<number | null> {
  return new Promise((resolve) => {
    const start = Date.now();
    const s = net.connect({ host, port });
    const done = (v: number | null) => {
      s.destroy();
      resolve(v);
    };
    s.setTimeout(timeoutMs, () => done(null));
    s.once("connect", () => done(Date.now() - start));
    s.once("error", () => done(null));
  });
}

export function isValidIPv4(ip: string): boolean {
  const m = /^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/.exec(ip);
  return !!m && m.slice(1).every((n) => Number(n) <= 255);
}

/** Only private (RFC1918) / link-local addresses are accepted as TV targets (SSRF guard). */
export function isPrivateIPv4(ip: string): boolean {
  if (!isValidIPv4(ip)) return false;
  const [a, b] = ip.split(".").map(Number);
  return a === 10 || (a === 172 && b >= 16 && b <= 31) || (a === 192 && b === 168) || (a === 169 && b === 254) || a === 127;
}

export function localIPv4s(): { address: string; netmask: string }[] {
  const out: { address: string; netmask: string }[] = [];
  for (const list of Object.values(os.networkInterfaces())) {
    for (const i of list ?? []) {
      if (i.family === "IPv4" && !i.internal) out.push({ address: i.address, netmask: i.netmask });
    }
  }
  return out;
}

function ipToInt(ip: string): number {
  return ip.split(".").reduce((a, b) => (a << 8) + Number(b), 0) >>> 0;
}

/** Server IP on the same subnet as the TV, so the TV can fetch our media. */
export function lanIpFor(targetIp: string): string | null {
  const all = localIPv4s();
  const t = ipToInt(targetIp);
  for (const i of all) {
    const mask = ipToInt(i.netmask);
    if ((ipToInt(i.address) & mask) === (t & mask)) return i.address;
  }
  return all[0]?.address ?? null;
}

export function normalizeMac(mac: string | null | undefined): string | null {
  if (!mac) return null;
  const hex = mac.replace(/[^0-9a-fA-F]/g, "").toLowerCase();
  if (hex.length !== 12) return null;
  return hex.match(/.{2}/g)!.join(":");
}

export function buildMagicPacket(mac: string): Buffer {
  const hex = mac.replace(/[^0-9a-fA-F]/g, "");
  if (hex.length !== 12) throw new TvError("Endereço MAC inválido");
  const macBuf = Buffer.from(hex, "hex");
  return Buffer.concat([Buffer.alloc(6, 0xff), ...Array.from({ length: 16 }, () => macBuf)]);
}

export function sendWakeOnLan(mac: string, targetIp?: string): Promise<void> {
  const packet = buildMagicPacket(mac);
  const broadcasts = new Set<string>(["255.255.255.255"]);
  for (const i of localIPv4s()) {
    const ip = ipToInt(i.address);
    const mask = ipToInt(i.netmask);
    const b = ((ip & mask) | (~mask >>> 0)) >>> 0;
    broadcasts.add([b >>> 24, (b >>> 16) & 255, (b >>> 8) & 255, b & 255].join("."));
  }
  if (targetIp) broadcasts.add(targetIp);
  return new Promise((resolve, reject) => {
    const sock = dgram.createSocket("udp4");
    sock.once("error", (e) => {
      sock.close();
      reject(new TvError(`WoL falhou: ${e.message}`));
    });
    sock.bind(() => {
      sock.setBroadcast(true);
      let pending = 0;
      const fin = () => {
        if (--pending <= 0) {
          sock.close();
          resolve();
        }
      };
      for (const addr of broadcasts) {
        for (const port of [9, 7]) {
          pending++;
          sock.send(packet, port, addr, fin);
        }
      }
    });
  });
}

/** Best-effort MAC lookup from the OS neighbour table (works when server and TV share a LAN). */
export function lookupMac(ip: string): Promise<string | null> {
  if (!isValidIPv4(ip)) return Promise.resolve(null);
  const parse = (out: string) => {
    const m = /([0-9a-f]{2}[:-]){5}[0-9a-f]{2}/i.exec(out);
    return m ? normalizeMac(m[0]) : null;
  };
  return new Promise((resolve) => {
    execFile("ip", ["neigh", "show", ip], { timeout: 1500 }, (e1, o1) => {
      const m = !e1 ? parse(o1) : null;
      if (m) return resolve(m);
      execFile("arp", ["-n", ip], { timeout: 1500 }, (e2, o2) => resolve(!e2 ? parse(o2) : null));
    });
  });
}

export function xmlText(xml: string, tag: string): string | null {
  const m = new RegExp(`<(?:[\\w-]+:)?${tag}[^>]*>([^<]*)</(?:[\\w-]+:)?${tag}>`, "i").exec(xml);
  return m ? m[1].trim() : null;
}

export function xmlEscape(s: string): string {
  return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&apos;");
}

export function sleep(ms: number): Promise<void> {
  return new Promise((r) => setTimeout(r, ms));
}

/** Binary GET (used for proxying TV app icons). Size-capped. */
export function httpBinary(url: string, timeoutMs = 4000, maxBytes = 2_000_000): Promise<{ status: number; type: string; data: Buffer }> {
  return new Promise((resolve, reject) => {
    let u: URL;
    try {
      u = new URL(url);
    } catch {
      reject(new TvError("URL inválida"));
      return;
    }
    const lib = u.protocol === "https:" ? https : http;
    const req = lib.get(u, { timeout: timeoutMs, agent: false, ...(u.protocol === "https:" ? { rejectUnauthorized: false } : {}) }, (res) => {
      const chunks: Buffer[] = [];
      let size = 0;
      res.on("data", (c: Buffer) => {
        size += c.length;
        if (size > maxBytes) {
          req.destroy(new TvError("Ícone grande demais"));
          return;
        }
        chunks.push(c);
      });
      res.on("end", () => resolve({ status: res.statusCode ?? 0, type: String(res.headers["content-type"] ?? "image/png"), data: Buffer.concat(chunks) }));
    });
    req.on("timeout", () => req.destroy(new TvError("Tempo esgotado", "timeout")));
    req.on("error", (e) => reject(e instanceof TvError ? e : new TvError(e.message)));
  });
}
