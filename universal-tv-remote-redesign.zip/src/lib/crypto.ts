import crypto from "node:crypto";
import fs from "node:fs";
import path from "node:path";

/**
 * Credential vault: AES-256-GCM, authenticated encryption.
 *
 * Key source (in order):
 *  1. CREDENTIAL_KEY env var (any string, stretched with scrypt)
 *  2. a random 32-byte key generated once and stored in .data/credential.key (mode 0600)
 *
 * Android Keystore does not exist on a server; this is the server-side
 * equivalent: credentials are never stored in plain text in the database and
 * the key lives outside the database.
 */

let cachedKey: Buffer | null = null;

export function dataDir(): string {
  const dir = process.env.DATA_DIR || path.join(process.cwd(), ".data");
  fs.mkdirSync(dir, { recursive: true });
  return dir;
}

function loadKey(): Buffer {
  if (cachedKey) return cachedKey;
  const env = process.env.CREDENTIAL_KEY;
  if (env && env.length >= 8) {
    cachedKey = crypto.scryptSync(env, "universal-tv-remote:v1", 32);
    return cachedKey;
  }
  const file = path.join(dataDir(), "credential.key");
  if (fs.existsSync(file)) {
    cachedKey = Buffer.from(fs.readFileSync(file, "utf8").trim(), "hex");
  } else {
    cachedKey = crypto.randomBytes(32);
    fs.writeFileSync(file, cachedKey.toString("hex"), { mode: 0o600 });
  }
  return cachedKey;
}

export function encryptJson(value: unknown, key: Buffer = loadKey()): string {
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv("aes-256-gcm", key, iv);
  const enc = Buffer.concat([
    cipher.update(JSON.stringify(value), "utf8"),
    cipher.final(),
  ]);
  const tag = cipher.getAuthTag();
  return ["v1", iv.toString("base64"), tag.toString("base64"), enc.toString("base64")].join(":");
}

export function decryptJson<T = unknown>(payload: string, key: Buffer = loadKey()): T | null {
  try {
    const [v, iv, tag, data] = payload.split(":");
    if (v !== "v1") return null;
    const decipher = crypto.createDecipheriv("aes-256-gcm", key, Buffer.from(iv, "base64"));
    decipher.setAuthTag(Buffer.from(tag, "base64"));
    const dec = Buffer.concat([
      decipher.update(Buffer.from(data, "base64")),
      decipher.final(),
    ]);
    return JSON.parse(dec.toString("utf8")) as T;
  } catch {
    // Wrong key or tampered data: treat as "no credentials" (forces re-pair).
    return null;
  }
}
