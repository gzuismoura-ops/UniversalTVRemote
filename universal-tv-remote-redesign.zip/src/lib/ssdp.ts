import dgram from "node:dgram";
import { localIPv4s } from "./net";

export interface SsdpResponse {
  ip: string;
  location: string | null;
  st: string | null;
  usn: string | null;
  server: string | null;
}

const SEARCH_TARGETS = [
  "roku:ecp",
  "urn:dial-multiscreen-org:service:dial:1",
  "urn:schemas-upnp-org:device:MediaRenderer:1",
  "urn:lge-com:service:webos-second-screen:1",
  "urn:samsung.com:device:RemoteControlReceiver:1",
  "urn:schemas-sony-com:service:ScalarWebAPI:1",
  "urn:schemas-upnp-org:device:MediaRenderer:2",
];

function parseHeaders(msg: string): Record<string, string> {
  const out: Record<string, string> = {};
  for (const line of msg.split(/\r?\n/).slice(1)) {
    const i = line.indexOf(":");
    if (i > 0) out[line.slice(0, i).trim().toLowerCase()] = line.slice(i + 1).trim();
  }
  return out;
}

/** Multicast M-SEARCH on every IPv4 interface. Resolves after `timeoutMs`. */
export function ssdpSearch(timeoutMs = 2500, targets: string[] = SEARCH_TARGETS): Promise<SsdpResponse[]> {
  const interfaces = localIPv4s();
  const results = new Map<string, SsdpResponse>();
  const sockets: dgram.Socket[] = [];

  const open = (address?: string) =>
    new Promise<void>((resolve) => {
      const sock = dgram.createSocket({ type: "udp4", reuseAddr: true });
      sockets.push(sock);
      sock.on("error", () => resolve());
      sock.on("message", (buf, rinfo) => {
        const h = parseHeaders(buf.toString("utf8"));
        const key = `${rinfo.address}|${h.st ?? ""}|${h.usn ?? ""}`;
        results.set(key, {
          ip: rinfo.address,
          location: h.location ?? null,
          st: h.st ?? null,
          usn: h.usn ?? null,
          server: h.server ?? null,
        });
      });
      sock.bind(0, address, () => {
        try {
          for (const st of targets) {
            const msg = Buffer.from(
              ["M-SEARCH * HTTP/1.1", "HOST: 239.255.255.250:1900", 'MAN: "ssdp:discover"', "MX: 2", `ST: ${st}`, "", ""].join("\r\n"),
            );
            sock.send(msg, 1900, "239.255.255.250");
          }
        } catch {
          /* interface cannot multicast */
        }
        resolve();
      });
    });

  return (async () => {
    await Promise.all((interfaces.length ? interfaces.map((i) => i.address) : [undefined]).map(open));
    await new Promise((r) => setTimeout(r, timeoutMs));
    for (const s of sockets) {
      try {
        s.close();
      } catch {
        /* already closed */
      }
    }
    return [...results.values()];
  })();
}
