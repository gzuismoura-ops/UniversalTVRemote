/** Pure reconnection policy (unit-tested). */

export interface ReconnectInput {
  attempts: number; // consecutive failures so far
  authState: "none" | "paired" | "revoked";
  errorKind?: "network" | "auth";
}

export type ReconnectDecision =
  | { action: "retry"; delayMs: number }
  | { action: "needs-pairing" }
  | { action: "give-up" };

export const BASE_DELAY_MS = 1500;
export const MAX_DELAY_MS = 60_000;
export const MAX_ATTEMPTS = 40;

export function backoffDelay(attempts: number): number {
  const exp = Math.min(MAX_DELAY_MS, BASE_DELAY_MS * 2 ** Math.max(0, attempts));
  return Math.round(exp);
}

/**
 * Re-pairing is requested ONLY when technically necessary:
 *  - the TV explicitly rejected our credential (errorKind "auth"), or
 *  - we never had a credential for a brand that requires one.
 * Plain network failures (Wi‑Fi drop, TV off) never trigger a new pairing.
 */
export function decideReconnect(input: ReconnectInput): ReconnectDecision {
  if (input.errorKind === "auth") return { action: "needs-pairing" };
  if (input.authState === "revoked") return { action: "needs-pairing" };
  if (input.attempts >= MAX_ATTEMPTS) return { action: "give-up" };
  return { action: "retry", delayMs: backoffDelay(input.attempts) };
}
