import { TvError } from "./net";

export function json(data: unknown, status = 200) {
  return Response.json(data, { status, headers: { "Cache-Control": "no-store" } });
}

export function fail(err: unknown) {
  if (err instanceof TvError) {
    const status = err.kind === "unsupported" ? 422 : err.kind === "auth" ? 401 : err.kind === "timeout" ? 504 : 502;
    return json({ error: err.message, kind: err.kind }, status);
  }
  const msg = err instanceof Error ? err.message : "Erro inesperado";
  return json({ error: msg, kind: "internal" }, 500);
}

export async function body<T = Record<string, unknown>>(req: Request): Promise<T> {
  try {
    return (await req.json()) as T;
  } catch {
    return {} as T;
  }
}
