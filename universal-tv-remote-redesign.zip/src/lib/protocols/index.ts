import type { Brand, Capabilities, Command, Feature } from "../commands";
import { androidTvModule } from "./androidtv";
import { chromecastModule } from "./chromecast";
import { dlnaModule } from "./dlna";
import { lgModule } from "./lg";
import { panasonicModule } from "./panasonic";
import { philipsModule } from "./philips";
import { rokuModule } from "./roku";
import { samsungModule } from "./samsung";
import { sonyModule } from "./sony";
import { vizioModule } from "./vizio";
import type { DeviceIdentity, ProtocolModule } from "./types";

export const MODULES: Record<Brand, ProtocolModule> = {
  lg: lgModule,
  samsung: samsungModule,
  sony: sonyModule,
  androidtv: androidTvModule,
  roku: rokuModule,
  philips: philipsModule,
  panasonic: panasonicModule,
  vizio: vizioModule,
  chromecast: chromecastModule,
  dlna: dlnaModule,
};

export function getModule(brand: string): ProtocolModule | null {
  return (MODULES as Record<string, ProtocolModule | undefined>)[brand] ?? null;
}

/**
 * Capabilities are derived from the adapter's real key map + features.
 * Casting / transport features depend on a DLNA renderer being known for the
 * device (Roku can additionally cast through its Media Player channel).
 */
export function capabilitiesFor(brand: string, meta: Record<string, unknown> = {}): Capabilities {
  const m = getModule(brand);
  if (!m) return { commands: [], features: [] };
  const hasDlna = typeof meta.dlnaLocation === "string" && meta.dlnaLocation.length > 0;
  const features = m.features.filter((f: Feature) => {
    if (f === "cast") return hasDlna || brand === "roku" || brand === "dlna";
    if (f === "mediaControl") return hasDlna || brand === "dlna";
    return true;
  });
  if (hasDlna && !features.includes("cast") && brand !== "chromecast") features.push("cast", "mediaControl");
  return { commands: Object.keys(m.keymap) as Command[], features };
}

// Priority when several probes answer.
const PRIORITY: Brand[] = ["roku", "samsung", "sony", "philips", "panasonic", "vizio", "lg", "androidtv", "chromecast"];

/** Runs every adapter's probe in parallel and returns the best match. */
export async function identify(ip: string): Promise<DeviceIdentity | null> {
  const results = await Promise.all(PRIORITY.map((b) => MODULES[b].probe(ip).catch(() => null)));
  const found = results.find((r) => r !== null) ?? null;
  if (found) return found;
  return dlnaModule.probe(ip).catch(() => null);
}
