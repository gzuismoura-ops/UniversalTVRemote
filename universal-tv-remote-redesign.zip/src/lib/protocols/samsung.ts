import WebSocket from "ws";
import type { AppDTO, Command } from "../commands";
import { DlnaRenderer, type MediaItem } from "../dlna";
import { httpJson, httpRequest, normalizeMac, TvError, tcpProbe } from "../net";
import { dlnaMedia } from "./lg";
import type { DeviceIdentity, DriverContext, MediaAction, PairingContext, PairingResult, ProtocolModule, TvDriver } from "./types";

/**
 * Samsung Tizen "SmartView" remote API (wss :8002, ws :8001).
 * First connection: the TV shows "Allow" and sends a `token` inside
 * `ms.channel.connect`. The token is persisted (encrypted) and appended to
 * the URL on later connections so the prompt is not shown again.
 */
export const SAMSUNG_KEYMAP: Partial<Record<Command, string>> = {
  power: "KEY_POWER",
  up: "KEY_UP",
  down: "KEY_DOWN",
  left: "KEY_LEFT",
  right: "KEY_RIGHT",
  ok: "KEY_ENTER",
  back: "KEY_RETURN",
  home: "KEY_HOME",
  menu: "KEY_MENU",
  settings: "KEY_TOOLS",
  source: "KEY_SOURCE",
  volUp: "KEY_VOLUP",
  volDown: "KEY_VOLDOWN",
  mute: "KEY_MUTE",
  chUp: "KEY_CHUP",
  chDown: "KEY_CHDOWN",
  num0: "KEY_0",
  num1: "KEY_1",
  num2: "KEY_2",
  num3: "KEY_3",
  num4: "KEY_4",
  num5: "KEY_5",
  num6: "KEY_6",
  num7: "KEY_7",
  num8: "KEY_8",
  num9: "KEY_9",
  guide: "KEY_GUIDE",
  info: "KEY_INFO",
  play: "KEY_PLAY",
  pause: "KEY_PAUSE",
  stop: "KEY_STOP",
  rewind: "KEY_REWIND",
  forward: "KEY_FF",
  red: "KEY_RED",
  green: "KEY_GREEN",
  yellow: "KEY_YELLOW",
  blue: "KEY_CYAN",
};

// Fallback launcher IDs for popular apps when the TV does not return its installed list (newer firmwares).
const KNOWN_APPS: AppDTO[] = [
  { id: "11101200001", name: "Netflix", icon: null, catalog: true },
  { id: "111299001912", name: "YouTube", icon: null, catalog: true },
  { id: "3201512006785", name: "Prime Video", icon: null, catalog: true },
  { id: "3201901017640", name: "Disney+", icon: null, catalog: true },
  { id: "3201606009684", name: "Spotify", icon: null, catalog: true },
];

interface SamMsg {
  event?: string;
  data?: { token?: string | number; data?: unknown; message?: string; [k: string]: unknown } | unknown[];
}

export class SamsungSession {
  private ws: WebSocket | null = null;
  private waiters: ((m: SamMsg) => void)[] = [];
  token: string | null;
  constructor(private ip: string, token: string | null, private name: string, private onToken?: (t: string) => void, private onPrompt?: () => void) {
    this.token = token;
  }

  get alive() {
    return !!this.ws && this.ws.readyState === WebSocket.OPEN;
  }

  private connectOnce(secure: boolean): Promise<void> {
    return new Promise((resolve, reject) => {
      const nameB64 = Buffer.from(this.name).toString("base64");
      const url = secure
        ? `wss://${this.ip}:8002/api/v2/channels/samsung.remote.api.v2?name=${encodeURIComponent(nameB64)}${this.token ? `&token=${encodeURIComponent(this.token)}` : ""}`
        : `ws://${this.ip}:8001/api/v2/channels/samsung.remote.api.v2?name=${encodeURIComponent(nameB64)}`;
      // Self-signed TV certificate: relaxed for this one socket to the TV only.
      const ws = new WebSocket(url, { handshakeTimeout: 5000, rejectUnauthorized: false });
      let settled = false;
      const waitMs = this.token ? 10_000 : 60_000; // no token => user must tap "Allow" on the TV
      const timer = setTimeout(() => {
        if (!settled) {
          settled = true;
          ws.close();
          reject(new TvError(this.token ? "Samsung: a TV não confirmou o token salvo" : "Samsung: autorização não concedida na TV", this.token ? "auth" : "timeout"));
        }
      }, waitMs);
      const fail = (e: TvError) => {
        if (settled) return;
        settled = true;
        clearTimeout(timer);
        reject(e);
      };
      ws.on("error", (e) => fail(new TvError(`Samsung: ${(e as Error).message}`)));
      ws.on("close", () => {
        if (this.ws === ws) this.ws = null;
        fail(new TvError("Samsung: conexão encerrada"));
      });
      ws.on("message", (raw) => {
        let m: SamMsg;
        try {
          m = JSON.parse(raw.toString());
        } catch {
          return;
        }
        for (const w of [...this.waiters]) w(m);
        if (m.event === "ms.channel.connect" && !settled) {
          settled = true;
          clearTimeout(timer);
          const tok = (m.data as { token?: string | number } | undefined)?.token;
          if (tok !== undefined && String(tok) !== this.token) {
            this.token = String(tok);
            this.onToken?.(this.token);
          }
          this.ws = ws;
          resolve();
        } else if (m.event === "ms.channel.clientConnect") {
          this.onPrompt?.();
        } else if ((m.event === "ms.channel.unauthorized" || m.event === "ms.channel.timeOut") && !settled) {
          settled = true;
          clearTimeout(timer);
          ws.close();
          reject(new TvError("Samsung: acesso negado pela TV", "auth"));
        }
      });
    });
  }

  async open() {
    try {
      await this.connectOnce(true);
    } catch (e) {
      if ((e as TvError).kind === "auth") throw e;
      // Older (pre-2016) models only expose plain ws://:8001 and need no token.
      if (!(await tcpProbe(this.ip, 8002, 800))) await this.connectOnce(false);
      else throw e;
    }
  }

  private emit(payload: unknown) {
    if (!this.alive) throw new TvError("Samsung desconectada");
    this.ws!.send(JSON.stringify(payload));
  }

  key(code: string) {
    this.emit({ method: "ms.remote.control", params: { Cmd: "Click", DataOfCmd: code, Option: "false", TypeOfRemote: "SendRemoteKey" } });
  }

  text(t: string) {
    this.emit({ method: "ms.remote.control", params: { Cmd: Buffer.from(t).toString("base64"), DataOfCmd: "base64", Option: "false", TypeOfRemote: "SendInputString" } });
  }

  request(payload: unknown, event: string, timeoutMs = 5000): Promise<SamMsg> {
    return new Promise((resolve, reject) => {
      const t = setTimeout(() => {
        this.waiters = this.waiters.filter((w) => w !== h);
        reject(new TvError("Samsung: sem resposta", "timeout"));
      }, timeoutMs);
      const h = (m: SamMsg) => {
        if (m.event === event) {
          clearTimeout(t);
          this.waiters = this.waiters.filter((w) => w !== h);
          resolve(m);
        }
      };
      this.waiters.push(h);
      try {
        this.emit(payload);
      } catch (e) {
        clearTimeout(t);
        reject(e);
      }
    });
  }

  sendRaw(payload: unknown) {
    this.emit(payload);
  }

  close() {
    this.ws?.close();
    this.ws = null;
  }
}

class SamsungDriver implements TvDriver {
  private s: SamsungSession | null = null;
  constructor(private ctx: DriverContext) {}

  async connect() {
    this.disconnect();
    const token = (this.ctx.credentials?.token as string | undefined) ?? null;
    const s = new SamsungSession(this.ctx.ip, token, this.ctx.clientName, (t) => void this.ctx.saveCredentials({ token: t }));
    await s.open();
    this.s = s;
  }
  disconnect() {
    this.s?.close();
    this.s = null;
  }
  isAlive() {
    return !!this.s?.alive;
  }
  async ping() {
    if (!this.s?.alive) throw new TvError("Samsung desconectada");
    const r = await httpRequest(`http://${this.ctx.ip}:8001/api/v2/`, { timeoutMs: 2500 });
    if (r.status !== 200) throw new TvError(`Samsung respondeu ${r.status}`);
  }
  private need() {
    if (!this.s?.alive) throw new TvError("Samsung desconectada");
    return this.s;
  }
  async send(cmd: Command) {
    const k = SAMSUNG_KEYMAP[cmd];
    if (!k) throw new TvError("Comando não suportado nesta TV", "unsupported");
    this.need().key(k);
  }
  async listApps(): Promise<AppDTO[]> {
    try {
      const m = await this.need().request({ method: "ms.channel.emit", params: { event: "ed.installedApp.get", to: "host" } }, "ed.installedApp.get", 4000);
      const list = ((m.data as { data?: { appId: string; name: string; icon?: string }[] } | undefined)?.data ?? []) as { appId: string; name: string }[];
      if (Array.isArray(list) && list.length) return list.map((a) => ({ id: a.appId, name: a.name, icon: null }));
    } catch {
      /* newer firmware: not supported */
    }
    return KNOWN_APPS;
  }
  async launchApp(id: string) {
    if (!/^[\w.-]+$/.test(id)) throw new TvError("ID de app inválido");
    const r = await httpRequest(`http://${this.ctx.ip}:8001/api/v2/applications/${id}`, { method: "POST", body: "", timeoutMs: 5000 }).catch(() => null);
    if (r && r.status < 300) return;
    this.need().sendRaw({ method: "ms.channel.emit", params: { event: "ed.apps.launch", to: "host", data: { action_type: "NATIVE_LAUNCH", appId: id } } });
  }
  async sendText(text: string) {
    this.need().text(text);
  }
  private dlna() {
    const loc = this.ctx.meta.dlnaLocation as string | undefined;
    if (!loc) throw new TvError("DLNA não detectada nesta TV", "unsupported");
    return new DlnaRenderer(loc);
  }
  async cast(item: MediaItem) {
    await this.dlna().cast(item);
  }
  async media(action: MediaAction, value?: number) {
    return dlnaMedia(this.dlna(), action, value);
  }
}

export const samsungModule: ProtocolModule = {
  brand: "samsung",
  keymap: SAMSUNG_KEYMAP,
  features: ["apps", "text", "cast", "mediaControl", "wol"],
  ports: [8001, 8002],
  requiresCredentials: true,
  async probe(ip): Promise<DeviceIdentity | null> {
    try {
      const { status, json } = await httpJson<{ device?: { name?: string; modelName?: string; wifiMac?: string; id?: string; type?: string } }>(`http://${ip}:8001/api/v2/`, { timeoutMs: 1500 });
      if (status !== 200 || !json?.device) return null;
      const d = json.device;
      return {
        brand: "samsung",
        name: (d.name ?? "Samsung TV").replace(/^\[TV\]\s*/, ""),
        model: d.modelName ?? null,
        mac: normalizeMac(d.wifiMac),
        uniqueId: d.id ?? null,
        port: 8002,
      };
    } catch {
      return null;
    }
  },
  async beginPairing(ctx: PairingContext): Promise<PairingResult> {
    let token: string | null = null;
    const s = new SamsungSession(ctx.ip, null, ctx.clientName, (t) => (token = t), ctx.onPrompt);
    try {
      await s.open();
      return { status: "paired", credentials: token ? { token } : null, identity: {} };
    } finally {
      s.close();
    }
  },
  createDriver: (ctx) => new SamsungDriver(ctx),
};
