import type { Command } from "../commands";
import { DlnaRenderer, fetchDlnaDescription, findDlnaLocation, type MediaItem } from "../dlna";
import { TvError } from "../net";
import { dlnaMedia } from "./lg";
import type { DeviceIdentity, DriverContext, MediaAction, ProtocolModule, TvDriver } from "./types";

/** Generic UPnP/DLNA MediaRenderer: no key remote, only casting + transport + volume. */
class DlnaDriver implements TvDriver {
  private alive = false;
  private r: DlnaRenderer;
  constructor(private ctx: DriverContext) {
    const loc = ctx.meta.dlnaLocation as string | undefined;
    if (!loc) throw new TvError("Localização DLNA desconhecida; adicione o dispositivo por descoberta", "unsupported");
    this.r = new DlnaRenderer(loc);
  }
  async connect() {
    await this.r.ping();
    this.alive = true;
  }
  disconnect() {
    this.alive = false;
  }
  isAlive() {
    return this.alive;
  }
  async ping() {
    await this.r.ping();
  }
  async send(_cmd: Command): Promise<void> {
    throw new TvError("Dispositivos DLNA não possuem controle por teclas", "unsupported");
  }
  async cast(item: MediaItem) {
    await this.r.cast(item);
  }
  async media(action: MediaAction, value?: number) {
    return dlnaMedia(this.r, action, value);
  }
}

export const dlnaModule: ProtocolModule = {
  brand: "dlna",
  keymap: {},
  features: ["cast", "mediaControl", "volumeSlider"],
  ports: [],
  requiresCredentials: false,
  async probe(ip): Promise<DeviceIdentity | null> {
    const loc = await findDlnaLocation(ip);
    if (!loc) return null;
    const d = await fetchDlnaDescription(loc).catch(() => null);
    if (!d?.avTransport) return null;
    return { brand: "dlna", name: d.friendlyName ?? "Dispositivo DLNA", model: d.modelName, uniqueId: d.udn, meta: { dlnaLocation: loc } };
  },
  async beginPairing(ctx) {
    return { status: "paired", credentials: null, identity: ctx.identity };
  },
  createDriver: (ctx) => new DlnaDriver(ctx),
};
