import type { Command } from "../commands";
import { TvError, tcpProbe } from "../net";
import type { DeviceIdentity, DriverContext, ProtocolModule, TvDriver } from "./types";

/**
 * Chromecast (CASTV2, TLS :8009, protobuf channels).
 * HONEST STATUS: the device is discovered and reachability is monitored, but
 * the CASTV2 media/receiver channels are NOT implemented in this build, so no
 * command is advertised as supported. Use an Android TV / Google TV profile
 * (Chromecast with Google TV) for remote-control keys.
 */
class ChromecastDriver implements TvDriver {
  private alive = false;
  constructor(private ctx: DriverContext) {}
  async connect() {
    await this.ping();
    this.alive = true;
  }
  disconnect() {
    this.alive = false;
  }
  isAlive() {
    return this.alive;
  }
  async ping() {
    if ((await tcpProbe(this.ctx.ip, 8009, 1500)) === null) throw new TvError("Chromecast inacessível");
  }
  async send(_cmd: Command): Promise<void> {
    throw new TvError("Controle CASTV2 do Chromecast ainda não implementado", "unsupported");
  }
}

export const chromecastModule: ProtocolModule = {
  brand: "chromecast",
  keymap: {},
  features: [],
  ports: [8009],
  requiresCredentials: false,
  async probe(ip): Promise<DeviceIdentity | null> {
    if ((await tcpProbe(ip, 8009, 1000)) === null) return null;
    return { brand: "chromecast", name: "Chromecast", port: 8009 };
  },
  async beginPairing(ctx) {
    return { status: "paired", credentials: null, identity: ctx.identity };
  },
  createDriver: (ctx) => new ChromecastDriver(ctx),
};
