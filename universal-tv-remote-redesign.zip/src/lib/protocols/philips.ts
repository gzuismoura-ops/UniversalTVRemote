import crypto from "node:crypto";
import type { AppDTO, Command } from "../commands";
import { httpJson, httpRequest, TvError } from "../net";
import type { Credentials, DeviceIdentity, DriverContext, PairingContext, PairingResult, ProtocolModule, TvDriver } from "./types";

/**
 * Philips JointSPACE v6 (HTTPS :1926, digest auth after PIN pairing) with a
 * v1 fallback (HTTP :1925, no auth) for old sets.
 * Credential = { id, authKey } (digest username/password).
 */
export const PHILIPS_KEYMAP: Partial<Record<Command, string>> = {
  power: "Standby",
  up: "CursorUp",
  down: "CursorDown",
  left: "CursorLeft",
  right: "CursorRight",
  ok: "Confirm",
  back: "Back",
  home: "Home",
  menu: "Options",
  source: "Source",
  volUp: "VolumeUp",
  volDown: "VolumeDown",
  mute: "Mute",
  chUp: "ChannelStepUp",
  chDown: "ChannelStepDown",
  num0: "Digit0",
  num1: "Digit1",
  num2: "Digit2",
  num3: "Digit3",
  num4: "Digit4",
  num5: "Digit5",
  num6: "Digit6",
  num7: "Digit7",
  num8: "Digit8",
  num9: "Digit9",
  info: "Info",
  play: "Play",
  pause: "Pause",
  stop: "Stop",
  rewind: "Rewind",
  forward: "FastForward",
  next: "Next",
  prev: "Previous",
  red: "RedColour",
  green: "GreenColour",
  yellow: "YellowColour",
  blue: "BlueColour",
};

// Public constant used by the official Philips remote apps for pairing signatures.
const PAIRING_SECRET = "ZmVay1EQVFOaZhwQ4Kv81ypLAZNczV9sG4KkseXWn1NEk6cXmPKO/MCa9sryslvLCFMnNe4Z4CPXzToowvhHvA==";

const md5 = (s: string) => crypto.createHash("md5").update(s).digest("hex");

async function digestRequest(url: string, user: string, pass: string, method: string, body?: unknown) {
  const payload = body === undefined ? undefined : JSON.stringify(body);
  const base = { method, body: payload, insecureTls: true, timeoutMs: 5000, headers: { "Content-Type": "application/json" } as Record<string, string> };
  const first = await httpRequest(url, base);
  if (first.status !== 401) return first;
  const h = String(first.headers["www-authenticate"] ?? "");
  const get = (k: string) => new RegExp(`${k}="?([^",]+)"?`).exec(h)?.[1] ?? "";
  const realm = get("realm");
  const nonce = get("nonce");
  const qop = get("qop").split(",")[0] || "auth";
  const u = new URL(url);
  const uri = u.pathname + u.search;
  const nc = "00000001";
  const cnonce = crypto.randomBytes(8).toString("hex");
  const ha1 = md5(`${user}:${realm}:${pass}`);
  const ha2 = md5(`${method}:${uri}`);
  const response = md5(`${ha1}:${nonce}:${nc}:${cnonce}:${qop}:${ha2}`);
  const auth = `Digest username="${user}", realm="${realm}", nonce="${nonce}", uri="${uri}", qop=${qop}, nc=${nc}, cnonce="${cnonce}", response="${response}", algorithm=MD5`;
  return httpRequest(url, { ...base, headers: { ...base.headers, Authorization: auth } });
}

class PhilipsDriver implements TvDriver {
  private alive = false;
  private v6 = true;
  constructor(private ctx: DriverContext) {}
  private get cred() {
    return this.ctx.credentials as { id?: string; authKey?: string } | null;
  }
  private url(path: string) {
    return this.v6 ? `https://${this.ctx.ip}:1926/6/${path}` : `http://${this.ctx.ip}:1925/1/${path}`;
  }
  private async call(path: string, method = "GET", body?: unknown) {
    if (!this.v6) {
      return httpRequest(this.url(path), { method, body: body === undefined ? undefined : JSON.stringify(body), headers: { "Content-Type": "application/json" }, timeoutMs: 4000 });
    }
    const c = this.cred;
    if (!c?.id || !c.authKey) throw new TvError("Philips: sem credencial salva", "auth");
    const r = await digestRequest(this.url(path), c.id, c.authKey, method, body);
    if (r.status === 401 || r.status === 403) throw new TvError("Philips: credencial recusada pela TV", "auth");
    return r;
  }
  async connect() {
    this.v6 = !!(await httpRequest(`https://${this.ctx.ip}:1926/6/system`, { insecureTls: true, timeoutMs: 2000 }).then((r) => r.status > 0).catch(() => false));
    await this.ping();
    this.alive = true;
  }
  disconnect() {
    this.alive = false;
  }
  isAlive() {
    return this.alive;
  }
  async ping() {
    const r = await this.call("powerstate");
    if (r.status >= 400) throw new TvError(`Philips respondeu ${r.status}`);
  }
  async send(cmd: Command) {
    const key = PHILIPS_KEYMAP[cmd];
    if (!key) throw new TvError("Comando não suportado nesta TV", "unsupported");
    const r = await this.call("input/key", "POST", { key });
    if (r.status >= 400) throw new TvError(`Philips recusou o comando (${r.status})`);
  }
  async listApps(): Promise<AppDTO[]> {
    if (!this.v6) throw new TvError("Esta Philips (API v1) não lista aplicativos", "unsupported");
    const r = await this.call("applications");
    let list: { label?: string; id?: string }[] = [];
    try {
      list = JSON.parse(r.body).applications ?? [];
    } catch { /* empty */ }
    return list.filter((a) => a.id && a.label).map((a) => ({ id: a.id!, name: a.label!, icon: null }));
  }
  async launchApp(id: string) {
    const r = await this.call("applications");
    const app = (JSON.parse(r.body).applications ?? []).find((a: { id: string }) => a.id === id);
    if (!app?.intent) throw new TvError("Aplicativo não encontrado na TV");
    const l = await this.call("activities/launch", "POST", { intent: app.intent, order: app.order });
    if (l.status >= 400) throw new TvError(`Philips não abriu o app (${l.status})`);
  }
}

function deviceInfo(id: string) {
  return { app_id: "app.id", app_name: "Universal TV Remote", type: "native", device_name: "heliotrope", device_os: "Android", id };
}

export const philipsModule: ProtocolModule = {
  brand: "philips",
  keymap: PHILIPS_KEYMAP,
  features: ["apps", "pairingPin", "wol"],
  ports: [1925, 1926],
  requiresCredentials: true,
  async probe(ip): Promise<DeviceIdentity | null> {
    const attempts = [`https://${ip}:1926/6/system`, `http://${ip}:1925/1/system`];
    for (const url of attempts) {
      try {
        const { status, json } = await httpJson<{ name?: string; model?: string; api_version?: unknown }>(url, { insecureTls: true, timeoutMs: 1500 });
        if (status === 200 && json && (json.api_version || json.name)) {
          return { brand: "philips", name: json.name ? `Philips ${json.name}` : "Philips TV", model: json.model ?? null, port: url.includes("1926") ? 1926 : 1925 };
        }
      } catch { /* try next */ }
    }
    return null;
  },
  async beginPairing(ctx: PairingContext): Promise<PairingResult> {
    const v6 = await httpRequest(`https://${ctx.ip}:1926/6/system`, { insecureTls: true, timeoutMs: 2000 }).then((r) => r.status === 200).catch(() => false);
    if (!v6) return { status: "paired", credentials: null, identity: {} }; // API v1 needs no pairing
    const id = crypto.randomBytes(8).toString("hex");
    const res = await httpJson<{ auth_key?: string; timestamp?: number; error_id?: string }>(`https://${ctx.ip}:1926/6/pair/request`, {
      method: "POST",
      insecureTls: true,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ scope: ["read", "write", "control"], device: deviceInfo(id) }),
      timeoutMs: 8000,
    });
    if (!res.json?.auth_key) throw new TvError("Philips: a TV não iniciou o pareamento");
    return {
      status: "pin",
      state: { id, authKey: res.json.auth_key, timestamp: res.json.timestamp },
      message: "Digite o PIN de 4 dígitos exibido na TV.",
    };
  },
  async finishPairing(state, pin, ctx): Promise<PairingResult> {
    const s = state as { id: string; authKey: string; timestamp: number };
    const sig = crypto.createHmac("sha1", Buffer.from(PAIRING_SECRET, "base64")).update(`${s.timestamp}${pin.trim()}`).digest("base64");
    const body = { auth: { auth_AppId: "1", pin: pin.trim(), auth_timestamp: s.timestamp, auth_signature: sig }, device: deviceInfo(s.id) };
    const r = await digestRequest(`https://${ctx.ip}:1926/6/pair/grant`, s.id, s.authKey, "POST", body);
    if (r.status !== 200) throw new TvError("PIN incorreto ou expirado", "auth");
    const creds: Credentials = { id: s.id, authKey: s.authKey };
    return { status: "paired", credentials: creds, identity: {} };
  },
  createDriver: (ctx) => new PhilipsDriver(ctx),
};
