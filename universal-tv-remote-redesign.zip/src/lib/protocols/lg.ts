import WebSocket from "ws";
import type { AppDTO, Command } from "../commands";
import { DlnaRenderer, type MediaItem } from "../dlna";
import { TvError, tcpProbe } from "../net";
import type { DeviceIdentity, DriverContext, MediaAction, PairingContext, PairingResult, ProtocolModule, TvDriver } from "./types";

/**
 * LG webOS (SSAP over WebSocket, :3000 ws / :3001 wss).
 * Authorization: the TV shows a prompt on first register and returns a
 * `client-key`. That key is persisted (encrypted) and re-sent on every connect,
 * so the TV does not prompt again unless it revoked the key.
 *
 * keymap value prefixes:  ssap:<uri>  |  btn:<POINTER_BUTTON>  |  app:<launch id>
 */
export const LG_KEYMAP: Partial<Record<Command, string>> = {
  power: "ssap:system/turnOff",
  up: "btn:UP",
  down: "btn:DOWN",
  left: "btn:LEFT",
  right: "btn:RIGHT",
  ok: "btn:ENTER",
  back: "btn:BACK",
  home: "btn:HOME",
  menu: "btn:MENU",
  settings: "app:com.palm.app.settings",
  source: "app:com.webos.app.inputpicker",
  volUp: "ssap:audio/volumeUp",
  volDown: "ssap:audio/volumeDown",
  mute: "ssap:audio/setMute",
  chUp: "ssap:tv/channelUp",
  chDown: "ssap:tv/channelDown",
  num0: "btn:0",
  num1: "btn:1",
  num2: "btn:2",
  num3: "btn:3",
  num4: "btn:4",
  num5: "btn:5",
  num6: "btn:6",
  num7: "btn:7",
  num8: "btn:8",
  num9: "btn:9",
  guide: "btn:GUIDE",
  info: "btn:INFO",
  play: "ssap:media.controls/play",
  pause: "ssap:media.controls/pause",
  stop: "ssap:media.controls/stop",
  rewind: "ssap:media.controls/rewind",
  forward: "ssap:media.controls/fastForward",
  red: "btn:RED",
  green: "btn:GREEN",
  yellow: "btn:YELLOW",
  blue: "btn:BLUE",
};

const PERMISSIONS = [
  "LAUNCH", "LAUNCH_WEBAPP", "APP_TO_APP", "CLOSE", "TEST_OPEN", "TEST_PROTECTED", "CONTROL_AUDIO", "CONTROL_DISPLAY",
  "CONTROL_INPUT_JOYSTICK", "CONTROL_INPUT_MEDIA_RECORDING", "CONTROL_INPUT_MEDIA_PLAYBACK", "CONTROL_INPUT_TV",
  "CONTROL_POWER", "CONTROL_MOUSE_AND_KEYBOARD", "CONTROL_INPUT_TEXT", "READ_APP_STATUS", "READ_CURRENT_CHANNEL",
  "READ_INPUT_DEVICE_LIST", "READ_INSTALLED_APPS", "READ_NETWORK_STATE", "READ_RUNNING_APPS", "READ_TV_CHANNEL_LIST",
  "READ_POWER_STATE", "READ_COUNTRY_INFO", "WRITE_NOTIFICATION_TOAST",
];

// Unsigned manifest: no signing blob is shipped (a wrong signature would make the TV reject registration).
const MANIFEST = { manifestVersion: 1, appVersion: "1.1", permissions: PERMISSIONS };

type Pending = { resolve: (v: Record<string, unknown>) => void; reject: (e: Error) => void; timer: NodeJS.Timeout };

export class LgSession {
  private ws: WebSocket | null = null;
  private pointer: WebSocket | null = null;
  private pending = new Map<string, Pending>();
  private seq = 0;
  clientKey: string | null;
  constructor(private ip: string, key: string | null, private onKey?: (k: string) => void, private onPrompt?: () => void) {
    this.clientKey = key;
  }

  private openSocket(url: string): Promise<WebSocket> {
    return new Promise((resolve, reject) => {
      const ws = new WebSocket(url, {
        handshakeTimeout: 4000,
        // LG wss:3001 uses a self-signed cert. Relaxed ONLY for this socket to the TV.
        rejectUnauthorized: !url.startsWith("wss:"),
      });
      ws.once("open", () => resolve(ws));
      ws.once("error", (e) => reject(new TvError(`LG: ${(e as Error).message}`)));
    });
  }

  async open(): Promise<void> {
    let lastErr: Error | null = null;
    for (const url of [`ws://${this.ip}:3000`, `wss://${this.ip}:3001`]) {
      try {
        this.ws = await this.openSocket(url);
        break;
      } catch (e) {
        lastErr = e as Error;
      }
    }
    if (!this.ws) throw lastErr ?? new TvError("LG: sem resposta");
    const ws = this.ws;
    ws.on("message", (raw) => this.handle(raw.toString()));
    ws.on("close", () => {
      this.ws = null;
      this.pointer?.close();
      this.pointer = null;
      for (const [, p] of this.pending) {
        clearTimeout(p.timer);
        p.reject(new TvError("LG: conexão encerrada"));
      }
      this.pending.clear();
    });
    ws.on("error", () => undefined);
    await this.register();
  }

  private handle(raw: string) {
    let msg: { id?: string; type?: string; payload?: Record<string, unknown>; error?: string };
    try {
      msg = JSON.parse(raw);
    } catch {
      return;
    }
    if (!msg.id) return;
    const p = this.pending.get(msg.id);
    if (!p) return;
    if (msg.type === "response" && msg.payload?.pairingType === "PROMPT") {
      this.onPrompt?.(); // keep waiting for user to accept on the TV
      return;
    }
    clearTimeout(p.timer);
    this.pending.delete(msg.id);
    if (msg.type === "error") {
      const text = msg.error ?? "erro";
      p.reject(new TvError(`LG: ${text}`, /401|insufficient|denied|cancel/i.test(text) ? "auth" : "network"));
    } else {
      p.resolve(msg.payload ?? {});
    }
  }

  private request(type: string, uri: string | null, payload: Record<string, unknown> | undefined, timeoutMs = 8000, id = `r_${++this.seq}`): Promise<Record<string, unknown>> {
    return new Promise((resolve, reject) => {
      if (!this.ws || this.ws.readyState !== WebSocket.OPEN) return reject(new TvError("LG desconectada"));
      const timer = setTimeout(() => {
        this.pending.delete(id);
        reject(new TvError("LG: tempo esgotado", "timeout"));
      }, timeoutMs);
      this.pending.set(id, { resolve, reject, timer });
      const msg: Record<string, unknown> = { id, type };
      if (uri) msg.uri = uri;
      if (payload) msg.payload = payload;
      this.ws.send(JSON.stringify(msg));
    });
  }

  private async register() {
    const payload: Record<string, unknown> = {
      forcePairing: false,
      pairingType: "PROMPT",
      manifest: MANIFEST,
    };
    if (this.clientKey) payload["client-key"] = this.clientKey;
    // When there is no stored key the TV shows the authorization prompt; wait up to 60 s.
    const res = await this.request("register", null, payload, this.clientKey ? 10_000 : 60_000, "register_0").catch((e: TvError) => {
      if (this.clientKey && e.kind !== "timeout") e.kind = "auth";
      if (this.clientKey && e.kind === "timeout") e.kind = "auth"; // no answer to a known key = rejected/needs prompt
      throw e;
    });
    const key = res["client-key"] as string | undefined;
    if (key) {
      if (key !== this.clientKey) this.onKey?.(key);
      this.clientKey = key;
    } else {
      throw new TvError("LG: a TV não devolveu a chave de pareamento", "auth");
    }
  }

  async call(uri: string, payload?: Record<string, unknown>): Promise<Record<string, unknown>> {
    return this.request("request", `ssap://${uri}`, payload);
  }

  async button(name: string): Promise<void> {
    if (!this.pointer || this.pointer.readyState !== WebSocket.OPEN) {
      const r = await this.call("com.webos.service.networkinput/getPointerInputSocket");
      const path = r.socketPath as string | undefined;
      if (!path) throw new TvError("LG: socket de entrada indisponível");
      const url = path.startsWith("wss:") || path.startsWith("ws:") ? path : `ws://${this.ip}:3000${path}`;
      const fixed = url.replace(/^(wss?:\/\/)[^/:]+/, `$1${this.ip}`);
      this.pointer = await this.openSocket(fixed);
      this.pointer.on("close", () => (this.pointer = null));
      this.pointer.on("error", () => undefined);
    }
    this.pointer.send(`type:button\nname:${name}\n\n`);
  }

  get open_(): boolean {
    return !!this.ws && this.ws.readyState === WebSocket.OPEN;
  }
  close() {
    this.pointer?.close();
    this.ws?.close();
  }
}

class LgDriver implements TvDriver {
  private session: LgSession | null = null;
  private muted = false;
  constructor(private ctx: DriverContext) {}

  async connect() {
    this.disconnect();
    const key = (this.ctx.credentials?.clientKey as string | undefined) ?? null;
    const s = new LgSession(this.ctx.ip, key, (k) => void this.ctx.saveCredentials({ clientKey: k }));
    await s.open();
    this.session = s;
  }
  disconnect() {
    this.session?.close();
    this.session = null;
  }
  isAlive() {
    return !!this.session?.open_;
  }
  async ping() {
    if (!this.session) throw new TvError("LG desconectada");
    await this.session.call("com.webos.service.update/getCurrentSWInformation").catch(async () => {
      await this.session!.call("audio/getVolume");
    });
  }
  async send(cmd: Command) {
    const spec = LG_KEYMAP[cmd];
    if (!spec) throw new TvError("Comando não suportado nesta TV", "unsupported");
    const s = this.need();
    const [kind, arg] = [spec.slice(0, spec.indexOf(":")), spec.slice(spec.indexOf(":") + 1)];
    if (kind === "btn") return s.button(arg);
    if (kind === "app") {
      await s.call("system.launcher/launch", { id: arg });
      return;
    }
    if (arg === "audio/setMute") {
      this.muted = !this.muted;
      await s.call(arg, { mute: this.muted });
      return;
    }
    await s.call(arg);
  }
  private need(): LgSession {
    if (!this.session?.open_) throw new TvError("LG desconectada");
    return this.session;
  }
  async listApps(): Promise<AppDTO[]> {
    const r = await this.need().call("com.webos.applicationManager/listLaunchPoints");
    const lp = (r.launchPoints as { id?: string; title?: string; icon?: string; largeIcon?: string }[] | undefined) ?? [];
    return lp
      .filter((a) => a.id && a.title)
      .map((a) => ({ id: a.id!, name: a.title!, icon: a.largeIcon || a.icon || null }));
  }
  async launchApp(id: string) {
    await this.need().call("system.launcher/launch", { id });
  }
  async sendText(text: string) {
    await this.need().call("com.webos.service.ime/insertText", { text, replace: 0 });
  }
  async cast(item: MediaItem) {
    const loc = this.ctx.meta.dlnaLocation as string | undefined;
    if (!loc) throw new TvError("DLNA não detectada nesta TV", "unsupported");
    await new DlnaRenderer(loc).cast(item);
  }
  async media(action: MediaAction, value?: number) {
    const loc = this.ctx.meta.dlnaLocation as string | undefined;
    if (!loc) throw new TvError("DLNA não detectada nesta TV", "unsupported");
    return dlnaMedia(new DlnaRenderer(loc), action, value);
  }
}

export async function dlnaMedia(r: DlnaRenderer, action: MediaAction, value?: number): Promise<Record<string, unknown> | void> {
  switch (action) {
    case "play": return r.play();
    case "pause": return r.pause();
    case "stop": return r.stop();
    case "seek": return r.seek(value ?? 0);
    case "volume": return r.setVolume(value ?? 0);
    case "mute": return r.setMute((value ?? 1) > 0);
    case "status": {
      const p = await r.position();
      let volume: number | null = null;
      try { volume = await r.getVolume(); } catch { /* optional */ }
      return { ...p, volume };
    }
  }
}

export const lgModule: ProtocolModule = {
  brand: "lg",
  keymap: LG_KEYMAP,
  features: ["apps", "text", "cast", "mediaControl", "wol"],
  ports: [3000, 3001],
  requiresCredentials: true,
  async probe(ip): Promise<DeviceIdentity | null> {
    const [a, b] = await Promise.all([tcpProbe(ip, 3000, 1000), tcpProbe(ip, 3001, 1000)]);
    if (a === null && b === null) return null;
    return { brand: "lg", name: "LG webOS TV", model: null, port: a !== null ? 3000 : 3001 };
  },
  async beginPairing(ctx: PairingContext): Promise<PairingResult> {
    let key: string | null = null;
    const s = new LgSession(ctx.ip, null, (k) => (key = k), ctx.onPrompt);
    try {
      await s.open();
      let model: string | null = null;
      let name: string | null = null;
      try {
        const info = await s.call("system/getSystemInfo");
        model = (info.modelName as string) ?? null;
        const sw = await s.call("com.webos.service.update/getCurrentSWInformation");
        model = (sw.model_name as string) ?? model;
        name = (sw.product_name as string) ?? null;
      } catch { /* optional metadata */ }
      if (!key) throw new TvError("LG: a TV não devolveu a chave", "auth");
      return {
        status: "paired",
        credentials: { clientKey: key },
        identity: { model, ...(name ? { name: `LG ${model ?? "webOS TV"}` } : {}) },
      };
    } finally {
      s.close();
    }
  },
  createDriver: (ctx) => new LgDriver(ctx),
};
