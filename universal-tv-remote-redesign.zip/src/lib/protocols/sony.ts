import crypto from "node:crypto";
import type { AppDTO, Command } from "../commands";
import { DlnaRenderer, type MediaItem } from "../dlna";
import { httpJson, httpRequest, normalizeMac, TvError, xmlEscape } from "../net";
import { dlnaMedia } from "./lg";
import type { Credentials, DeviceIdentity, DriverContext, MediaAction, PairingContext, PairingResult, ProtocolModule, TvDriver } from "./types";

/**
 * Sony Bravia — REST (/sony/*) + IRCC (SOAP). Authorization is either
 *  - PIN registration  → cookie `auth=…` (persisted encrypted; Sony cookies can expire), or
 *  - Pre-Shared Key    → header X-Auth-PSK (configured by the user on the TV).
 *
 * keymap values are IRCC *names*. The real codes are read from the TV
 * (`getRemoteControllerInfo`) on connect; IRCC_FALLBACK is only a fallback.
 */
export const SONY_KEYMAP: Partial<Record<Command, string>> = {
  power: "Power",
  up: "Up",
  down: "Down",
  left: "Left",
  right: "Right",
  ok: "Confirm",
  back: "Return",
  home: "Home",
  menu: "Options",
  source: "Input",
  volUp: "VolumeUp",
  volDown: "VolumeDown",
  mute: "Mute",
  chUp: "ChannelUp",
  chDown: "ChannelDown",
  num0: "Num0",
  num1: "Num1",
  num2: "Num2",
  num3: "Num3",
  num4: "Num4",
  num5: "Num5",
  num6: "Num6",
  num7: "Num7",
  num8: "Num8",
  num9: "Num9",
  guide: "EPG",
  info: "Display",
  play: "Play",
  pause: "Pause",
  stop: "Stop",
  rewind: "Rewind",
  forward: "Forward",
  next: "Next",
  prev: "Prev",
  red: "Red",
  green: "Green",
  yellow: "Yellow",
  blue: "Blue",
};

const IRCC_FALLBACK: Record<string, string> = {
  Power: "AAAAAQAAAAEAAAAVAw==", Up: "AAAAAQAAAAEAAAB0Aw==", Down: "AAAAAQAAAAEAAAB1Aw==", Left: "AAAAAQAAAAEAAAA0Aw==",
  Right: "AAAAAQAAAAEAAAAzAw==", Confirm: "AAAAAQAAAAEAAABlAw==", Home: "AAAAAQAAAAEAAABgAw==", Return: "AAAAAgAAAJcAAAAjAw==",
  Options: "AAAAAgAAAJcAAAA2Aw==", Display: "AAAAAQAAAAEAAAA6Aw==", Input: "AAAAAQAAAAEAAAAlAw==", VolumeUp: "AAAAAQAAAAEAAAASAw==",
  VolumeDown: "AAAAAQAAAAEAAAATAw==", Mute: "AAAAAQAAAAEAAAAUAw==", ChannelUp: "AAAAAQAAAAEAAAAQAw==", ChannelDown: "AAAAAQAAAAEAAAARAw==",
  Num1: "AAAAAQAAAAEAAAAAAw==", Num2: "AAAAAQAAAAEAAAABAw==", Num3: "AAAAAQAAAAEAAAACAw==", Num4: "AAAAAQAAAAEAAAADAw==",
  Num5: "AAAAAQAAAAEAAAAEAw==", Num6: "AAAAAQAAAAEAAAAFAw==", Num7: "AAAAAQAAAAEAAAAGAw==", Num8: "AAAAAQAAAAEAAAAHAw==",
  Num9: "AAAAAQAAAAEAAAAIAw==", Num0: "AAAAAQAAAAEAAAAJAw==", Play: "AAAAAgAAAJcAAAAaAw==", Pause: "AAAAAgAAAJcAAAAZAw==",
  Stop: "AAAAAgAAAJcAAAAYAw==", Rewind: "AAAAAgAAAJcAAAAbAw==", Forward: "AAAAAgAAAJcAAAAcAw==", Prev: "AAAAAgAAAJcAAAA8Aw==",
  Next: "AAAAAgAAAJcAAAA9Aw==", Red: "AAAAAgAAAJcAAAAlAw==", Green: "AAAAAgAAAJcAAAAmAw==", Yellow: "AAAAAgAAAJcAAAAnAw==",
  Blue: "AAAAAgAAAJcAAAAkAw==", EPG: "AAAAAgAAAKQAAABbAw==",
};

function authHeaders(c: Credentials | null): Record<string, string> {
  if (c?.psk) return { "X-Auth-PSK": String(c.psk) };
  if (c?.cookie) return { Cookie: String(c.cookie) };
  return {};
}

async function rpc<T = unknown>(ip: string, svc: string, method: string, params: unknown[], creds: Credentials | null, version = "1.0"): Promise<T> {
  const { status, json } = await httpJson<{ result?: T; error?: [number, string] }>(`http://${ip}/sony/${svc}`, {
    method: "POST",
    headers: { "Content-Type": "application/json", ...authHeaders(creds) },
    body: JSON.stringify({ method, id: 1, params, version }),
    timeoutMs: 5000,
  });
  if (status === 401 || status === 403) throw new TvError("Sony: credencial recusada pela TV", "auth");
  if (!json || json.error) {
    const code = json?.error?.[0];
    if (code === 40005 || code === 7) throw new TvError("Sony: ação indisponível agora (TV em espera?)", "unsupported");
    throw new TvError(`Sony: ${json?.error?.[1] ?? `HTTP ${status}`}`);
  }
  return json.result as T;
}

class SonyDriver implements TvDriver {
  private alive = false;
  private codes: Record<string, string> = {};
  constructor(private ctx: DriverContext) {}

  async connect() {
    const c = this.ctx.credentials;
    // Validates the stored credential without prompting the TV again.
    await rpc(this.ctx.ip, "system", "getPowerStatus", [], c);
    try {
      const r = await rpc<[unknown, { name: string; value: string }[]]>(this.ctx.ip, "system", "getRemoteControllerInfo", [], c);
      this.codes = Object.fromEntries((r[1] ?? []).map((x) => [x.name, x.value]));
    } catch {
      this.codes = {};
    }
    this.alive = true;
  }
  disconnect() {
    this.alive = false;
  }
  isAlive() {
    return this.alive;
  }
  async ping() {
    await rpc(this.ctx.ip, "system", "getPowerStatus", [], this.ctx.credentials);
  }
  async send(cmd: Command) {
    const name = SONY_KEYMAP[cmd];
    if (!name) throw new TvError("Comando não suportado nesta TV", "unsupported");
    const code = this.codes[name] ?? IRCC_FALLBACK[name];
    if (!code) throw new TvError("Esta TV não expõe esse botão", "unsupported");
    const body = `<?xml version="1.0"?><s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/" s:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/"><s:Body><u:X_SendIRCC xmlns:u="urn:schemas-sony-com:service:IRCC:1"><IRCCCode>${code}</IRCCCode></u:X_SendIRCC></s:Body></s:Envelope>`;
    const r = await httpRequest(`http://${this.ctx.ip}/sony/IRCC`, {
      method: "POST",
      headers: { "Content-Type": 'text/xml; charset="UTF-8"', SOAPACTION: '"urn:schemas-sony-com:service:IRCC:1#X_SendIRCC"', ...authHeaders(this.ctx.credentials) },
      body,
      timeoutMs: 4000,
    });
    if (r.status === 403 || r.status === 401) throw new TvError("Sony: credencial recusada pela TV", "auth");
    if (r.status >= 400) throw new TvError(`Sony recusou o comando (${r.status})`);
  }
  async listApps(): Promise<AppDTO[]> {
    const r = await rpc<[{ title: string; uri: string; icon?: string }[]]>(this.ctx.ip, "appControl", "getApplicationList", [], this.ctx.credentials);
    return (r[0] ?? []).map((a) => ({ id: a.uri, name: a.title, icon: a.icon ?? null }));
  }
  async launchApp(id: string) {
    await rpc(this.ctx.ip, "appControl", "setActiveApp", [{ uri: id }], this.ctx.credentials);
  }
  async sendText(text: string) {
    await rpc(this.ctx.ip, "appControl", "setTextForm", [text], this.ctx.credentials);
  }
  private dlna() {
    const loc = this.ctx.meta.dlnaLocation as string | undefined;
    if (!loc) throw new TvError("DLNA não detectada nesta TV", "unsupported");
    return new DlnaRenderer(loc);
  }
  async cast(item: MediaItem) {
    await this.dlna().cast(item);
  }
  async media(action: MediaAction, value?: number) {
    return dlnaMedia(this.dlna(), action, value);
  }
}

function clientId(ctx: PairingContext) {
  return `utv-remote:${crypto.createHash("sha1").update(ctx.clientName).digest("hex").slice(0, 16)}`;
}

async function register(ip: string, cid: string, nickname: string, auth?: Record<string, string>) {
  return httpRequest(`http://${ip}/sony/accessControl`, {
    method: "POST",
    headers: { "Content-Type": "application/json", ...(auth ?? {}) },
    body: JSON.stringify({
      method: "actRegister",
      id: 8,
      version: "1.0",
      params: [{ clientid: cid, nickname: xmlEscape(nickname), level: "private" }, [{ value: "yes", function: "WOL" }]],
    }),
    timeoutMs: 8000,
  });
}

export const sonyModule: ProtocolModule = {
  brand: "sony",
  keymap: SONY_KEYMAP,
  features: ["apps", "text", "cast", "mediaControl", "wol", "pairingPin"],
  ports: [80],
  requiresCredentials: true,
  async probe(ip): Promise<DeviceIdentity | null> {
    try {
      const { json } = await httpJson<{ result?: [{ productName?: string; modelName?: string; productCategory?: string }] }>(`http://${ip}/sony/system`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ method: "getInterfaceInformation", id: 33, params: [], version: "1.0" }),
        timeoutMs: 1500,
      });
      const r = json?.result?.[0];
      if (!r?.modelName) return null;
      return { brand: "sony", name: `Sony ${r.modelName}`, model: r.modelName, port: 80 };
    } catch {
      return null;
    }
  },
  async beginPairing(ctx): Promise<PairingResult> {
    const cid = clientId(ctx);
    const r = await register(ctx.ip, cid, ctx.clientName);
    if (r.status === 200) {
      const cookie = String(r.headers["set-cookie"]?.[0] ?? "").split(";")[0];
      return { status: "paired", credentials: cookie ? { cookie } : null, identity: {} };
    }
    if (r.status === 401) {
      return {
        status: "pin",
        state: { cid },
        message: "Digite o PIN exibido na TV — ou, se usa Pre-Shared Key, digite psk:SUA_CHAVE.",
      };
    }
    throw new TvError(`Sony: registro falhou (${r.status})`);
  },
  async finishPairing(state, pin, ctx): Promise<PairingResult> {
    const { cid } = state as { cid: string };
    const value = pin.trim();
    if (value.toLowerCase().startsWith("psk:")) {
      const psk = value.slice(4);
      await rpc(ctx.ip, "system", "getPowerStatus", [], { psk });
      return { status: "paired", credentials: { psk }, identity: {} };
    }
    const basic = "Basic " + Buffer.from(`:${value}`).toString("base64");
    const r = await register(ctx.ip, cid, ctx.clientName, { Authorization: basic });
    if (r.status === 401 || r.status === 403) throw new TvError("PIN incorreto", "auth");
    if (r.status !== 200) throw new TvError(`Sony: registro falhou (${r.status})`);
    const cookie = String(r.headers["set-cookie"]?.[0] ?? "").split(";")[0];
    if (!cookie) throw new TvError("Sony: a TV não devolveu o cookie de autorização", "auth");
    let mac: string | null = null;
    try {
      const info = await rpc<[{ macAddr?: string; model?: string }]>(ctx.ip, "system", "getSystemInformation", [], { cookie });
      mac = normalizeMac(info[0]?.macAddr);
    } catch { /* optional */ }
    return { status: "paired", credentials: { cookie }, identity: { mac } };
  },
  createDriver: (ctx) => new SonyDriver(ctx),
};
