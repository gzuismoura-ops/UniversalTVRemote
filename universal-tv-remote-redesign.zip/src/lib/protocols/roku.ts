import type { AppDTO, Command } from "../commands";
import { DlnaRenderer, type MediaItem } from "../dlna";
import { httpRequest, normalizeMac, TvError, xmlText } from "../net";
import type { DeviceIdentity, DriverContext, ProtocolModule, TvDriver } from "./types";

/** Roku External Control Protocol (ECP) — HTTP :8060, no authentication. */
export const ROKU_KEYMAP: Partial<Record<Command, string>> = {
  power: "Power",
  up: "Up",
  down: "Down",
  left: "Left",
  right: "Right",
  ok: "Select",
  back: "Back",
  home: "Home",
  menu: "Info", // Roku's "*" options key
  source: "InputTuner",
  volUp: "VolumeUp",
  volDown: "VolumeDown",
  mute: "VolumeMute",
  chUp: "ChannelUp",
  chDown: "ChannelDown",
  info: "Info",
  play: "Play",
  pause: "Play", // Roku uses one Play/Pause toggle key
  rewind: "Rev",
  forward: "Fwd",
  prev: "InstantReplay",
};

const base = (ip: string) => `http://${ip}:8060`;

class RokuDriver implements TvDriver {
  private alive = false;
  constructor(private ctx: DriverContext) {}

  async connect() {
    await this.ping();
    this.alive = true;
  }
  disconnect() {
    this.alive = false;
  }
  isAlive() {
    return this.alive;
  }
  async ping() {
    const r = await httpRequest(`${base(this.ctx.ip)}/query/device-info`, { timeoutMs: 2500 });
    if (r.status !== 200) throw new TvError(`Roku respondeu ${r.status}`);
  }
  private async post(path: string) {
    const r = await httpRequest(`${base(this.ctx.ip)}${path}`, { method: "POST", body: "", timeoutMs: 4000 });
    if (r.status >= 400) throw new TvError(`Roku recusou o comando (${r.status})`);
  }
  async send(cmd: Command) {
    const key = ROKU_KEYMAP[cmd];
    if (!key) throw new TvError("Comando não suportado nesta TV", "unsupported");
    if (key === "Power") {
      // ECP exposes PowerOff/PowerOn on TVs; players only support PowerOff.
      await this.post("/keypress/Power");
      return;
    }
    await this.post(`/keypress/${key}`);
  }
  async listApps(): Promise<AppDTO[]> {
    const r = await httpRequest(`${base(this.ctx.ip)}/query/apps`);
    const apps: AppDTO[] = [];
    const re = /<app\s+id="(\d+)"[^>]*>([^<]*)<\/app>/g;
    let m: RegExpExecArray | null;
    while ((m = re.exec(r.body))) {
      apps.push({ id: m[1], name: decodeXml(m[2]), icon: `${base(this.ctx.ip)}/query/icon/${m[1]}` });
    }
    return apps;
  }
  async launchApp(id: string) {
    if (!/^[\w.-]+$/.test(id)) throw new TvError("ID de app inválido");
    await this.post(`/launch/${id}`);
  }
  async sendText(text: string) {
    for (const ch of text) {
      await this.post(`/keypress/Lit_${encodeURIComponent(ch)}`);
    }
  }
  async cast(item: MediaItem) {
    // Prefer DLNA when the Roku exposes it; otherwise use the Roku Media Player channel.
    const loc = this.ctx.meta.dlnaLocation as string | undefined;
    if (loc) {
      try {
        await new DlnaRenderer(loc).cast(item);
        return;
      } catch {
        /* fall through to Roku Media Player */
      }
    }
    const t = item.kind === "image" ? "p" : item.kind === "audio" ? "a" : "v";
    const q = new URLSearchParams({ t, u: item.url, k: "(null)", videoName: item.title });
    await this.post(`/input/15985?${q.toString()}`);
  }
}

export const rokuModule: ProtocolModule = {
  brand: "roku",
  keymap: ROKU_KEYMAP,
  features: ["apps", "text", "cast"],
  ports: [8060],
  requiresCredentials: false,
  async probe(ip): Promise<DeviceIdentity | null> {
    try {
      const r = await httpRequest(`${base(ip)}/query/device-info`, { timeoutMs: 1500 });
      if (r.status !== 200 || !r.body.includes("<device-info>")) return null;
      return {
        brand: "roku",
        name: xmlText(r.body, "user-device-name") ?? xmlText(r.body, "friendly-device-name") ?? "Roku",
        model: xmlText(r.body, "model-name"),
        mac: normalizeMac(xmlText(r.body, "wifi-mac") ?? xmlText(r.body, "ethernet-mac")),
        uniqueId: xmlText(r.body, "serial-number"),
        port: 8060,
      };
    } catch {
      return null;
    }
  },
  async beginPairing(ctx) {
    // ECP has no pairing; the TV only needs to be reachable.
    return { status: "paired", credentials: null, identity: ctx.identity };
  },
  createDriver: (ctx) => new RokuDriver(ctx),
};

function decodeXml(s: string) {
  return s.replace(/&amp;/g, "&").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&quot;/g, '"').replace(/&apos;/g, "'");
}
