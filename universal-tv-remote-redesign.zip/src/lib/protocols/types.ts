import type { AppDTO, Brand, Command, Feature } from "../commands";
import type { MediaItem } from "../dlna";

export interface DeviceIdentity {
  brand: Brand;
  name: string;
  model?: string | null;
  mac?: string | null;
  uniqueId?: string | null;
  port?: number | null;
  meta?: Record<string, unknown>;
}

export type Credentials = Record<string, unknown>;

export interface DriverContext {
  ip: string;
  port: number | null;
  clientName: string;
  credentials: Credentials | null;
  meta: Record<string, unknown>;
  /** Persist rotated/updated credentials (encrypted by the caller). */
  saveCredentials(c: Credentials): Promise<void>;
}

export type MediaAction = "play" | "pause" | "stop" | "seek" | "volume" | "mute" | "status";

export interface TvDriver {
  connect(): Promise<void>;
  disconnect(): void;
  /** Cheap local check: is the transport believed to be open? */
  isAlive(): boolean;
  /** Round-trip health check; throws TvError. */
  ping(): Promise<void>;
  send(cmd: Command): Promise<void>;
  listApps?(): Promise<AppDTO[]>;
  launchApp?(id: string): Promise<void>;
  sendText?(text: string): Promise<void>;
  cast?(item: MediaItem): Promise<void>;
  media?(action: MediaAction, value?: number): Promise<Record<string, unknown> | void>;
}

export type PairingResult =
  | { status: "paired"; credentials: Credentials | null; identity: Partial<DeviceIdentity> }
  | { status: "pin"; state: unknown; message: string };

export interface PairingContext {
  ip: string;
  clientName: string;
  identity: DeviceIdentity;
  /** For long-running pairing flows: called when the TV is now showing a prompt. */
  onPrompt?: () => void;
}

export interface ProtocolModule {
  brand: Brand;
  /** Native key mapping; the UI only enables commands present here. */
  keymap: Partial<Record<Command, string>>;
  features: Feature[];
  /** Ports used for diagnostics. */
  ports: number[];
  /** Does this protocol need a stored credential to operate? */
  requiresCredentials: boolean;
  probe(ip: string): Promise<DeviceIdentity | null>;
  beginPairing(ctx: PairingContext): Promise<PairingResult>;
  finishPairing?(state: unknown, pin: string, ctx: PairingContext): Promise<PairingResult>;
  createDriver(ctx: DriverContext): TvDriver;
}
