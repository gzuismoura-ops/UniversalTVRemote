import { AndroidRemote, RemoteDirection, RemoteKeyCode } from "androidtv-remote";
import type { AppDTO, Command } from "../commands";
import { DlnaRenderer, type MediaItem } from "../dlna";
import { TvError, tcpProbe } from "../net";
import { dlnaMedia } from "./lg";
import type { DeviceIdentity, DriverContext, MediaAction, PairingContext, PairingResult, ProtocolModule, TvDriver } from "./types";

/**
 * Android TV / Google TV — "Remote v2" protocol (TLS, :6467 pairing, :6466 remote).
 * Pairing: the TV shows a 6-char code; the user types it. The client certificate
 * that the TV has accepted IS the credential. It is persisted (encrypted) and
 * presented on every later TLS connection, so no new code is requested.
 */
export const ANDROIDTV_KEYMAP: Partial<Record<Command, string>> = {
  power: "KEYCODE_POWER",
  up: "KEYCODE_DPAD_UP",
  down: "KEYCODE_DPAD_DOWN",
  left: "KEYCODE_DPAD_LEFT",
  right: "KEYCODE_DPAD_RIGHT",
  ok: "KEYCODE_DPAD_CENTER",
  back: "KEYCODE_BACK",
  home: "KEYCODE_HOME",
  menu: "KEYCODE_MENU",
  settings: "KEYCODE_SETTINGS",
  source: "KEYCODE_TV_INPUT",
  volUp: "KEYCODE_VOLUME_UP",
  volDown: "KEYCODE_VOLUME_DOWN",
  mute: "KEYCODE_VOLUME_MUTE",
  chUp: "KEYCODE_CHANNEL_UP",
  chDown: "KEYCODE_CHANNEL_DOWN",
  num0: "KEYCODE_0",
  num1: "KEYCODE_1",
  num2: "KEYCODE_2",
  num3: "KEYCODE_3",
  num4: "KEYCODE_4",
  num5: "KEYCODE_5",
  num6: "KEYCODE_6",
  num7: "KEYCODE_7",
  num8: "KEYCODE_8",
  num9: "KEYCODE_9",
  guide: "KEYCODE_GUIDE",
  info: "KEYCODE_INFO",
  play: "KEYCODE_MEDIA_PLAY",
  pause: "KEYCODE_MEDIA_PAUSE",
  stop: "KEYCODE_MEDIA_STOP",
  rewind: "KEYCODE_MEDIA_REWIND",
  forward: "KEYCODE_MEDIA_FAST_FORWARD",
  next: "KEYCODE_MEDIA_NEXT",
  prev: "KEYCODE_MEDIA_PREVIOUS",
  red: "KEYCODE_PROG_RED",
  green: "KEYCODE_PROG_GREEN",
  yellow: "KEYCODE_PROG_YELLOW",
  blue: "KEYCODE_PROG_BLUE",
};

// The protocol cannot list installed apps; these are deep-link shortcuts (catalog), not discovered apps.
const CATALOG: AppDTO[] = [
  { id: "https://www.youtube.com", name: "YouTube", icon: null, catalog: true },
  { id: "https://www.netflix.com/browse", name: "Netflix", icon: null, catalog: true },
  { id: "https://app.primevideo.com", name: "Prime Video", icon: null, catalog: true },
  { id: "https://www.disneyplus.com", name: "Disney+", icon: null, catalog: true },
  { id: "spotify://", name: "Spotify", icon: null, catalog: true },
  { id: "market://launch?id=com.android.vending", name: "Google Play", icon: null, catalog: true },
];

function waitFor(r: AndroidRemote, event: string, ms: number): Promise<void> {
  return new Promise((resolve, reject) => {
    const t = setTimeout(() => reject(new TvError("Android TV: sem resposta", "timeout")), ms);
    r.once(event, () => {
      clearTimeout(t);
      resolve();
    });
  });
}

interface Cert { key: string; cert: string }

class AndroidTvDriver implements TvDriver {
  private remote: AndroidRemote | null = null;
  private ready = false;
  constructor(private ctx: DriverContext) {}

  async connect() {
    this.disconnect();
    const cert = this.ctx.credentials as Cert | null;
    if (!cert?.key || !cert?.cert) throw new TvError("Android TV: sem certificado salvo", "auth");
    const r = new AndroidRemote(this.ctx.ip, { cert, service_name: this.ctx.clientName });
    this.remote = r;
    r.on("unpaired", () => {
      this.ready = false;
      this.lastAuthError = true;
    });
    r.on("error", () => undefined);
    const ready = waitFor(r, "ready", 12_000);
    ready.catch(() => undefined);
    const started = await r.start().catch(() => false);
    if (!started) throw new TvError("Android TV: não foi possível abrir a conexão", "network");
    try {
      await ready;
    } catch (e) {
      this.disconnect();
      throw this.lastAuthError ? new TvError("Android TV: a TV revogou o pareamento", "auth") : (e as Error);
    }
    this.ready = true;
  }
  private lastAuthError = false;
  disconnect() {
    try {
      this.remote?.stop();
    } catch {
      /* already closed */
    }
    this.remote = null;
    this.ready = false;
  }
  isAlive() {
    return this.ready && !!this.remote;
  }
  async ping() {
    if (!this.isAlive()) throw new TvError("Android TV desconectada");
    const alive = await tcpProbe(this.ctx.ip, 6466, 1500);
    if (alive === null) throw new TvError("Android TV inacessível");
  }
  async send(cmd: Command) {
    const name = ANDROIDTV_KEYMAP[cmd];
    if (!name) throw new TvError("Comando não suportado nesta TV", "unsupported");
    if (!this.isAlive()) throw new TvError("Android TV desconectada");
    const code = (RemoteKeyCode as Record<string, number>)[name];
    if (code === undefined) throw new TvError("Tecla indisponível na biblioteca", "unsupported");
    this.remote!.sendKey(code, RemoteDirection.SHORT);
  }
  async listApps() {
    return CATALOG;
  }
  async launchApp(id: string) {
    if (!this.isAlive()) throw new TvError("Android TV desconectada");
    this.remote!.sendAppLink(id);
  }
  private dlna() {
    const loc = this.ctx.meta.dlnaLocation as string | undefined;
    if (!loc) throw new TvError("Esta TV não expõe DLNA", "unsupported");
    return new DlnaRenderer(loc);
  }
  async cast(item: MediaItem) {
    await this.dlna().cast(item);
  }
  async media(action: MediaAction, value?: number) {
    return dlnaMedia(this.dlna(), action, value);
  }
}

interface PairState { remote: AndroidRemote }

export const androidTvModule: ProtocolModule = {
  brand: "androidtv",
  keymap: ANDROIDTV_KEYMAP,
  features: ["apps", "wol", "pairingPin"],
  ports: [6466, 6467],
  requiresCredentials: true,
  async probe(ip): Promise<DeviceIdentity | null> {
    const [a, b] = await Promise.all([tcpProbe(ip, 6466, 1000), tcpProbe(ip, 6467, 1000)]);
    if (a === null || b === null) return null;
    return { brand: "androidtv", name: "Android TV", model: null, port: 6466 };
  },
  async beginPairing(ctx: PairingContext): Promise<PairingResult> {
    const remote = new AndroidRemote(ctx.ip, { service_name: ctx.clientName });
    remote.on("error", () => undefined);
    const secret = waitFor(remote, "secret", 15_000);
    secret.catch(() => undefined);
    // start() blocks until the code is accepted, so it must not be awaited here.
    void remote.start().catch(() => undefined);
    try {
      await secret;
    } catch {
      try { remote.stop(); } catch { /* not started */ }
      throw new TvError("Android TV: a TV não iniciou o pareamento", "timeout");
    }
    return { status: "pin", state: { remote } satisfies PairState, message: "Digite o código de 6 caracteres exibido na TV." };
  },
  async finishPairing(state, pin): Promise<PairingResult> {
    const { remote } = state as PairState;
    const ready = waitFor(remote, "ready", 15_000);
    ready.catch(() => undefined);
    const ok = await remote.sendCode(pin.trim().toUpperCase());
    if (!ok) {
      try { remote.stop(); } catch { /* ignore */ }
      throw new TvError("Código incorreto", "auth");
    }
    await ready;
    const cert = remote.getCertificate();
    try { remote.stop(); } catch { /* ignore */ }
    return { status: "paired", credentials: cert, identity: {} };
  },
  createDriver: (ctx) => new AndroidTvDriver(ctx),
};
