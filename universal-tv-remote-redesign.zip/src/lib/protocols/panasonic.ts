import type { Command } from "../commands";
import { httpRequest, TvError, tcpProbe, xmlText } from "../net";
import type { DeviceIdentity, DriverContext, ProtocolModule, TvDriver } from "./types";

/**
 * Panasonic Viera — UPnP/SOAP NRC (:55000), unencrypted variant.
 * LIMITATION: 2018+ models require an encrypted session (PIN + AES). That
 * variant is NOT implemented here; those TVs will answer with errors.
 */
export const PANASONIC_KEYMAP: Partial<Record<Command, string>> = {
  power: "NRC_POWER-ONOFF",
  up: "NRC_UP-ONOFF",
  down: "NRC_DOWN-ONOFF",
  left: "NRC_LEFT-ONOFF",
  right: "NRC_RIGHT-ONOFF",
  ok: "NRC_ENTER-ONOFF",
  back: "NRC_RETURN-ONOFF",
  home: "NRC_HOME-ONOFF",
  menu: "NRC_MENU-ONOFF",
  source: "NRC_CHG_INPUT-ONOFF",
  volUp: "NRC_VOLUP-ONOFF",
  volDown: "NRC_VOLDOWN-ONOFF",
  mute: "NRC_MUTE-ONOFF",
  chUp: "NRC_CH_UP-ONOFF",
  chDown: "NRC_CH_DOWN-ONOFF",
  num0: "NRC_D0-ONOFF",
  num1: "NRC_D1-ONOFF",
  num2: "NRC_D2-ONOFF",
  num3: "NRC_D3-ONOFF",
  num4: "NRC_D4-ONOFF",
  num5: "NRC_D5-ONOFF",
  num6: "NRC_D6-ONOFF",
  num7: "NRC_D7-ONOFF",
  num8: "NRC_D8-ONOFF",
  num9: "NRC_D9-ONOFF",
  guide: "NRC_EPG-ONOFF",
  info: "NRC_INFO-ONOFF",
  play: "NRC_PLAY-ONOFF",
  pause: "NRC_PAUSE-ONOFF",
  stop: "NRC_STOP-ONOFF",
  rewind: "NRC_REW-ONOFF",
  forward: "NRC_FF-ONOFF",
  next: "NRC_SKIP_NEXT-ONOFF",
  prev: "NRC_SKIP_PREV-ONOFF",
  red: "NRC_RED-ONOFF",
  green: "NRC_GREEN-ONOFF",
  yellow: "NRC_YELLOW-ONOFF",
  blue: "NRC_BLUE-ONOFF",
};

async function sendKey(ip: string, key: string) {
  const body = `<?xml version="1.0" encoding="utf-8"?><s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/" s:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/"><s:Body><u:X_SendKey xmlns:u="urn:panasonic-com:service:p00NetworkControl:1"><X_KeyEvent>${key}</X_KeyEvent></u:X_SendKey></s:Body></s:Envelope>`;
  const r = await httpRequest(`http://${ip}:55000/nrc/control_0`, {
    method: "POST",
    headers: { "Content-Type": 'text/xml; charset="utf-8"', SOAPACTION: '"urn:panasonic-com:service:p00NetworkControl:1#X_SendKey"' },
    body,
    timeoutMs: 4000,
  });
  if (r.status >= 400) throw new TvError(`Panasonic recusou o comando (${r.status}) — modelos 2018+ exigem sessão criptografada, ainda não suportada.`);
}

class PanasonicDriver implements TvDriver {
  private alive = false;
  constructor(private ctx: DriverContext) {}
  async connect() {
    await this.ping();
    this.alive = true;
  }
  disconnect() {
    this.alive = false;
  }
  isAlive() {
    return this.alive;
  }
  async ping() {
    const r = await httpRequest(`http://${this.ctx.ip}:55000/nrc/ddd.xml`, { timeoutMs: 2500 });
    if (r.status !== 200) throw new TvError(`Panasonic respondeu ${r.status}`);
  }
  async send(cmd: Command) {
    const k = PANASONIC_KEYMAP[cmd];
    if (!k) throw new TvError("Comando não suportado nesta TV", "unsupported");
    await sendKey(this.ctx.ip, k);
  }
}

export const panasonicModule: ProtocolModule = {
  brand: "panasonic",
  keymap: PANASONIC_KEYMAP,
  features: ["wol"],
  ports: [55000],
  requiresCredentials: false,
  async probe(ip): Promise<DeviceIdentity | null> {
    if ((await tcpProbe(ip, 55000, 900)) === null) return null;
    try {
      const r = await httpRequest(`http://${ip}:55000/nrc/ddd.xml`, { timeoutMs: 1500 });
      if (r.status !== 200 || !/panasonic/i.test(r.body)) return null;
      return { brand: "panasonic", name: xmlText(r.body, "friendlyName") ?? "Panasonic Viera", model: xmlText(r.body, "modelName"), port: 55000 };
    } catch {
      return null;
    }
  },
  async beginPairing(ctx) {
    return { status: "paired", credentials: null, identity: ctx.identity };
  },
  createDriver: (ctx) => new PanasonicDriver(ctx),
};
