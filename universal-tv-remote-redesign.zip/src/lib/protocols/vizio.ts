import crypto from "node:crypto";
import type { Command } from "../commands";
import { httpJson, TvError } from "../net";
import type { DeviceIdentity, DriverContext, PairingContext, PairingResult, ProtocolModule, TvDriver } from "./types";

/**
 * Vizio SmartCast (HTTPS :7345 or :9000, self-signed).
 * Pairing: PIN shown on the TV → AUTH_TOKEN (persisted encrypted, sent as `AUTH` header).
 * keymap value = "codeset,code".
 */
export const VIZIO_KEYMAP: Partial<Record<Command, string>> = {
  power: "11,2",
  up: "3,8",
  down: "3,0",
  left: "3,1",
  right: "3,7",
  ok: "3,2",
  back: "4,0",
  home: "4,15",
  menu: "4,8",
  source: "7,1",
  volUp: "5,1",
  volDown: "5,0",
  mute: "5,4",
  chUp: "8,1",
  chDown: "8,0",
  info: "4,6",
  play: "2,3",
  pause: "2,2",
  rewind: "2,1",
  forward: "2,0",
};

const PORTS = [7345, 9000];

async function vizio<T>(ip: string, port: number, method: string, path: string, body?: unknown, token?: string) {
  const headers: Record<string, string> = { "Content-Type": "application/json" };
  if (token) headers.AUTH = token;
  return httpJson<T>(`https://${ip}:${port}${path}`, { method, headers, body: body === undefined ? undefined : JSON.stringify(body), insecureTls: true, timeoutMs: 5000 });
}

async function findPort(ip: string): Promise<number | null> {
  for (const p of PORTS) {
    try {
      const r = await vizio<unknown>(ip, p, "GET", "/state/device/deviceinfo");
      if (r.status > 0 && r.json) return p;
    } catch { /* next */ }
  }
  return null;
}

class VizioDriver implements TvDriver {
  private alive = false;
  private port = 7345;
  constructor(private ctx: DriverContext) {}
  private get token() {
    return (this.ctx.credentials?.token as string | undefined) ?? "";
  }
  async connect() {
    this.port = (await findPort(this.ctx.ip)) ?? this.port;
    await this.ping();
    this.alive = true;
  }
  disconnect() {
    this.alive = false;
  }
  isAlive() {
    return this.alive;
  }
  async ping() {
    const r = await vizio<{ STATUS?: { RESULT?: string } }>(this.ctx.ip, this.port, "GET", "/state/device/power_mode", undefined, this.token);
    if (r.status === 401 || r.json?.STATUS?.RESULT === "BLOCKED") throw new TvError("Vizio: credencial recusada", "auth");
    if (r.status >= 400) throw new TvError(`Vizio respondeu ${r.status}`);
  }
  async send(cmd: Command) {
    const spec = VIZIO_KEYMAP[cmd];
    if (!spec) throw new TvError("Comando não suportado nesta TV", "unsupported");
    const [codeset, code] = spec.split(",").map(Number);
    const r = await vizio<{ STATUS?: { RESULT?: string } }>(
      this.ctx.ip, this.port, "PUT", "/key_command/",
      { KEYLIST: [{ CODESET: codeset, CODE: code, ACTION: "KEYPRESS" }] },
      this.token,
    );
    if (r.status === 401) throw new TvError("Vizio: credencial recusada", "auth");
    if (r.json?.STATUS?.RESULT && r.json.STATUS.RESULT !== "SUCCESS") throw new TvError(`Vizio: ${r.json.STATUS.RESULT}`);
  }
}

export const vizioModule: ProtocolModule = {
  brand: "vizio",
  keymap: VIZIO_KEYMAP,
  features: ["pairingPin"],
  ports: PORTS,
  requiresCredentials: true,
  async probe(ip): Promise<DeviceIdentity | null> {
    const port = await findPort(ip);
    if (!port) return null;
    try {
      const r = await vizio<{ ITEMS?: { VALUE?: { MODEL_NAME?: string; NAME?: string } }[] }>(ip, port, "GET", "/state/device/deviceinfo");
      const v = r.json?.ITEMS?.[0]?.VALUE;
      return { brand: "vizio", name: v?.NAME ?? "Vizio SmartCast", model: v?.MODEL_NAME ?? null, port };
    } catch {
      return { brand: "vizio", name: "Vizio SmartCast", port };
    }
  },
  async beginPairing(ctx: PairingContext): Promise<PairingResult> {
    const port = (await findPort(ctx.ip)) ?? 7345;
    const deviceId = `utv-${crypto.randomBytes(6).toString("hex")}`;
    const r = await vizio<{ ITEM?: { PAIRING_REQ_TOKEN?: number }; STATUS?: { RESULT?: string } }>(ctx.ip, port, "PUT", "/pairing/start", { DEVICE_NAME: ctx.clientName, DEVICE_ID: deviceId });
    const tok = r.json?.ITEM?.PAIRING_REQ_TOKEN;
    if (tok === undefined) throw new TvError("Vizio: a TV não iniciou o pareamento");
    return { status: "pin", state: { port, deviceId, tok }, message: "Digite o PIN exibido na TV." };
  },
  async finishPairing(state, pin, ctx): Promise<PairingResult> {
    const s = state as { port: number; deviceId: string; tok: number };
    const r = await vizio<{ ITEM?: { AUTH_TOKEN?: string }; STATUS?: { RESULT?: string } }>(ctx.ip, s.port, "PUT", "/pairing/pair", {
      DEVICE_ID: s.deviceId, CHALLENGE_TYPE: 1, RESPONSE_VALUE: pin.trim(), PAIRING_REQ_TOKEN: s.tok,
    });
    const token = r.json?.ITEM?.AUTH_TOKEN;
    if (!token) throw new TvError("PIN incorreto", "auth");
    return { status: "paired", credentials: { token }, identity: { port: s.port } };
  },
  createDriver: (ctx) => new VizioDriver(ctx),
};
