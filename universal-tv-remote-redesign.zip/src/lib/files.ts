import fs from "node:fs";
import path from "node:path";
import type { transfers } from "@/db/schema";
import type { TransferDTO, TransferStatus } from "./commands";
import { dataDir } from "./crypto";

export function uploadsDir(): string {
  const d = path.join(dataDir(), "uploads");
  fs.mkdirSync(d, { recursive: true });
  return d;
}

export function filePathFor(id: string): string {
  if (!/^[0-9a-f-]{36}$/i.test(id)) throw new Error("id inválido");
  return path.join(uploadsDir(), id);
}

export function safeName(name: string): string {
  const base = name.replace(/[\\/\0]/g, "_").replace(/[^\p{L}\p{N}._ -]/gu, "_").trim().slice(0, 120);
  return base || "arquivo";
}

export function toTransferDTO(t: typeof transfers.$inferSelect): TransferDTO {
  return {
    id: t.id,
    name: t.name,
    mime: t.mime,
    kind: t.kind as TransferDTO["kind"],
    size: t.size,
    received: t.received,
    status: t.status as TransferStatus,
    error: t.error,
    deviceId: t.deviceId,
    method: t.method,
    createdAt: t.createdAt.toISOString(),
    updatedAt: t.updatedAt.toISOString(),
  };
}

export const MAX_UPLOAD_BYTES = (Number(process.env.MAX_UPLOAD_MB) || 4096) * 1024 * 1024;
