// Shared (client + server) definition of the universal command vocabulary.
// Each protocol adapter maps this vocabulary to its own native key codes.

export const COMMANDS = [
  "power",
  "up",
  "down",
  "left",
  "right",
  "ok",
  "back",
  "home",
  "menu",
  "settings",
  "source",
  "volUp",
  "volDown",
  "mute",
  "chUp",
  "chDown",
  "num0",
  "num1",
  "num2",
  "num3",
  "num4",
  "num5",
  "num6",
  "num7",
  "num8",
  "num9",
  "guide",
  "info",
  "play",
  "pause",
  "stop",
  "rewind",
  "forward",
  "next",
  "prev",
  "red",
  "green",
  "yellow",
  "blue",
] as const;

export type Command = (typeof COMMANDS)[number];

export const FEATURES = [
  "apps", // list + launch apps
  "text", // text input to the TV
  "cast", // play a media URL on the TV
  "mediaControl", // play/pause/seek on cast session
  "volumeSlider",
  "wol", // wake-on-lan (needs MAC)
  "pairingPin", // pairing needs PIN typed by the user
] as const;
export type Feature = (typeof FEATURES)[number];

export const BRANDS = [
  "lg",
  "samsung",
  "sony",
  "androidtv",
  "roku",
  "philips",
  "panasonic",
  "vizio",
  "chromecast",
  "dlna",
] as const;
export type Brand = (typeof BRANDS)[number];

export const BRAND_LABEL: Record<Brand, string> = {
  lg: "LG webOS",
  samsung: "Samsung Tizen",
  sony: "Sony Bravia",
  androidtv: "Android TV / Google TV",
  roku: "Roku",
  philips: "Philips JointSPACE",
  panasonic: "Panasonic Viera",
  vizio: "Vizio SmartCast",
  chromecast: "Chromecast",
  dlna: "DLNA / UPnP",
};

export interface Capabilities {
  commands: Command[];
  features: Feature[];
}

export interface DeviceDTO {
  id: string;
  name: string;
  brand: Brand;
  model: string | null;
  ip: string;
  port: number | null;
  mac: string | null;
  favorite: boolean;
  authState: "none" | "paired" | "revoked";
  lastConnectedAt: string | null;
  lastError: string | null;
  createdAt: string;
  capabilities: Capabilities;
  hasMedia: boolean;
}

export type LinkState =
  | "disconnected"
  | "connecting"
  | "connected"
  | "reconnecting"
  | "needs-pairing"
  | "error";

export interface StatusDTO {
  state: LinkState;
  error: string | null;
  latencyMs: number | null;
  attempts: number;
  nextRetryInMs: number | null;
}

export interface AppDTO {
  id: string;
  name: string;
  icon: string | null;
  /** true = well-known shortcut, not read from the TV's installed list */
  catalog?: boolean;
}

export interface TransferDTO {
  id: string;
  name: string;
  mime: string;
  kind: "image" | "video" | "audio" | "document" | "other";
  size: number;
  received: number;
  status: TransferStatus;
  error: string | null;
  deviceId: string | null;
  method: string | null;
  createdAt: string;
  updatedAt: string;
}

export type TransferStatus =
  | "uploading"
  | "ready"
  | "sending"
  | "sent"
  | "failed"
  | "cancelled";

export interface ActivityDTO {
  id: number;
  deviceId: string | null;
  type: string;
  label: string;
  refId: string | null;
  icon: string | null;
  createdAt: string;
}

export const COMMAND_LABEL: Record<Command, string> = {
  power: "Energia",
  up: "Cima",
  down: "Baixo",
  left: "Esquerda",
  right: "Direita",
  ok: "OK",
  back: "Voltar",
  home: "Início",
  menu: "Menu",
  settings: "Configurações",
  source: "Fonte",
  volUp: "Volume +",
  volDown: "Volume −",
  mute: "Mudo",
  chUp: "Canal +",
  chDown: "Canal −",
  num0: "0",
  num1: "1",
  num2: "2",
  num3: "3",
  num4: "4",
  num5: "5",
  num6: "6",
  num7: "7",
  num8: "8",
  num9: "9",
  guide: "Guia",
  info: "Info",
  play: "Reproduzir",
  pause: "Pausar",
  stop: "Parar",
  rewind: "Retroceder",
  forward: "Avançar",
  next: "Próximo",
  prev: "Anterior",
  red: "Vermelho",
  green: "Verde",
  yellow: "Amarelo",
  blue: "Azul",
};
