import { httpRequest, TvError, xmlEscape, xmlText } from "./net";
import { ssdpSearch } from "./ssdp";

/** UPnP AV (DLNA) control point: used for casting media and for DLNA-only devices. */

export interface DlnaEndpoints {
  avTransport: string | null;
  renderingControl: string | null;
  friendlyName: string | null;
  manufacturer: string | null;
  modelName: string | null;
  udn: string | null;
}

export async function fetchDlnaDescription(location: string): Promise<DlnaEndpoints> {
  const res = await httpRequest(location, { timeoutMs: 3000 });
  if (res.status !== 200) throw new TvError(`Descrição UPnP indisponível (${res.status})`);
  const base = new URL(location);
  const abs = (p: string | null) => {
    if (!p) return null;
    try {
      return new URL(p, base.origin + "/").toString();
    } catch {
      return null;
    }
  };
  const services = res.body.match(/<service>[\s\S]*?<\/service>/gi) ?? [];
  const control = (type: string) => {
    const s = services.find((x) => new RegExp(`service:${type}:`, "i").test(x));
    return s ? abs(xmlText(s, "controlURL")) : null;
  };
  return {
    avTransport: control("AVTransport"),
    renderingControl: control("RenderingControl"),
    friendlyName: xmlText(res.body, "friendlyName"),
    manufacturer: xmlText(res.body, "manufacturer"),
    modelName: xmlText(res.body, "modelName"),
    udn: xmlText(res.body, "UDN"),
  };
}

/** Finds a MediaRenderer description URL for the given IP via SSDP. */
export async function findDlnaLocation(ip: string): Promise<string | null> {
  const found = await ssdpSearch(2200, [
    "urn:schemas-upnp-org:device:MediaRenderer:1",
    "urn:schemas-upnp-org:service:AVTransport:1",
  ]);
  return found.find((r) => r.ip === ip && r.location)?.location ?? null;
}

async function soap(controlUrl: string, service: "AVTransport" | "RenderingControl", action: string, args: Record<string, string | number>): Promise<string> {
  const urn = `urn:schemas-upnp-org:service:${service}:1`;
  const argXml = Object.entries(args)
    .map(([k, v]) => `<${k}>${typeof v === "string" ? xmlEscape(v) : v}</${k}>`)
    .join("");
  const body = `<?xml version="1.0" encoding="utf-8"?><s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/" s:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/"><s:Body><u:${action} xmlns:u="${urn}">${argXml}</u:${action}></s:Body></s:Envelope>`;
  const res = await httpRequest(controlUrl, {
    method: "POST",
    headers: {
      "Content-Type": 'text/xml; charset="utf-8"',
      SOAPACTION: `"${urn}#${action}"`,
    },
    body,
    timeoutMs: 6000,
  });
  if (res.status >= 400) {
    const code = xmlText(res.body, "errorDescription") ?? `HTTP ${res.status}`;
    throw new TvError(`DLNA ${action}: ${code}`);
  }
  return res.body;
}

export function didl(title: string, url: string, mime: string, kind: string): string {
  const cls =
    kind === "image" ? "object.item.imageItem.photo" : kind === "audio" ? "object.item.audioItem.musicTrack" : "object.item.videoItem";
  return (
    `<DIDL-Lite xmlns="urn:schemas-upnp-org:metadata-1-0/DIDL-Lite/" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:upnp="urn:schemas-upnp-org:metadata-1-0/upnp/">` +
    `<item id="0" parentID="-1" restricted="1"><dc:title>${xmlEscape(title)}</dc:title><upnp:class>${cls}</upnp:class>` +
    `<res protocolInfo="http-get:*:${mime}:*">${xmlEscape(url)}</res></item></DIDL-Lite>`
  );
}

export interface MediaItem {
  url: string;
  mime: string;
  title: string;
  kind: string;
}

export class DlnaRenderer {
  private eps: DlnaEndpoints | null = null;
  constructor(private location: string) {}

  private async ep(): Promise<DlnaEndpoints> {
    if (!this.eps) this.eps = await fetchDlnaDescription(this.location);
    return this.eps;
  }
  private async av(): Promise<string> {
    const e = await this.ep();
    if (!e.avTransport) throw new TvError("Este dispositivo não expõe AVTransport (DLNA)", "unsupported");
    return e.avTransport;
  }
  private async rc(): Promise<string> {
    const e = await this.ep();
    if (!e.renderingControl) throw new TvError("Este dispositivo não expõe RenderingControl (DLNA)", "unsupported");
    return e.renderingControl;
  }

  async ping(): Promise<void> {
    await this.ep();
  }

  async cast(item: MediaItem): Promise<void> {
    const av = await this.av();
    try {
      await soap(av, "AVTransport", "Stop", { InstanceID: 0 });
    } catch {
      /* nothing playing */
    }
    await soap(av, "AVTransport", "SetAVTransportURI", {
      InstanceID: 0,
      CurrentURI: item.url,
      CurrentURIMetaData: didl(item.title, item.url, item.mime, item.kind),
    });
    await soap(av, "AVTransport", "Play", { InstanceID: 0, Speed: "1" });
  }

  async play() {
    await soap(await this.av(), "AVTransport", "Play", { InstanceID: 0, Speed: "1" });
  }
  async pause() {
    await soap(await this.av(), "AVTransport", "Pause", { InstanceID: 0 });
  }
  async stop() {
    await soap(await this.av(), "AVTransport", "Stop", { InstanceID: 0 });
  }
  async seek(seconds: number) {
    const s = Math.max(0, Math.floor(seconds));
    const t = [Math.floor(s / 3600), Math.floor((s % 3600) / 60), s % 60].map((n) => String(n).padStart(2, "0")).join(":");
    await soap(await this.av(), "AVTransport", "Seek", { InstanceID: 0, Unit: "REL_TIME", Target: t });
  }
  async position(): Promise<{ position: number; duration: number; state: string }> {
    const av = await this.av();
    const pos = await soap(av, "AVTransport", "GetPositionInfo", { InstanceID: 0 });
    let state = "UNKNOWN";
    try {
      state = xmlText(await soap(av, "AVTransport", "GetTransportInfo", { InstanceID: 0 }), "CurrentTransportState") ?? "UNKNOWN";
    } catch {
      /* optional */
    }
    return { position: parseHms(xmlText(pos, "RelTime")), duration: parseHms(xmlText(pos, "TrackDuration")), state };
  }
  async setVolume(v: number) {
    await soap(await this.rc(), "RenderingControl", "SetVolume", { InstanceID: 0, Channel: "Master", DesiredVolume: Math.max(0, Math.min(100, Math.round(v))) });
  }
  async getVolume(): Promise<number> {
    const x = await soap(await this.rc(), "RenderingControl", "GetVolume", { InstanceID: 0, Channel: "Master" });
    return Number(xmlText(x, "CurrentVolume") ?? 0);
  }
  async setMute(m: boolean) {
    await soap(await this.rc(), "RenderingControl", "SetMute", { InstanceID: 0, Channel: "Master", DesiredMute: m ? 1 : 0 });
  }
}

function parseHms(s: string | null): number {
  if (!s || !/^\d+:\d+:\d+/.test(s)) return 0;
  const [h, m, sec] = s.split(":").map((x) => parseFloat(x));
  return h * 3600 + m * 60 + sec;
}
