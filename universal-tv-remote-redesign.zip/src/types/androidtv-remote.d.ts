declare module "androidtv-remote" {
  import { EventEmitter } from "node:events";

  export class AndroidRemote extends EventEmitter {
    constructor(
      host: string,
      options: {
        cert?: { key?: string; cert?: string };
        pairing_port?: number;
        remote_port?: number;
        service_name?: string;
      },
    );
    start(): Promise<boolean | undefined>;
    sendCode(code: string): Promise<boolean>;
    sendPower(): void;
    sendAppLink(link: string): void;
    sendKey(key: number, direction: number): void;
    getCertificate(): { key: string; cert: string };
    stop(): void;
  }
  export const RemoteKeyCode: Record<string, number>;
  export const RemoteDirection: { SHORT: number; START_LONG: number; END_LONG: number; [k: string]: number };
}
