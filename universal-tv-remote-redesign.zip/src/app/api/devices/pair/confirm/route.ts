import { body, fail, json } from "@/lib/api";
import { cancelPairing, confirmPairing } from "@/lib/device-service";

export const dynamic = "force-dynamic";
export const maxDuration = 60;

export async function POST(req: Request) {
  try {
    const b = await body<{ pairingId?: string; pin?: string; cancel?: boolean }>(req);
    if (!b.pairingId) return json({ error: "pairingId ausente" }, 400);
    if (b.cancel) {
      await cancelPairing(b.pairingId);
      return json({ ok: true });
    }
    if (!b.pin) return json({ error: "Informe o código exibido na TV" }, 400);
    return json(await confirmPairing(b.pairingId, b.pin));
  } catch (e) {
    return fail(e);
  }
}
