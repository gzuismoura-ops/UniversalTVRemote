import { status } from "@/lib/connection-manager";
import { listDevices, startPairing, toDTO } from "@/lib/device-service";
import { body, fail, json } from "@/lib/api";

export const dynamic = "force-dynamic";
export const maxDuration = 90;

export async function GET() {
  try {
    const rows = await listDevices();
    return json({ devices: rows.map((r) => ({ ...toDTO(r), status: status(r.id) })) });
  } catch (e) {
    return fail(e);
  }
}

/** Add / pair a TV by IP. May block until the user accepts on the TV (LG, Samsung). */
export async function POST(req: Request) {
  try {
    const b = await body<{ ip?: string; brand?: string; name?: string }>(req);
    if (!b.ip) return json({ error: "Informe o IP da TV" }, 400);
    return json(await startPairing({ ip: b.ip, brand: b.brand, name: b.name }));
  } catch (e) {
    return fail(e);
  }
}
