import { and, asc, eq } from "drizzle-orm";
import { db } from "@/db";
import { devices, favoriteApps } from "@/db/schema";
import { body, fail, json } from "@/lib/api";
import { connect, disconnect, run, sendCommand, status } from "@/lib/connection-manager";
import { COMMANDS, type Command } from "@/lib/commands";
import { getDevice, logActivity, readCredentials, resetCredentials, toDTO } from "@/lib/device-service";
import { httpBinary, lanIpFor, localIPv4s, lookupMac, sendWakeOnLan, tcpProbe, TvError } from "@/lib/net";
import { capabilitiesFor, getModule } from "@/lib/protocols";
import type { MediaAction } from "@/lib/protocols/types";

export const dynamic = "force-dynamic";
export const maxDuration = 60;
type Ctx = { params: Promise<{ id: string; action: string }> };

const MEDIA_ACTIONS: MediaAction[] = ["play", "pause", "stop", "seek", "volume", "mute", "status"];

export async function GET(req: Request, { params }: Ctx) {
  try {
    const { id, action } = await params;
    const row = await getDevice(id);
    if (!row) return json({ error: "Dispositivo não encontrado" }, 404);
    const caps = capabilitiesFor(row.brand, (row.meta ?? {}) as Record<string, unknown>);

    switch (action) {
      case "status":
        return json({ status: status(id) });

      case "apps": {
        if (!caps.features.includes("apps")) return json({ apps: [], supported: false });
        const apps = await run(id, (d) => (d.listApps ? d.listApps() : Promise.reject(new TvError("Sem suporte a apps", "unsupported"))));
        return json({ apps, supported: true });
      }

      case "favorites": {
        const rows = await db.select().from(favoriteApps).where(eq(favoriteApps.deviceId, id)).orderBy(asc(favoriteApps.position), asc(favoriteApps.id));
        return json({ favorites: rows.map((f) => ({ id: f.appId, name: f.name, icon: f.icon })) });
      }

      case "icon": {
        const u = new URL(req.url).searchParams.get("u") ?? "";
        let target: URL;
        try {
          target = new URL(u);
        } catch {
          return json({ error: "URL inválida" }, 400);
        }
        // SSRF guard: only fetch icons hosted by this TV.
        if (target.hostname !== row.ip) return json({ error: "Host não permitido" }, 403);
        const r = await httpBinary(target.toString());
        if (r.status !== 200 || !r.type.startsWith("image/")) return json({ error: "Ícone indisponível" }, 404);
        return new Response(new Uint8Array(r.data), { headers: { "Content-Type": r.type, "Cache-Control": "public, max-age=86400" } });
      }

      case "diagnostics": {
        const mod = getModule(row.brand)!;
        const checks: { label: string; ok: boolean; detail: string }[] = [];
        const servers = localIPv4s();
        checks.push({ label: "Servidor na rede local", ok: servers.length > 0, detail: servers.map((s) => s.address).join(", ") || "sem interface IPv4" });
        const sameNet = lanIpFor(row.ip);
        checks.push({ label: "Mesma sub-rede da TV", ok: !!sameNet && sameNet.split(".").slice(0, 3).join(".") === row.ip.split(".").slice(0, 3).join("."), detail: sameNet ?? "—" });
        for (const p of mod.ports) {
          const ms = await tcpProbe(row.ip, p, 1500);
          checks.push({ label: `Porta ${p}`, ok: ms !== null, detail: ms !== null ? `${ms} ms` : "fechada / inacessível" });
        }
        const creds = readCredentials(row);
        checks.push({
          label: "Credencial salva (criptografada)",
          ok: !mod.requiresCredentials || !!creds,
          detail: mod.requiresCredentials ? (creds ? "presente" : row.authState === "revoked" ? "revogada pela TV" : "ausente") : "este protocolo não usa credencial",
        });
        const st = status(id);
        checks.push({ label: "Estado da conexão", ok: st.state === "connected", detail: `${st.state}${st.error ? ` — ${st.error}` : ""}` });
        checks.push({ label: "Latência", ok: st.latencyMs !== null, detail: st.latencyMs !== null ? `${st.latencyMs} ms` : "—" });
        checks.push({ label: "Wake-on-LAN", ok: !!row.mac, detail: row.mac ?? "MAC desconhecido" });
        checks.push({ label: "DLNA (envio de mídia)", ok: caps.features.includes("cast"), detail: caps.features.includes("cast") ? "disponível" : "não detectado" });
        return json({ checks, status: st });
      }

      default:
        return json({ error: "Ação desconhecida" }, 404);
    }
  } catch (e) {
    return fail(e);
  }
}

export async function POST(req: Request, { params }: Ctx) {
  try {
    const { id, action } = await params;
    const row = await getDevice(id);
    if (!row) return json({ error: "Dispositivo não encontrado" }, 404);
    const caps = capabilitiesFor(row.brand, (row.meta ?? {}) as Record<string, unknown>);
    const b = await body<Record<string, unknown>>(req);

    switch (action) {
      case "connect":
        return json({ status: await connect(id, { force: b.force === true }), device: toDTO((await getDevice(id)) ?? row) });

      case "disconnect":
        disconnect(id);
        return json({ status: status(id) });

      case "repair": {
        // User explicitly chose to discard the stored credential and pair again.
        disconnect(id);
        await resetCredentials(id);
        return json({ ok: true });
      }

      case "command": {
        const cmd = b.command as Command;
        if (!COMMANDS.includes(cmd)) return json({ error: "Comando inválido" }, 400);
        if (!caps.commands.includes(cmd)) return json({ error: "Esta TV não suporta esse comando", kind: "unsupported" }, 422);
        await sendCommand(id, cmd);
        return json({ ok: true });
      }

      case "launch": {
        const appId = String(b.appId ?? "");
        if (!appId) return json({ error: "appId ausente" }, 400);
        await run(id, (d) => (d.launchApp ? d.launchApp(appId) : Promise.reject(new TvError("Sem suporte a apps", "unsupported"))));
        await logActivity({ deviceId: id, type: "app", label: String(b.name ?? appId).slice(0, 80), refId: appId, icon: typeof b.icon === "string" ? b.icon : null });
        return json({ ok: true });
      }

      case "text": {
        const text = String(b.text ?? "");
        if (!text) return json({ error: "Texto vazio" }, 400);
        if (!caps.features.includes("text")) return json({ error: "Esta TV não aceita texto remoto", kind: "unsupported" }, 422);
        await run(id, (d) => (d.sendText ? d.sendText(text) : Promise.reject(new TvError("Sem suporte a texto", "unsupported"))));
        if (b.enter === true) await sendCommand(id, "ok").catch(() => undefined);
        return json({ ok: true });
      }

      case "wake": {
        let mac = row.mac;
        if (!mac) {
          mac = await lookupMac(row.ip);
          if (mac) await db.update(devices).set({ mac }).where(eq(devices.id, id));
        }
        if (!mac) return json({ error: "MAC desconhecido. Informe o endereço MAC nos detalhes do dispositivo.", kind: "unsupported" }, 422);
        await sendWakeOnLan(mac, row.ip);
        await logActivity({ deviceId: id, type: "command", label: `Wake-on-LAN para ${row.name}` });
        // Give the TV a moment, then try to restore the session in the background.
        setTimeout(() => void connect(id).catch(() => undefined), 8000);
        return json({ ok: true, mac });
      }

      case "media": {
        const act = b.action as MediaAction;
        if (!MEDIA_ACTIONS.includes(act)) return json({ error: "Ação inválida" }, 400);
        const out = await run(id, (d) => (d.media ? d.media(act, typeof b.value === "number" ? b.value : undefined) : Promise.reject(new TvError("Controle de mídia indisponível nesta TV", "unsupported"))));
        return json({ ok: true, data: out ?? null });
      }

      case "favorites": {
        const appId = String(b.appId ?? "");
        if (!appId) return json({ error: "appId ausente" }, 400);
        const existing = await db.select().from(favoriteApps).where(and(eq(favoriteApps.deviceId, id), eq(favoriteApps.appId, appId)));
        if (existing.length) {
          await db.delete(favoriteApps).where(and(eq(favoriteApps.deviceId, id), eq(favoriteApps.appId, appId)));
          return json({ favorite: false });
        }
        const all = await db.select({ id: favoriteApps.id }).from(favoriteApps).where(eq(favoriteApps.deviceId, id));
        await db.insert(favoriteApps).values({ deviceId: id, appId, name: String(b.name ?? appId).slice(0, 80), icon: typeof b.icon === "string" ? b.icon : null, position: all.length });
        return json({ favorite: true });
      }

      default:
        return json({ error: "Ação desconhecida" }, 404);
    }
  } catch (e) {
    return fail(e);
  }
}
