import { eq } from "drizzle-orm";
import { db } from "@/db";
import { devices } from "@/db/schema";
import { body, fail, json } from "@/lib/api";
import { forget, status } from "@/lib/connection-manager";
import { getDevice, toDTO } from "@/lib/device-service";
import { normalizeMac } from "@/lib/net";

export const dynamic = "force-dynamic";
type Ctx = { params: Promise<{ id: string }> };

export async function GET(_req: Request, { params }: Ctx) {
  try {
    const row = await getDevice((await params).id);
    if (!row) return json({ error: "Dispositivo não encontrado" }, 404);
    return json({ device: { ...toDTO(row), status: status(row.id) } });
  } catch (e) {
    return fail(e);
  }
}

export async function PATCH(req: Request, { params }: Ctx) {
  try {
    const { id } = await params;
    const row = await getDevice(id);
    if (!row) return json({ error: "Dispositivo não encontrado" }, 404);
    const b = await body<{ name?: string; favorite?: boolean; mac?: string }>(req);
    const patch: Partial<typeof devices.$inferInsert> = {};
    if (typeof b.name === "string" && b.name.trim()) patch.name = b.name.trim().slice(0, 60);
    if (typeof b.mac === "string") {
      const mac = normalizeMac(b.mac);
      if (b.mac.trim() && !mac) return json({ error: "MAC inválido" }, 400);
      patch.mac = mac;
    }
    if (typeof b.favorite === "boolean") {
      if (b.favorite) await db.update(devices).set({ favorite: false });
      patch.favorite = b.favorite;
    }
    const [updated] = Object.keys(patch).length ? await db.update(devices).set(patch).where(eq(devices.id, id)).returning() : [row];
    return json({ device: { ...toDTO(updated), status: status(id) } });
  } catch (e) {
    return fail(e);
  }
}

export async function DELETE(_req: Request, { params }: Ctx) {
  try {
    const { id } = await params;
    await forget(id);
    await db.delete(devices).where(eq(devices.id, id));
    return json({ ok: true });
  } catch (e) {
    return fail(e);
  }
}
