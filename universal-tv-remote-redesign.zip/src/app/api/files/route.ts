import fs from "node:fs";
import { Readable, Transform } from "node:stream";
import { pipeline } from "node:stream/promises";
import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { transfers } from "@/db/schema";
import { fail, json } from "@/lib/api";
import { logActivity } from "@/lib/device-service";
import { filePathFor, MAX_UPLOAD_BYTES, safeName, toTransferDTO } from "@/lib/files";
import { localIPv4s } from "@/lib/net";
import { kindFromMime } from "@/lib/transfer";

export const dynamic = "force-dynamic";
export const maxDuration = 3600;

export async function GET(req: Request) {
  try {
    const rows = await db.select().from(transfers).orderBy(desc(transfers.createdAt)).limit(60);
    const port = new URL(req.url).port || process.env.PORT || "3000";
    const ip = localIPv4s()[0]?.address ?? null;
    return json({ transfers: rows.map(toTransferDTO), lanBase: ip ? `http://${ip}:${port}` : null });
  } catch (e) {
    return fail(e);
  }
}

/**
 * Raw-body streaming upload (so the browser can report real progress and abort):
 *   POST /api/files?name=foo.mp4&type=video/mp4&size=123
 */
export async function POST(req: Request) {
  const url = new URL(req.url);
  const name = safeName(url.searchParams.get("name") ?? "arquivo");
  const mime = (url.searchParams.get("type") || "application/octet-stream").slice(0, 100);
  const size = Number(url.searchParams.get("size") ?? 0);
  if (!req.body) return json({ error: "Corpo vazio" }, 400);
  if (size > MAX_UPLOAD_BYTES) return json({ error: "Arquivo maior que o limite configurado" }, 413);

  const [row] = await db
    .insert(transfers)
    .values({ name, mime, kind: kindFromMime(mime, name), size, status: "uploading" })
    .returning();
  const dest = filePathFor(row.id);
  let received = 0;
  try {
    const counter = new Transform({
      transform(chunk, _enc, cb) {
        received += chunk.length;
        if (received > MAX_UPLOAD_BYTES) return cb(new Error("Limite de tamanho excedido"));
        cb(null, chunk);
      },
    });
    await pipeline(Readable.fromWeb(req.body as never), counter, fs.createWriteStream(dest));
    const [done] = await db.update(transfers).set({ status: "ready", received, size: size || received, updatedAt: new Date() }).where(eq(transfers.id, row.id)).returning();
    await logActivity({ type: "file", label: `Arquivo enviado ao servidor: ${name}`, refId: row.id });
    return json({ transfer: toTransferDTO(done) });
  } catch (e) {
    await fs.promises.rm(dest, { force: true });
    const aborted = req.signal.aborted;
    await db
      .update(transfers)
      .set({ status: aborted ? "cancelled" : "failed", error: aborted ? "Cancelado pelo usuário" : (e as Error).message, received, updatedAt: new Date() })
      .where(eq(transfers.id, row.id));
    return fail(aborted ? new Error("Envio cancelado") : e);
  }
}
