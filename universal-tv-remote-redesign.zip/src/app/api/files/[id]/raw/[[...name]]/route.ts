import fs from "node:fs";
import { Readable } from "node:stream";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { transfers } from "@/db/schema";
import { filePathFor } from "@/lib/files";
import { isCastable } from "@/lib/transfer";

export const dynamic = "force-dynamic";
type Ctx = { params: Promise<{ id: string; name?: string[] }> };

/**
 * Serves an uploaded file to the TV (DLNA/Roku pull it over HTTP). Supports
 * HTTP Range (seeking) and HEAD. The URL is unguessable (UUID) and only meant
 * for the local network.
 */
async function serve(req: Request, { params }: Ctx, head: boolean) {
  const { id } = await params;
  if (!/^[0-9a-f-]{36}$/i.test(id)) return new Response("Not found", { status: 404 });
  const [t] = await db.select().from(transfers).where(eq(transfers.id, id)).limit(1);
  if (!t || !["ready", "sending", "sent"].includes(t.status)) return new Response("Not found", { status: 404 });
  const p = filePathFor(id);
  let stat: fs.Stats;
  try {
    stat = await fs.promises.stat(p);
  } catch {
    return new Response("Not found", { status: 404 });
  }
  const total = stat.size;
  const headers: Record<string, string> = {
    "Content-Type": isCastable(t.kind) || t.mime === "application/pdf" ? t.mime : "application/octet-stream",
    "Accept-Ranges": "bytes",
    "X-Content-Type-Options": "nosniff",
    "transferMode.dlna.org": "Streaming",
    "contentFeatures.dlna.org": "DLNA.ORG_OP=01;DLNA.ORG_CI=0;DLNA.ORG_FLAGS=01700000000000000000000000000000",
    "Content-Disposition": `${isCastable(t.kind) ? "inline" : "attachment"}; filename*=UTF-8''${encodeURIComponent(t.name)}`,
    "Cache-Control": "private, max-age=0",
  };
  const range = req.headers.get("range");
  let start = 0;
  let end = total - 1;
  let status = 200;
  if (range) {
    const m = /^bytes=(\d*)-(\d*)$/.exec(range);
    if (m) {
      if (m[1] === "" && m[2] !== "") {
        start = Math.max(0, total - Number(m[2]));
      } else {
        start = Number(m[1]);
        if (m[2] !== "") end = Math.min(total - 1, Number(m[2]));
      }
      if (start > end || start >= total) return new Response(null, { status: 416, headers: { "Content-Range": `bytes */${total}` } });
      status = 206;
      headers["Content-Range"] = `bytes ${start}-${end}/${total}`;
    }
  }
  headers["Content-Length"] = String(total === 0 ? 0 : end - start + 1);
  if (head || total === 0) return new Response(null, { status, headers });
  const stream = fs.createReadStream(p, { start, end });
  return new Response(Readable.toWeb(stream) as ReadableStream, { status, headers });
}

export async function GET(req: Request, ctx: Ctx) {
  return serve(req, ctx, false);
}
export async function HEAD(req: Request, ctx: Ctx) {
  return serve(req, ctx, true);
}
