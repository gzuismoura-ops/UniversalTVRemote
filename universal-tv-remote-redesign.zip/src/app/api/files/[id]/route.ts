import fs from "node:fs";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { transfers } from "@/db/schema";
import { fail, json } from "@/lib/api";
import { filePathFor } from "@/lib/files";

export const dynamic = "force-dynamic";

export async function DELETE(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params;
    if (!/^[0-9a-f-]{36}$/i.test(id)) return json({ error: "Id inválido" }, 400);
    await fs.promises.rm(filePathFor(id), { force: true });
    await db.delete(transfers).where(eq(transfers.id, id));
    return json({ ok: true });
  } catch (e) {
    return fail(e);
  }
}
