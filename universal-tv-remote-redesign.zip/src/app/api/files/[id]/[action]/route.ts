import fs from "node:fs";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { transfers } from "@/db/schema";
import { body, fail, json } from "@/lib/api";
import { run } from "@/lib/connection-manager";
import type { TransferStatus } from "@/lib/commands";
import { getDevice, logActivity } from "@/lib/device-service";
import { filePathFor, toTransferDTO } from "@/lib/files";
import { lanIpFor, TvError } from "@/lib/net";
import { capabilitiesFor } from "@/lib/protocols";
import { canTransition, isCastable } from "@/lib/transfer";

export const dynamic = "force-dynamic";
export const maxDuration = 60;
type Ctx = { params: Promise<{ id: string; action: string }> };

async function setStatus(id: string, status: TransferStatus, extra: Partial<typeof transfers.$inferInsert> = {}) {
  const [row] = await db.update(transfers).set({ status, updatedAt: new Date(), ...extra }).where(eq(transfers.id, id)).returning();
  return row;
}

export async function POST(req: Request, { params }: Ctx) {
  try {
    const { id, action } = await params;
    if (!/^[0-9a-f-]{36}$/i.test(id)) return json({ error: "Id inválido" }, 400);
    const [t] = await db.select().from(transfers).where(eq(transfers.id, id)).limit(1);
    if (!t) return json({ error: "Transferência não encontrada" }, 404);
    const b = await body<{ deviceId?: string }>(req);

    if (action === "send") {
      const dev = b.deviceId ? await getDevice(b.deviceId) : null;
      if (!dev) return json({ error: "Escolha uma TV" }, 400);
      if (!canTransition(t.status as TransferStatus, "sending")) return json({ error: `Não é possível enviar neste estado (${t.status})` }, 409);
      if (!isCastable(t.kind)) {
        return json({ error: "TVs só reproduzem fotos, vídeos e músicas por este método. PDFs e outros arquivos ficam disponíveis por link na rede local (abra no navegador da TV).", kind: "unsupported" }, 422);
      }
      const caps = capabilitiesFor(dev.brand, (dev.meta ?? {}) as Record<string, unknown>);
      if (!caps.features.includes("cast")) {
        return json({ error: "Esta TV não expõe um receptor de mídia (DLNA/Roku). Ela precisaria de um app receptor companheiro.", kind: "unsupported" }, 422);
      }
      const lan = lanIpFor(dev.ip);
      if (!lan) return json({ error: "Servidor sem IP de rede local" }, 500);
      const port = new URL(req.url).port || process.env.PORT || "3000";
      const url = `http://${lan}:${port}/api/files/${t.id}/raw/${encodeURIComponent(t.name)}`;
      if (!(await fs.promises.stat(filePathFor(t.id)).catch(() => null))) return json({ error: "Arquivo não está mais no servidor" }, 410);

      await setStatus(id, "sending", { deviceId: dev.id, error: null, method: dev.brand === "roku" ? "roku-media-player" : "dlna" });
      try {
        await run(dev.id, (d) => (d.cast ? d.cast({ url, mime: t.mime, title: t.name, kind: t.kind }) : Promise.reject(new TvError("Sem suporte a envio de mídia", "unsupported"))));
        const done = await setStatus(id, "sent", { received: t.size });
        await logActivity({ deviceId: dev.id, type: "media", label: `Enviado à TV: ${t.name}`, refId: t.id });
        return json({ transfer: toTransferDTO(done), url });
      } catch (e) {
        await setStatus(id, "failed", { error: (e as Error).message });
        throw e;
      }
    }

    if (action === "cancel") {
      const st = t.status as TransferStatus;
      if (!canTransition(st, "cancelled")) return json({ error: "Nada para cancelar" }, 409);
      if (st === "sending" && t.deviceId) {
        await run(t.deviceId, (d) => (d.media ? d.media("stop") : Promise.resolve())).catch(() => undefined);
      }
      return json({ transfer: toTransferDTO(await setStatus(id, "cancelled", { error: "Cancelado pelo usuário" })) });
    }

    return json({ error: "Ação desconhecida" }, 404);
  } catch (e) {
    return fail(e);
  }
}
