import { json, fail } from "@/lib/api";
import { listDevices } from "@/lib/device-service";
import { identify } from "@/lib/protocols";
import { localIPv4s } from "@/lib/net";
import { ssdpSearch } from "@/lib/ssdp";

export const dynamic = "force-dynamic";
export const maxDuration = 30;

export async function GET() {
  try {
    const [responses, saved] = await Promise.all([ssdpSearch(3000), listDevices()]);
    const byIp = new Map<string, { location: string | null; server: string | null }>();
    for (const r of responses) {
      const cur = byIp.get(r.ip);
      byIp.set(r.ip, { location: cur?.location ?? r.location, server: cur?.server ?? r.server });
    }
    const ips = [...byIp.keys()].slice(0, 40);
    const found = await Promise.all(
      ips.map(async (ip) => {
        const id = await identify(ip).catch(() => null);
        if (!id) return null;
        return {
          ip,
          brand: id.brand,
          name: id.name,
          model: id.model ?? null,
          saved: saved.some((d) => d.ip === ip),
        };
      }),
    );
    return json({
      devices: found.filter(Boolean),
      scanned: ips.length,
      serverAddresses: localIPv4s().map((i) => i.address),
    });
  } catch (e) {
    return fail(e);
  }
}
