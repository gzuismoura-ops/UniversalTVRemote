import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { activities } from "@/db/schema";
import { fail, json } from "@/lib/api";
import { activityDTO } from "@/lib/device-service";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  try {
    const deviceId = new URL(req.url).searchParams.get("deviceId");
    const q = db.select().from(activities);
    const rows = await (deviceId && /^[0-9a-f-]{36}$/i.test(deviceId) ? q.where(eq(activities.deviceId, deviceId)) : q).orderBy(desc(activities.id)).limit(40);
    return json({ activities: rows.map(activityDTO) });
  } catch (e) {
    return fail(e);
  }
}
