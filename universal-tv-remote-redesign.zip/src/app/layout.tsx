import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "Controle Universal de TV",
  description: "Controle remoto universal para smart TVs: pareamento permanente, apps, arquivos e mídia.",
  applicationName: "Controle Universal de TV",
  manifest: "/manifest.webmanifest",
  appleWebApp: { capable: true, title: "Controle TV", statusBarStyle: "black-translucent" },
};

export const viewport: Viewport = {
  themeColor: "#07080d",
  width: "device-width",
  initialScale: 1,
  maximumScale: 1,
  viewportFit: "cover",
};

// Applies the saved theme before first paint (no flash).
const themeScript = `try{var s=JSON.parse(localStorage.getItem('utv-settings')||'{}');var t=s.theme||'dark';if(t==='system'){t=matchMedia('(prefers-color-scheme: light)').matches?'light':'dark'}document.documentElement.dataset.theme=t}catch(e){document.documentElement.dataset.theme='dark'}`;

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="pt-BR" suppressHydrationWarning>
      <head>
        <script dangerouslySetInnerHTML={{ __html: themeScript }} />
      </head>
      <body className="antialiased">{children}</body>
    </html>
  );
}
